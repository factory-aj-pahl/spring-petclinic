# Fun facts

A few things about the repository that turned up while counting. Each one was checked with `git` on 2026-11-13 against `origin/main` or commit `2aff817`. [Lore](lore.md) has the full history and [By the numbers](by-the-numbers.md) has the statistics.

## The oldest lines are from November 2009

`git blame origin/main` on every text file under `src/` plus `pom.xml` finds 7,214 lines, and 319 of them still carry a 2009 author date. The oldest come from `521d01d` on 2009-11-25, the commit that turned the project into a Maven build. They include the Javadoc of `src/main/java/org/springframework/samples/petclinic/model/Person.java`, typo included:

```java
/**
 * Simple JavaBean domain object representing an person.
 *
 * @author Ken Krebs
 */
```

The same commit is the oldest line in `src/main/java/org/springframework/samples/petclinic/owner/Owner.java`, `src/main/java/org/springframework/samples/petclinic/owner/Pet.java`, `src/main/java/org/springframework/samples/petclinic/owner/PetType.java`, `src/main/java/org/springframework/samples/petclinic/owner/Visit.java`, `src/main/java/org/springframework/samples/petclinic/vet/Vet.java`, `src/main/java/org/springframework/samples/petclinic/vet/Specialty.java`, `src/main/java/org/springframework/samples/petclinic/owner/OwnerController.java` and the default, English and German message bundles. Nothing from the very first 2009-05-05 commits survives.

The six vets in the seed data have not changed either. James Carter, Helen Leary, Linda Douglas, Rafael Ortega, Henry Stevens and Sharon Jenkins arrived in the MySQL population script on 2009-11-26 and are the same six names in `src/main/resources/db/h2/data.sql` today.

## Why the crash page is called /oups

`src/main/java/org/springframework/samples/petclinic/system/CrashController.java` maps `GET /oups` and throws a `RuntimeException` on purpose, so you can see the error page. It was added on 2013-02-05 in `ae9085d` "added CrashController to showcase behaviour when exception occurs", with the message "Something went wrong...". Today the message starts with "Expected:", likely so that nobody mistakes it for a real failure in the logs. The spelling appears to be the French "oups" rather than "oops"; the commit does not say. The navigation bar in `src/main/resources/templates/fragments/layout.html` still links to it as "trigger a RuntimeException to see how it is handled". [Error handling](features/error-handling.md) covers what the page shows.

## Not one TODO

`git grep -IinE 'TODO|FIXME|HACK|XXX'` over the tracked files at `2aff817` returns nothing. According to `git log origin/main -S'TODO'`, the first TODOs arrived with the 2009-05-06 commit `0901364` "owner pages". The last one left on 2019-03-28, when `5d73726` "Upgrade maven wrapper" replaced a wrapper script that contained `# TODO classpath?`. No TODO has been added since.

## Front-end libraries, there and back

The three largest commits in the history change no application logic. On 2016-01-30 `c65cfb6` moved the front-end libraries from WebJars to Bower and touched 1,082 files. On 2016-04-04 `7dcf82a` moved to Bootstrap 3 (830 files). On 2016-06-28 `eb6f934` went back to WebJars (377 files). The longest tracked file today is also front-end: the generated `src/main/resources/static/resources/css/petclinic.css` at 9,531 lines. The longest Java file is a test, `src/test/java/org/springframework/samples/petclinic/owner/OwnerControllerTests.java` at 330 lines.

## Names and labels

- In November 2009 the Maven project was named `petclinic-classic`, with the artifact id `org.springframework.samples.petclinic`. The first commit message called it "petclinic 3", probably after Spring Framework 3. The artifact id `spring-petclinic` dates from the Spring 3.2 migration on 2013-01-09 (`87ccf9f`).
- The repository has a single tag, `1.5.x`, from 2017-11-03. It points at a commit on `main` built with Spring Boot 1.5.4, about two months before the move to Spring Boot 2.0 snapshots on 2018-01-09.
- `@author` tags in the Java files under `src/` name 14 different people, from the original 2009 authors to contributors of the last few years. Git knows 156 distinct authors on `origin/main`, so most contributors never added their name to a file. [Maintainers](maintainers.md) lists who looks after each area now.

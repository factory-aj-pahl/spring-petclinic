# By the numbers

Data collected on 2026-11-13 from commit `2aff817`.

This page measures the repository: how big it is, how often it changes, how much of the history is attributed to bots, and how large the code files are. History numbers come from `origin/main` (500158f, 1,047 commits) unless a row says otherwise. The 11 commits on the branch `security/spring-boot-4.1.2-cve-remediation` up to `2aff817` are counted separately. [Lore](lore.md) tells the story behind these numbers and [Architecture](overview/architecture.md) explains what the code does.

## Size

### Lines by language

```mermaid
xychart-beta horizontal
    title "Lines in tracked files by type"
    x-axis ["Java", "Markdown", "YAML", "Properties", "HTML", "XML", "SCSS", "SQL", "Python", "Gradle"]
    y-axis "Lines" 0 --> 5000
    bar [4780, 1019, 862, 579, 536, 461, 388, 344, 249, 98]
```

Method: `git ls-files` (the untracked `droid-wiki/` excluded), grouped by file extension, `wc -l` per file. The compiled `src/main/resources/static/resources/css/petclinic.css` (9,531 lines) and the SVG fonts are left out because they are generated or binary-like.

### Files by group

| Group | Paths | Files |
| --- | --- | --- |
| Main Java source | `src/main/java/**` | 30 |
| Tests | `src/test/**` (24 Java files and the JMeter plan `src/test/jmeter/petclinic_test_plan.jmx`) | 25 |
| Application resources | `src/main/resources/templates/**`, `src/main/resources/messages/**`, `src/main/resources/db/**/*.sql`, `src/main/resources/application*.properties` | 33 |
| Static assets | `src/main/resources/static/**`, `src/main/scss/**` | 18 |
| Build and configuration | `pom.xml`, `build.gradle`, `settings.gradle`, wrappers, `gradle/`, `.mvn/`, `src/checkstyle/`, `.github/` (except the PR template), `.factory/` (except skill Markdown), `k8s/`, `docker-compose.yml`, `.devcontainer/`, `.gitpod.yml`, dot files | 38 |
| Documentation | `*.md`, `*.txt` (including `LICENSE.txt`, `src/main/resources/banner.txt` and the two database setup notes) | 13 |
| Total | | 157 |

Note: the static group is 14 files under `src/main/resources/static/resources/` (1 CSS, 8 fonts, 5 images) plus 4 SCSS files under `src/main/scss/`. Groups were assigned by path in that order, so a Markdown file under `.factory/skills/` counts as documentation.

### Code structure

| Item | Count | Where |
| --- | --- | --- |
| Packages in main code | 4 (`owner`, `vet`, `system`, `model`) plus the root package | `src/main/java/org/springframework/samples/petclinic/` |
| Thymeleaf templates | 12 (8 pages, 3 fragments, `src/main/resources/templates/error.html`) | `src/main/resources/templates/` |
| Message bundles | 11 (default plus 10 languages) | `src/main/resources/messages/` |
| SQL scripts | 7 (schema and data for H2, MySQL and PostgreSQL, plus `src/main/resources/db/mysql/user.sql`) | `src/main/resources/db/` |
| GitHub Actions workflows | 6 | `.github/workflows/` |

## Activity

### Commits per year

```mermaid
xychart-beta
    title "Commits per year on origin/main (author date)"
    x-axis ["2009", "2010", "2011", "2012", "2013", "2014", "2015", "2016", "2017", "2018", "2019", "2020", "2021", "2022", "2023", "2024", "2025", "2026"]
    y-axis "Commits" 0 --> 250
    bar [57, 8, 0, 1, 224, 40, 95, 122, 26, 60, 43, 51, 46, 57, 49, 79, 56, 33]
```

Method: `git log origin/main --format=%ad --date=format:%Y | sort | uniq -c`. The years add up to 1,047. The 2009 to 2012 commits were imported into Git on 2013-01-09 with their original author dates (see [Lore](lore.md)), so their commit dates are all 2013. The 11 branch commits are not included; all of them are dated 2026-11-13.

### Commits per month, October 2025 to September 2026

| Month | Commits |
| --- | --- |
| 2025-10 | 7 |
| 2025-11 | 10 |
| 2025-12 | 6 |
| 2026-01 | 3 |
| 2026-02 | 2 |
| 2026-03 | 4 |
| 2026-04 | 5 |
| 2026-05 | 1 |
| 2026-06 | 5 |
| 2026-07 | 6 |
| 2026-08 | 2 |
| 2026-09 | 5 |
| Total | 56 |

Method: author dates on `origin/main`, the 12 calendar months up to the last `origin/main` commit on 2026-09-29. On top of these, the branch added 11 commits on 2026-11-13 (`git log origin/main..HEAD`).

### Churn in the 90 days before 2026-09-29

13 commits landed between 2026-07-01 and 2026-09-29 (commit date). Most of them touched owner handling: unique pet names, whitespace in the owner search, field lengths and page bounds.

| File | Commits |
| --- | --- |
| `src/main/java/org/springframework/samples/petclinic/owner/OwnerController.java` | 3 |
| `src/test/java/org/springframework/samples/petclinic/owner/OwnerControllerTests.java` | 3 |
| `src/main/java/org/springframework/samples/petclinic/owner/Owner.java` | 2 |
| `src/main/java/org/springframework/samples/petclinic/vet/VetController.java` | 2 |
| `src/main/resources/db/postgres/schema.sql` | 2 |
| `src/test/java/org/springframework/samples/petclinic/owner/PetValidatorTests.java` | 2 |

| Directory | File changes |
| --- | --- |
| `src/main/java/org/springframework/samples/petclinic/owner/` | 8 |
| `src/test/java/org/springframework/samples/petclinic/owner/` | 8 |
| `src/main/resources/messages/` | 2 |
| `src/main/resources/db/postgres/` | 2 |
| `src/main/java/org/springframework/samples/petclinic/vet/` | 2 |

Method: `git log origin/main --since=2026-07-01 --until=2026-09-30 --name-only`, counting each file once per commit. A directory's number is the sum over the files directly in it.

### Churn over the last two years

118 commits landed on `origin/main` from 2024-09-29 to 2026-09-29 (commit date).

| File | Commits |
| --- | --- |
| `pom.xml` | 26 |
| `build.gradle` | 22 |
| `README.md` | 21 |
| `src/test/java/org/springframework/samples/petclinic/owner/PetControllerTests.java` | 13 |
| `src/main/java/org/springframework/samples/petclinic/owner/PetController.java` | 12 |
| `src/test/java/org/springframework/samples/petclinic/owner/OwnerControllerTests.java` | 12 |
| `src/test/java/org/springframework/samples/petclinic/MySqlIntegrationTests.java` | 12 |
| `src/main/java/org/springframework/samples/petclinic/owner/OwnerRepository.java` | 11 |
| `src/main/java/org/springframework/samples/petclinic/owner/OwnerController.java` | 11 |
| `src/test/java/org/springframework/samples/petclinic/service/ClinicServiceTests.java` | 10 |

| Directory | File changes |
| --- | --- |
| Repository root (`pom.xml`, `build.gradle`, `README.md` and others) | 97 |
| `src/main/java/org/springframework/samples/petclinic/owner/` | 75 |
| `src/test/java/org/springframework/samples/petclinic/owner/` | 40 |
| `src/main/resources/messages/` | 39 |
| `src/test/java/org/springframework/samples/petclinic/` (root test package) | 38 |
| `src/main/java/org/springframework/samples/petclinic/model/` | 18 |
| `src/main/java/org/springframework/samples/petclinic/vet/` | 17 |
| `gradle/wrapper/` | 14 |

Method: `git log origin/main --since=2024-09-29 --name-only`, same counting as above. The build files lead because each Spring Boot upgrade changes both `pom.xml` and `build.gradle`, as `AGENTS.md` requires.

## Bot-attributed commits

| Measure on `origin/main` | Commits |
| --- | --- |
| Author name ends in `[bot]` | 0 |
| `Co-authored-by:` trailer naming `factory-droid[bot]`, `dependabot[bot]`, `github-actions[bot]` or `copilot` | 0 |
| `Co-authored-by:` trailer naming any AI model (one commit, `a2c2ef9` on 2026-05-27, names a Claude model) | 1 |
| Total commits | 1,047 |

Method: `git log origin/main --format='%an'` checked for names ending in `[bot]`, and `git log origin/main --format='%(trailers:key=Co-authored-by,valueonly)'` checked for the bot names above, case-insensitive. Only two `Co-authored-by` values appear on `origin/main` at all: one person and the Claude model.

On this branch, all 11 commits (`d74cc16` to `2aff817`) carry `Co-authored-by: factory-droid[bot]`.

These counts are a lower bound. Editor assistants and chat tools that help write code leave no mark in Git unless the author adds a trailer, so the share of machine-assisted changes cannot be determined from history.

## Complexity

### Java file size per package

| Package | Files | Lines | Average lines per file | Largest file (lines) |
| --- | --- | --- | --- | --- |
| `owner` | 12 | 1,132 | 94 | `src/main/java/org/springframework/samples/petclinic/owner/PetController.java` (207) |
| `vet` | 6 | 302 | 50 | `src/main/java/org/springframework/samples/petclinic/vet/VetController.java` (79) |
| `system` | 5 | 196 | 39 | `src/main/java/org/springframework/samples/petclinic/system/WebConfiguration.java` (60) |
| `model` | 4 | 179 | 45 | `src/main/java/org/springframework/samples/petclinic/model/Person.java` (57) |
| root package | 3 | 90 | 30 | `src/main/java/org/springframework/samples/petclinic/PetClinicRuntimeHints.java` (38) |
| All main code | 30 | 1,899 | 63 | |

Method: `wc -l` on the tracked `.java` files in each package directory, the package-info.java files included. Lines include the license header and blank lines.

### Largest files

| Main source file | Lines |
| --- | --- |
| `src/main/java/org/springframework/samples/petclinic/owner/PetController.java` | 207 |
| `src/main/java/org/springframework/samples/petclinic/owner/OwnerController.java` | 190 |
| `src/main/java/org/springframework/samples/petclinic/owner/Owner.java` | 188 |
| `src/main/java/org/springframework/samples/petclinic/owner/VisitController.java` | 114 |
| `src/main/java/org/springframework/samples/petclinic/owner/Pet.java` | 85 |

| Test file | Lines |
| --- | --- |
| `src/test/java/org/springframework/samples/petclinic/owner/OwnerControllerTests.java` | 330 |
| `src/test/java/org/springframework/samples/petclinic/service/ClinicServiceTests.java` | 315 |
| `src/test/java/org/springframework/samples/petclinic/owner/PetControllerTests.java` | 274 |
| `src/test/java/org/springframework/samples/petclinic/PostgresIntegrationTests.java` | 150 |
| `src/test/java/org/springframework/samples/petclinic/PostgresOutageIntegrationTests.java` | 145 |

### Tests

- Test Java lines to main Java lines: 2,881 / 1,899 = 1.52. There is about half again as much test code as application code.
- `./mvnw clean verify` ran 116 tests with Docker available, with 0 failures and 0 skipped. Without Docker the MySQL tests are reported as skipped and the PostgreSQL ones are not counted at all, so the total drops. [Testing](how-to-contribute/testing.md) explains the test layers.

## Growth

| End of year | Tracked files | Java files | Distinct authors so far |
| --- | --- | --- | --- |
| 2013 | 97 | 51 | 13 |
| 2016 | 90 | 34 | 39 |
| 2019 | 95 | 37 | 61 |
| 2022 | 110 | 36 | 90 |
| 2024 | 121 | 40 | 128 |
| 2026 (`origin/main`) | 132 | 50 | 156 |
| 2026 (this branch) | 157 | 54 | |

Method: the last `origin/main` commit before 31 December of each year (by commit date), `git ls-tree -r` for files and `git log <commit> --format=%an | sort -u` for authors. Bots are not among the authors. [Maintainers](maintainers.md) lists who works on each area today.

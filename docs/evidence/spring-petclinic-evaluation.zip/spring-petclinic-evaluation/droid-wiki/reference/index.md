# Reference

These pages collect the facts you look up rather than read: every configuration property, every table and column, and every dependency with its version. Each one points back to the file it was taken from.

## Pages

| Page | What it lists |
| --- | --- |
| [Configuration](configuration.md) | Properties in `src/main/resources/application*.properties`, profiles, environment variables, Spring Boot defaults the application relies on, Kubernetes settings, build and test configuration |
| [Data models](data-models.md) | Tables, columns, types per database, keys, indexes, constraints, entity mapping, validation and seed data |
| [Dependencies](dependencies.md) | Summary of `docs/DEPENDENCIES.md`: libraries and versions, external services, the 20 advisories fixed by Spring Boot 4.1.2, counts and freshness |

## Source documents in the repository

- `docs/DEPENDENCIES.md` ([open](../../docs/DEPENDENCIES.md)) is the maintained dependency list with Confirmed, Inferred and Unknown labels and the advisory table. [Dependencies](dependencies.md) summarizes it; when they disagree, the file wins.
- `docs/RUNBOOK.md` ([open](../../docs/RUNBOOK.md)) covers build, run, health checks, failure behaviour, the vulnerability scan, the QA check, the Spring Boot upgrade procedure, rollback and the follow-ups F1 onward.

## Related pages

- [Persistence](../systems/persistence.md) explains how the entities, repositories and SQL scripts work together.
- [Getting started](../overview/getting-started.md) has the commands to build and run the application.
- [Maintainers](../maintainers.md) lists who has worked on each area.

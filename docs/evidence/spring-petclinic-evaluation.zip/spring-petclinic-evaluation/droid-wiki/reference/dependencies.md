# Dependencies

This page summarizes `docs/DEPENDENCIES.md` ([open](../../docs/DEPENDENCIES.md)), the maintained list of what PetClinic depends on, and checks its versions against `pom.xml` and the runtime SBOM. When this page and that file disagree, the file is the one to trust and update.

## Overview

- The application is built on the Spring Boot 4.1.2 parent (`pom.xml`) or plugin (`build.gradle`), which manages almost every library version.
- `pom.xml` declares 28 direct dependencies: 8 compile, 7 runtime, 1 optional (`spring-boot-devtools`) and 12 test. `build.gradle` declares 23 plus 2 Checkstyle artifacts.
- The SBOM in the jar (`target/classes/META-INF/sbom/application.cdx.json`, served at `/actuator/sbom`) lists 107 components: 106 required and 1 optional (`spring-boot-devtools`). `docs/DEPENDENCIES.md` says the full resolved Maven list, test scope included, has about 170 artifacts.
- The only runtime network peer is the database; `src/main` makes no outbound HTTP, mail or messaging calls (Confirmed in `docs/DEPENDENCIES.md`).
- The upgrade from Spring Boot 4.1.0 to 4.1.2 fixed 20 published advisories in six libraries. After it, OSV-Scanner reports no known vulnerabilities (see [Security](../security.md)).

## Status labels

`docs/DEPENDENCIES.md` marks each entry Confirmed (seen in code and exercised by a test or a live run), Inferred (follows from the code but nothing exercises it) or Unknown (the repository cannot answer it). Counted from the status columns of its tables:

| Label | Entries | Where |
| --- | --- | --- |
| Confirmed | 23 | 6 runtime services, 2 deployment items, 10 build and test tools, 5 CI and developer environment items |
| Inferred | 9 | Service binding, container image build, GraalVM native build tools, libsass-maven-plugin, JMeter plan, QA check, wiki refresh, dev container, Gitpod |
| Unknown | 1 | The Kubernetes image `dsyer/petclinic` |

The prose also marks "Outbound network calls: none" as Confirmed. The advisory table has its own reachability column: 9 advisories are "Not reachable", 1 is "Unlikely" and 10 are "Unknown".

### Unknown items

- **Kubernetes image `dsyer/petclinic`** ([Deployment table](../../docs/DEPENDENCIES.md#deployment)). `k8s/petclinic.yml` uses it with no tag, and no workflow in `.github/workflows/` builds or pushes it. Who builds it, from which commit and with which library versions is unknown, so the 4.1.2 fixes do not reach Kubernetes until the image is rebuilt (follow-up F4 in `docs/RUNBOOK.md`). See [Deployment](../deployment.md).
- **Reachability of 10 advisories** ([advisory table](../../docs/DEPENDENCIES.md#advisories-fixed-by-the-spring-boot-412-upgrade)): Tomcat GHSA-gcx9-497g-6cp6, GHSA-mqg3-r7h5-24x4 and GHSA-5v3h-fjv2-54fg; Jackson GHSA-p6pp-m3f8-5c89, GHSA-cxp5-3px4-pw24, GHSA-q4xh-88c3-wmh7, GHSA-wv8q-qhhj-9h54, GHSA-vvgp-rfg2-7rr6 and GHSA-wjgm-6hv5-3cvf; PostgreSQL driver GHSA-j92g-9f8w-j867. The advisory texts do not say enough to rule the application in or out. All are fixed by the upgrade.

## Runtime libraries

Versions from `docs/DEPENDENCIES.md`, checked against the SBOM; every version below matches the SBOM.

| Library | Version | Declared in `pom.xml` as |
| --- | --- | --- |
| spring-webmvc, spring-core | 7.0.10 | `spring-boot-starter-webmvc` |
| tomcat-embed-core, tomcat-embed-el, tomcat-embed-websocket | 11.0.27 | `spring-boot-starter-webmvc` |
| hibernate-core | 7.4.13.Final | `spring-boot-starter-data-jpa` |
| spring-data-jpa | 4.1.2 | `spring-boot-starter-data-jpa` |
| HikariCP | 7.0.2 | `spring-boot-starter-data-jpa` |
| hibernate-validator | 9.1.5.Final | `spring-boot-starter-validation` |
| thymeleaf, thymeleaf-spring6 | 3.1.5.RELEASE | `spring-boot-starter-thymeleaf` |
| jackson-core, jackson-databind (group `tools.jackson.core`) | 3.1.7 | through `spring-boot-starter-jackson` |
| logback-classic | 1.5.38 | through `spring-boot-starter-logging` |
| log4j-api | 2.25.5 | through `log4j-to-slf4j`; only bridges to SLF4J |
| micrometer-core | 1.17.2 | `spring-boot-starter-actuator` |
| spring-boot, spring-boot-actuator | 4.1.2 | starters |
| javax.cache:cache-api | 1.1.1 | direct, compile |
| jakarta.xml.bind-api | 4.0.5 | direct, compile (XML for `/vets`) |
| h2 | 2.4.240 | direct, runtime |
| mysql-connector-j | 9.7.0 | direct, runtime |
| postgresql | 42.7.14 | direct, runtime (brings checker-qual 3.55.1) |
| caffeine | 3.2.4 | direct, runtime |
| webjars-locator-lite | 1.1.3 | direct, runtime, version from `pom.xml` property |
| bootstrap (webjar) | 5.3.8 | direct, runtime, version from `pom.xml` property |
| font-awesome (webjar) | 4.7.0 | direct, runtime, version from `pom.xml` property |
| spring-boot-devtools | 4.1.2 | optional; active under `./mvnw spring-boot:run` |

`cache-api` is on the classpath, but there is no JCache provider, so the JCache customizer in `src/main/java/org/springframework/samples/petclinic/system/CacheConfiguration.java` never runs (F12, see [Caching](../systems/caching.md)).

Test-only dependencies in `pom.xml`: the Spring Boot test starters for data JPA, REST client, Thymeleaf, validation, Web MVC, Actuator and cache, plus `spring-boot-starter-restclient`, `spring-boot-testcontainers`, `spring-boot-docker-compose`, `testcontainers-junit-jupiter` and `testcontainers-mysql`. `build.gradle` has 7 test dependencies and puts Actuator in `runtimeOnly`; this scope drift is follow-up F11. Build plugins and their versions are listed on [Configuration](configuration.md#build-time-configuration) and [Tooling](../how-to-contribute/tooling.md).

## External services and images

| Service or image | Used by | Defined in |
| --- | --- | --- |
| H2 2.4.240, in memory | Default run and every `@SpringBootTest` without a profile | `src/main/resources/application.properties` |
| MySQL `mysql:9.7` | `mysql` profile, Compose service, `MySqlIntegrationTests` and `MysqlTestApplication` (Testcontainers) | `docker-compose.yml`, `src/test/java/org/springframework/samples/petclinic/MySqlIntegrationTests.java` |
| PostgreSQL `postgres:18.4` | `postgres` profile, Compose service, `PostgresIntegrationTests` (Compose), `PostgresOutageIntegrationTests` (Testcontainers), Kubernetes `demo-db` | `docker-compose.yml`, `k8s/db.yml`, `src/test/java/org/springframework/samples/petclinic/PostgresOutageIntegrationTests.java` |
| Docker Hub `dsyer/petclinic`, no tag | Kubernetes Deployment `petclinic` and the kind workflow | `k8s/petclinic.yml` (Unknown provenance) |
| Buildpack builder | `./mvnw spring-boot:build-image`; there is no Dockerfile | Spring Boot Maven plugin defaults (Inferred) |
| Dev container images | `mcr.microsoft.com/devcontainers/base:ubuntu` with Java 21; Gitpod on `mcr.microsoft.com/vscode/devcontainers/java:0-17-bullseye` | `.devcontainer/devcontainer.json`, `.devcontainer/Dockerfile` |
| Factory API | Droid CLI in the QA and wiki workflows (needs `FACTORY_API_KEY`) | `.github/workflows/qa.yml`, `.github/workflows/droid-wiki-refresh.yml` |

GitHub Actions used in `.github/workflows/`: `actions/checkout@v4`, `actions/setup-java@v4`, `gradle/actions/setup-gradle@v4`, `helm/kind-action@v1`, `actions/setup-node@v4`, `actions/upload-artifact@v4`, `actions/download-artifact@v4`, `google/osv-scanner-action` reusable workflows at `v2.7.1`, and `peter-evans/create-pull-request` pinned to a commit (v8.1.1). Only the last one is pinned to a commit. The QA workflow also installs `agent-browser` 0.43.0 and the latest, unpinned Droid CLI. Dependabot (`.github/dependabot.yml`) opens weekly updates for Maven, Gradle and GitHub Actions. [Deployment](../deployment.md) covers the Kubernetes and Compose setups.

## Advisories fixed by Spring Boot 4.1.2

Spring Boot 4.1.0 managed six libraries with 20 published advisories: 7 critical, 7 high and 6 moderate. 4.1.1 still left 11 open; 4.1.2 is the first release that fixes them all. The full table, with GHSA and CVE ids, severities, first fixed versions and reachability notes, is in [`docs/DEPENDENCIES.md`](../../docs/DEPENDENCIES.md#advisories-fixed-by-the-spring-boot-412-upgrade).

| Package | Before | After | Advisories | Critical | High | Moderate |
| --- | --- | --- | --- | --- | --- | --- |
| tomcat-embed-core | 11.0.22 | 11.0.27 | 7 | 5 | 1 | 1 |
| spring-webmvc | 7.0.8 | 7.0.10 | 2 | 2 | 0 | 0 |
| jackson-core | 3.1.4 | 3.1.7 | 2 | 0 | 2 | 0 |
| jackson-databind | 3.1.4 | 3.1.7 | 7 | 0 | 3 | 4 |
| postgresql | 42.7.11 | 42.7.14 | 1 | 0 | 1 | 0 |
| log4j-api | 2.25.4 | 2.25.5 | 1 | 0 | 0 | 1 |
| **Total** | | | **20** | **7** | **7** | **6** |

`src/test/java/org/springframework/samples/petclinic/PatchedDependencyVersionsTests.java` fails the build if any of these six libraries resolves below its first fixed version. Raise a minimum there when a new advisory is fixed; never lower one. The upgrade procedure and the local scan commands are in `docs/RUNBOOK.md` ([open](../../docs/RUNBOOK.md)).

## Freshness

- **Font Awesome 4.7.0** dates from 2016 and is no longer maintained (follow-up F14). It is set by `webjars-font-awesome.version` in `pom.xml` and `webjarsFontawesomeVersion` in `build.gradle`.
- **LibSass** is deprecated upstream. The `css` profile in `pom.xml` uses `libsass-maven-plugin` 0.3.4 to compile `src/main/scss/` (also F14). It runs only when someone recompiles the CSS.
- **Checkstyle** is held at 12.3.1 because version 13 requires JDK 21, as the comment in `pom.xml` says.
- **Unpinned tools.** The Droid CLI, the `droid-control` plugin (`.factory/settings.json`) and the major-version GitHub Action tags move without a change in the repository.
- **Java versions differ.** CI uses Temurin 17, the dev container Java 21 and Gitpod Java 17.0.7.
- Everything managed by the Spring Boot parent follows Spring Boot 4.1.2. `docs/DEPENDENCIES.md` was last reviewed on 2026-11-13; whether a newer 4.1.x release exists is not checked here.

## Related pages

- [Security](../security.md): what the advisories and the open Actuator endpoints mean for the application.
- [How to monitor](../how-to-monitor.md): reading the SBOM at `/actuator/sbom`.
- [Configuration](configuration.md): build properties and plugin settings.
- [By the numbers](../by-the-numbers.md): size and activity figures for the repository.

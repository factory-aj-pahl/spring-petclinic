# Configuration

PetClinic is configured by three property files in `src/main/resources/`, a handful of environment variables for the database profiles, and Spring Boot defaults for everything else. This page lists every property the repository sets, the defaults it depends on, the Kubernetes overrides, and the build and test settings.

## Overview

| Layer | Where | Covered below |
| --- | --- | --- |
| Application properties | `src/main/resources/application.properties` | [Default properties](#default-properties) |
| Profiles | `src/main/resources/application-mysql.properties`, `src/main/resources/application-postgres.properties` | [Profiles](#profiles) |
| Environment variables | Read by the profile files, Kubernetes, Compose, JMeter and CI | [Environment variables](#environment-variables) |
| Spring Boot defaults | Not set anywhere in the repository | [Defaults the application relies on](#defaults-the-application-relies-on) |
| Kubernetes | `k8s/petclinic.yml` | [Kubernetes settings](#kubernetes-settings) |
| Build | `pom.xml`, `build.gradle` | [Build-time configuration](#build-time-configuration) |
| Tests | Annotations in `src/test/java/` | [Test-only configuration](#test-only-configuration) |

These are the only `application*` files in the repository; there is no `application.yml`, and there is no `src/test/resources/` directory. `src/main/resources/banner.txt` is the startup banner.

## Default properties

`src/main/resources/application.properties`, active in every run:

| Property | Value | Effect |
| --- | --- | --- |
| `database` | `h2` | Custom property (not a Spring Boot one). It only fills the `${database}` placeholder in the two script locations below. |
| `spring.sql.init.schema-locations` | `classpath*:db/${database}/schema.sql` | Schema script for the chosen database. |
| `spring.sql.init.data-locations` | `classpath*:db/${database}/data.sql` | Seed data script for the chosen database. |
| `spring.thymeleaf.mode` | `HTML` | Thymeleaf template mode. `HTML` is already the Spring Boot 4.1.2 default, so this line changes nothing. |
| `spring.jpa.hibernate.ddl-auto` | `none` | Hibernate never creates or alters tables. |
| `spring.jpa.open-in-view` | `false` | No persistence context during view rendering (the default is `true`). |
| `spring.jpa.hibernate.naming.physical-strategy` | `org.hibernate.boot.model.naming.PhysicalNamingStrategySnakeCaseImpl` | `firstName` maps to `first_name` and so on. |
| `spring.jpa.properties.hibernate.default_batch_fetch_size` | `16` | Eager collections are loaded for up to 16 parents per query. |
| `spring.messages.basename` | `messages/messages` | Message bundles in `src/main/resources/messages/` (the default would be `messages`). |
| `management.endpoints.web.exposure.include` | `*` | Every Actuator endpoint is exposed over HTTP without authentication (follow-up F1). The file's own comment says not to do this in production. The default is `health` only. |
| `logging.level.org.springframework` | `INFO` | Spring log level. Two commented-out lines show `DEBUG` for `org.springframework.web` and `TRACE` for `org.springframework.context.annotation`. |
| `spring.web.resources.cache.cachecontrol.max-age` | `12h` | `Cache-Control: max-age` for static resources and webjars. Spring Boot sets no header by default. |

What the JPA settings mean for entity code is explained on [Persistence](../systems/persistence.md#jpa-settings).

## Profiles

Two profiles exist. Without a profile the application uses an in-memory H2 database that Spring Boot creates because no `spring.datasource.url` is set.

| Property | `mysql` (`src/main/resources/application-mysql.properties`) | `postgres` (`src/main/resources/application-postgres.properties`) |
| --- | --- | --- |
| `database` | `mysql` | `postgres` |
| `spring.datasource.url` | `${MYSQL_URL:jdbc:mysql://localhost/petclinic}` | `${POSTGRES_URL:jdbc:postgresql://localhost/petclinic}` |
| `spring.datasource.username` | `${MYSQL_USER:...}` | `${POSTGRES_USER:...}` |
| `spring.datasource.password` | `${MYSQL_PASS:...}` | `${POSTGRES_PASS:...}` |
| `spring.sql.init.mode` | `always` | `always` |

The username and password defaults are local development values written in the two files; this wiki does not repeat the password. `spring.sql.init.mode=always` runs the scripts at every start against a non-embedded database; the files note that the SQL is idempotent. Activate a profile with `--spring.profiles.active=mysql` or `SPRING_PROFILES_ACTIVE=postgres`. [Getting started](../overview/getting-started.md#use-mysql-or-postgresql) has the commands.

## Environment variables

Names and defaults only. Secret values are never shown here.

| Variable | Read by | Default | Purpose |
| --- | --- | --- | --- |
| `MYSQL_URL` | `src/main/resources/application-mysql.properties` | `jdbc:mysql://localhost/petclinic` | JDBC URL for the `mysql` profile |
| `MYSQL_USER` | same | set in the file | Database user |
| `MYSQL_PASS` | same | set in the file (local development value) | Database password |
| `POSTGRES_URL` | `src/main/resources/application-postgres.properties` | `jdbc:postgresql://localhost/petclinic` | JDBC URL for the `postgres` profile |
| `POSTGRES_USER` | same | set in the file | Database user |
| `POSTGRES_PASS` | same | set in the file (local development value) | Database password |
| `SPRING_PROFILES_ACTIVE` | Spring Boot | none | `k8s/petclinic.yml` sets `postgres` |
| `SERVICE_BINDING_ROOT` | Spring Cloud Bindings, if the image contains it | none | `k8s/petclinic.yml` sets `/bindings`; see [Kubernetes settings](#kubernetes-settings) |
| `SPRING_APPLICATION_JSON` | Spring Boot | none | `k8s/petclinic.yml` passes one property as JSON |
| `PETCLINIC_HOST`, `PETCLINIC_PORT` | `src/test/jmeter/petclinic_test_plan.jmx` | `localhost`, `8080` (per `docs/DEPENDENCIES.md`) | Target of the JMeter load test |
| `FACTORY_API_KEY` | `.github/workflows/qa.yml`, `.github/workflows/droid-wiki-refresh.yml` | none (GitHub secret) | Droid CLI in CI |
| `FACTORY_WIKI_PR_TOKEN` | `.github/workflows/droid-wiki-refresh.yml` | none (GitHub secret) | Opens the rolling wiki pull request |

`docker-compose.yml` sets container variables for its two services: `MYSQL_USER`, `MYSQL_PASSWORD`, `MYSQL_DATABASE`, `MYSQL_ROOT_PASSWORD` (empty) and `MYSQL_ALLOW_EMPTY_PASSWORD=true` for `mysql`, and `POSTGRES_USER`, `POSTGRES_PASSWORD` and `POSTGRES_DB` for `postgres`. These configure the database containers, not the application. The `mysql` service also mounts `./conf.d` read-only at `/etc/mysql/conf.d`, but no `conf.d` directory is tracked in the repository (follow-up F7 in `docs/RUNBOOK.md`).

## Defaults the application relies on

Spring Boot 4.1.2 defaults that shape behaviour, taken from the configuration metadata in the Spring Boot 4.1.2 jars. None of these is set in `src/main/resources/`.

| Property | Default | Why it matters |
| --- | --- | --- |
| `server.port` | `8080` | The port in every run and in `k8s/petclinic.yml` |
| `spring.web.error.include-message` | `never` | The error page and JSON error body hide exception messages. In Spring Boot 4 the old `server.error.*` names are deprecated with level `error` and replaced by `spring.web.error.*`. |
| `spring.web.error.include-stacktrace` | `never` | No stack traces in responses |
| `spring.web.error.include-exception` | `false` | No exception class name in responses |
| `spring.web.error.include-binding-errors` | `never` | No binding errors in the JSON error body |
| `spring.web.error.include-path` | `always` | The JSON error body has `path` |
| `spring.web.error.path` | `/error` | Error controller path |
| `spring.mvc.problemdetails.enabled` | `false` | Errors are not RFC 9457 problem details |
| `spring.cache.type` | not set | Spring Boot detects Caffeine on the classpath and uses it |
| `spring.cache.caffeine.spec` | not set | The `vets` cache has no maximum size and no expiry. Since commit `0e8563f` only existing pages reach the cached `findAll(Pageable)`, so the cache stays small; a size limit here would also bound any future cached query (F15). See [Caching](../systems/caching.md). |
| `spring.sql.init.mode` | `embedded` | Without a profile the scripts run because H2 is embedded |
| `spring.datasource.hikari.*` | not set | HikariCP defaults, including a 30-second connection timeout |
| `management.endpoint.health.probes.add-additional-paths` | `false` | `/livez` and `/readyz` exist only when this is turned on, as `k8s/petclinic.yml` does |

[Error handling](../features/error-handling.md) shows what the error defaults produce, and [How to monitor](../how-to-monitor.md) covers the Actuator endpoints.

## Kubernetes settings

`k8s/petclinic.yml` configures the container `workload` (image `dsyer/petclinic`, no tag) only through environment variables and a mounted Secret:

| Setting | Value | Effect |
| --- | --- | --- |
| `SPRING_PROFILES_ACTIVE` | `postgres` | Uses `src/main/resources/application-postgres.properties` |
| `SERVICE_BINDING_ROOT` | `/bindings` | Where service binding credentials are read from |
| Volume mount | Secret `demo-db` projected at `/bindings/secret`, read-only | The PostgreSQL connection details from `k8s/db.yml` (Secret type `servicebinding.io/postgresql`) |
| `SPRING_APPLICATION_JSON` | `{"management.endpoint.health.probes.add-additional-paths": true}` | Adds `/livez` and `/readyz` on the main port |
| `livenessProbe` | HTTP GET `/livez` on port `http` (8080) | Restarts the pod when liveness fails |
| `readinessProbe` | HTTP GET `/readyz` on port `http` | Readiness does not include the database (F2) |
| Service | `NodePort`, port 80 to target port 8080 | |

Spring Boot does not read `/bindings` by itself; `docs/DEPENDENCIES.md` marks this as Inferred to work only if the buildpack image contains Spring Cloud Bindings. The `POSTGRES_URL` and related variables are not set in the manifest. [Deployment](../deployment.md) covers the manifests and the kind workflow.

## Build-time configuration

### Maven

Properties in `pom.xml`:

| Property | Value | Used for |
| --- | --- | --- |
| Parent `spring-boot-starter-parent` | `4.1.2` | Manages most library and plugin versions |
| `java.version` | `17` | Compiler level; `maven-enforcer-plugin` requires at least this JDK |
| `project.build.sourceEncoding`, `project.reporting.outputEncoding` | `UTF-8` | Encodings, also written into build info |
| `project.build.outputTimestamp` | `2024-11-28T14:37:52Z` | Reproducible builds |
| `webjars-locator.version` | `1.1.3` | `webjars-locator-lite` |
| `webjars-bootstrap.version` | `5.3.8` | Bootstrap webjar and the `css` profile include path |
| `webjars-font-awesome.version` | `4.7.0` | Font Awesome webjar |
| `checkstyle.version` | `12.3.1` | Kept on 12 because Checkstyle 13 needs JDK 21 (comment in `pom.xml`) |
| `jacoco.version` | `0.8.15` | Coverage |
| `libsass.version` | `0.3.4` | `css` profile |
| `lifecycle-mapping` | `1.0.0` | Eclipse `m2e` profile |
| `maven-checkstyle.version` | `3.6.0` | Checkstyle plugin |
| `nohttp-checkstyle.version` | `0.0.11` | nohttp rule |
| `spring-format.version` | `0.0.47` | spring-javaformat |

Plugin configuration that changes the build:

- `spring-javaformat-maven-plugin` and `maven-checkstyle-plugin` (configuration `src/checkstyle/nohttp-checkstyle.xml`, suppressions `src/checkstyle/nohttp-checkstyle-suppressions.xml`) run in the `validate` phase. The nohttp scan covers `${basedir}` except `.git`, `.idea`, `target`, `.flattened-pom.xml`, class files and `qa-results`.
- `spring-boot-maven-plugin` runs `build-info` with extra properties `encoding.source`, `encoding.reporting`, `java.source` and `java.target`.
- `git-commit-id-maven-plugin` with `failOnNoGitDirectory=false` and `failOnUnableToExtractRepoInfo=false`, so a build outside a Git checkout still works.
- `cyclonedx-maven-plugin` writes the SBOM for `/actuator/sbom`; `jacoco-maven-plugin` reports in `prepare-package`; `native-maven-plugin` is declared for GraalVM builds.

Profiles in `pom.xml`:

| Profile | Activation | What it does |
| --- | --- | --- |
| `css` | `-P css`, for example `./mvnw package -P css` | Unpacks the Bootstrap webjar into `target/webjars` and compiles `src/main/scss/` into `src/main/resources/static/resources/css/` with `libsass-maven-plugin` in `generate-resources` |
| `m2e` | Automatic when the `m2e.version` property exists (Eclipse) | Lifecycle mapping for Eclipse only; no effect on the Maven build |

### Gradle

`build.gradle` mirrors the Maven versions: Spring Boot plugin `4.1.2`, `io.spring.dependency-management` `1.1.7`, `org.graalvm.buildtools.native` `1.1.2`, `org.cyclonedx.bom` `3.2.4`, `io.spring.javaformat` `0.0.47`, `io.spring.nohttp` `0.0.11`, Java toolchain 17, and `ext` values `checkstyleVersion = "12.3.1"`, `springJavaformatCheckstyleVersion = "0.0.47"`, `webjarsLocatorLiteVersion = "1.1.3"`, `webjarsFontawesomeVersion = "4.7.0"`, `webjarsBootstrapVersion = "5.3.8"`. It excludes `qa-results/**` from nohttp, skips test configurations in the CycloneDX BOM, and disables the format and Checkstyle tasks for AOT sources.

Differences from Maven, read from the two files:

- No `css` equivalent. `README.md` says so: CSS can be recompiled only with Maven.
- No JaCoCo and no enforcer rule.
- No git-commit-id plugin and no `springBoot { buildInfo() }` block, so a Gradle jar presumably has no `git.properties` or `build-info.properties` and `/actuator/info` would be empty. This is inferred from `build.gradle` and not checked at runtime.
- Actuator is `runtimeOnly` and there are fewer test starters (follow-up F11; see [Dependencies](dependencies.md)).

Wrapper versions: Maven 3.9.16 in `.mvn/wrapper/maven-wrapper.properties`, Gradle 9.5.1 in `gradle/wrapper/gradle-wrapper.properties`. [Tooling](../how-to-contribute/tooling.md) describes the build tools and checks.

## Test-only configuration

There are no test property files; tests set properties in annotations or command-line arguments.

| Test | Settings |
| --- | --- |
| `src/test/java/org/springframework/samples/petclinic/PetClinicIntegrationTests.java` | `logging.level.sql=DEBUG`; its `main` method runs with `--spring.docker.compose.lifecycle-management=NONE` |
| `src/test/java/org/springframework/samples/petclinic/MySqlIntegrationTests.java` | Profile `mysql`; Testcontainers `mysql:9.7` with `@ServiceConnection`, which replaces the datasource settings |
| `src/test/java/org/springframework/samples/petclinic/MysqlTestApplication.java` | `--spring.profiles.active=mysql`, `--spring.docker.compose.enabled=false`, Testcontainers `mysql:9.7` |
| `src/test/java/org/springframework/samples/petclinic/PostgresIntegrationTests.java` | Profile `postgres`; `spring.docker.compose.skip.in-tests=false` and `spring.docker.compose.start.arguments=--force-recreate,--renew-anon-volumes,postgres`, so it starts the Compose service `postgres` |
| `src/test/java/org/springframework/samples/petclinic/PostgresOutageIntegrationTests.java` | Profile `postgres`; `spring.datasource.hikari.connection-timeout=2000`, `management.endpoint.health.probes.enabled=true`, `management.endpoint.health.probes.add-additional-paths=true`; `POSTGRES_URL` set through `@DynamicPropertySource` to a fixed host port of a `postgres:18.4` container |
| `src/test/java/org/springframework/samples/petclinic/DatabaseUnavailableAtStartupTests.java` | Per profile: `--spring.profiles.active=<profile>`, the URL variable pointed at an unused local port, `--server.port=0`, `--spring.docker.compose.enabled=false` |
| `src/test/java/org/springframework/samples/petclinic/system/CrashControllerIntegrationTests.java` | `spring.web.error.include-message=ALWAYS`, `management.endpoints.access.default=none` |

`spring-boot-docker-compose` is a test dependency only (`pom.xml`, `build.gradle`), so Compose support never starts with the packaged application. `src/test/java/org/springframework/samples/petclinic/service/ClinicServiceTests.java` has a commented-out `@TestPropertySource("/application-postgres.properties")`. [Testing](../how-to-contribute/testing.md) explains which tests need Docker.

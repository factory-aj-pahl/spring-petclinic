# HTTP API

PetClinic has no separate API module. Its machine-facing surface is one read-only resource, `/vets`, which returns the vet list as JSON or XML, plus the HTML form endpoints, Spring Boot's error responses and every Spring Boot Actuator endpoint. Nothing requires authentication.

## Overview

| Surface | Paths | Formats | Source |
| --- | --- | --- | --- |
| Vets resource | `GET /vets` | JSON, XML | `src/main/java/org/springframework/samples/petclinic/vet/VetController.java` |
| HTML pages and form posts | 17 routes under `/`, `/owners/**`, `/vets.html`, `/oups` | HTML, `application/x-www-form-urlencoded` posts | The controllers in `src/main/java/org/springframework/samples/petclinic/` |
| Error responses | `/error` (Spring Boot) | HTML or JSON | Spring Boot defaults; see [Error handling](features/error-handling.md) |
| Actuator | `/actuator/**`, and `/livez`, `/readyz` when enabled | Actuator JSON, CycloneDX JSON, plain text | `src/main/resources/application.properties` (`management.endpoints.web.exposure.include=*`) |

The full route table, with handlers and views, is in [Web layer](systems/web-layer.md#routes). This page covers what a client sends and gets back.

There is no Spring Security in `pom.xml` or `build.gradle`, so there are no logins, tokens, roles or CSRF tokens. Every route below, including the Actuator endpoints that can change state, is open to anyone who can reach port 8080. This is follow-up F1 in `docs/RUNBOOK.md`; [Security](security.md) discusses it.

## The vets resource

`GET /vets` is handled by `VetController.showResourcesVetList` in `src/main/java/org/springframework/samples/petclinic/vet/VetController.java`. It returns a `@ResponseBody Vets`, read through the cached `VetRepository.findAll()` ([Caching](systems/caching.md)). Spring MVC picks the format from the `Accept` header:

| `Accept` | Status | `Content-Type` | Writer |
| --- | --- | --- | --- |
| `application/json` | 200 | `application/json` | Jackson 3 (`tools.jackson.core:jackson-databind` 3.1.7) |
| `application/xml` | 200 | `application/xml` | JAXB (`jakarta.xml.bind-api` declared in `pom.xml`, `jaxb-runtime` 4.0.9 through `hibernate-core`) |
| A type neither can write, such as `text/csv` | 406 | none, empty body | Spring MVC content negotiation |
| No header, or `*/*` | Not confirmed | Not confirmed | Depends on converter order; no test or recorded run covers it |

The JSON case is tested by `src/test/java/org/springframework/samples/petclinic/vet/VetControllerTests.java`. The XML and 406 cases are checked only by QA flow A1 in `.factory/skills/qa-api/SKILL.md`. Send an explicit `Accept` header.

```bash
curl -H 'Accept: application/json' http://localhost:8080/vets
curl -H 'Accept: application/xml' http://localhost:8080/vets
curl -i -H 'Accept: text/csv' http://localhost:8080/vets    # 406
```

### Response shape

The types are `src/main/java/org/springframework/samples/petclinic/vet/Vets.java` (wrapper, `@XmlRootElement`, one `@XmlElement` getter `getVetList()`), `src/main/java/org/springframework/samples/petclinic/vet/Vet.java` (extends `Person`, which extends `BaseEntity`) and `src/main/java/org/springframework/samples/petclinic/vet/Specialty.java` (extends `NamedEntity`).

JSON. Jackson writes every public getter, so `BaseEntity.isNew()` appears as `new` and `Vet.getNrOfSpecialties()` as `nrOfSpecialties`. Specialties are sorted by name (`Vet.getSpecialties()`). Shortened from the local QA run (`api.txt` in the QA evidence) with the seed data:

```json
{
  "vetList": [
    {"firstName": "James", "id": 1, "lastName": "Carter", "new": false,
     "nrOfSpecialties": 0, "specialties": []},
    {"firstName": "Linda", "id": 3, "lastName": "Douglas", "new": false,
     "nrOfSpecialties": 2,
     "specialties": [{"id": 3, "name": "dentistry", "new": false},
                     {"id": 2, "name": "surgery", "new": false}]}
  ]
}
```

| JSON field | Type | Source |
| --- | --- | --- |
| `vetList` | array of vets | `Vets.getVetList()` |
| `id` | integer | `BaseEntity.getId()` in `src/main/java/org/springframework/samples/petclinic/model/BaseEntity.java` |
| `new` | boolean, always `false` for stored rows | `BaseEntity.isNew()` |
| `firstName`, `lastName` | string | `src/main/java/org/springframework/samples/petclinic/model/Person.java` |
| `specialties` | array of `{id, name, new}`, sorted by name | `Vet.getSpecialties()`, `NamedEntity.getName()` |
| `nrOfSpecialties` | integer | `Vet.getNrOfSpecialties()` |

XML. JAXB has different rules: the root is `<vets>`, each vet is a `<vetList>` element, and each specialty a `<specialties>` element. The recorded XML has `id`, `firstName`, `lastName` and `specialties` only; `new` and `nrOfSpecialties` are absent, and vets without specialties have no `<specialties>` element.

```xml
<vets>
  <vetList><id>1</id><firstName>James</firstName><lastName>Carter</lastName></vetList>
  <vetList><id>3</id><firstName>Linda</firstName><lastName>Douglas</lastName>
    <specialties><id>3</id><name>dentistry</name></specialties>
    <specialties><id>2</id><name>surgery</name></specialties></vetList>
</vets>
```

There are no query parameters, no paging and no filtering on `/vets`; it always returns the full list. `/vets.html?page=N` is the paged HTML page. [Vets](features/vets.md) explains the feature, including why `/vets` keeps answering during a database outage.

## Form posts

The forms post `application/x-www-form-urlencoded` bodies and answer with HTML. On success they redirect (302) with a flash message; on a validation error they return 200 with the form and messages. There are no CSRF tokens, so a plain `curl -d` works. `@InitBinder` in each form controller ignores `id` and `*.id`, so a client cannot choose or overwrite ids.

| Endpoint | Fields | Main rules | Details |
| --- | --- | --- | --- |
| `POST /owners/new`, `POST /owners/{ownerId}/edit` | `firstName`, `lastName`, `address`, `city`, `telephone` | Names required, at most 30 characters; `address` required, at most 255; `city` required, at most 80; `telephone` exactly 10 digits | [Owners](features/owners.md) |
| `POST /owners/{ownerId}/pets/new`, `POST /owners/{ownerId}/pets/{petId}/edit` | `name`, `birthDate` (`yyyy-MM-dd`), `type` (a pet type name such as `dog`) | Name required, at most 30, unique per owner; type required for new pets; birth date required and not in the future | [Pets](features/pets.md) |
| `POST /owners/{ownerId}/pets/{petId}/visits/new` | `date` (`yyyy-MM-dd`), `description` | Description required, at most 255; date after today | [Visits](features/visits.md) |

`type` is converted by `src/main/java/org/springframework/samples/petclinic/owner/PetTypeFormatter.java`, which matches the name against the pet types in the database. The field names come from the templates in `src/main/resources/templates/owners/createOrUpdateOwnerForm.html`, `src/main/resources/templates/pets/createOrUpdatePetForm.html` and `src/main/resources/templates/pets/createOrUpdateVisitForm.html`. The full validation table is in [Patterns and conventions](how-to-contribute/patterns-and-conventions.md).

```bash
curl -i -d 'firstName=Ada&lastName=Byron&address=1+Main+St&city=Madison&telephone=6085551234' \
  http://localhost:8080/owners/new     # 302 to /owners/{id}
```

## Errors

A client whose `Accept` header does not include `text/html` gets Spring Boot's JSON error body (`timestamp`, `status`, `error`, `path`; no `message`, `trace` or `exception`). The status codes for malformed numbers (400), unknown ids (500, F3) and unknown paths (404) are listed in [Error handling](features/error-handling.md#status-codes).

```bash
curl http://localhost:8080/owners/999999
# {"timestamp":"...","status":500,"error":"Internal Server Error","path":"/owners/999999"}
```

## Actuator endpoints

`src/main/resources/application.properties` sets `management.endpoints.web.exposure.include=*`, with the comment that this is for development and testing only. Every endpoint that Spring Boot 4.1.2 auto-configures with the jars in this build is therefore reachable over HTTP under `/actuator`. `GET /actuator` lists them with links. Responses use `application/vnd.spring-boot.actuator.v3+json`.

The list below comes from the endpoint classes in the jars of `target/spring-petclinic-4.0.0-SNAPSHOT.jar` and their conditions in the Spring Boot reference documentation ([Actuator endpoints](https://docs.spring.io/spring-boot/reference/actuator/endpoints.html)). "QA run" means the local QA run recorded the response (`api.txt` and `report.md` in the QA evidence for run 1794576862); "Test" means a test in `src/test/java` calls it.

| Endpoint | Purpose | Available here | Evidence |
| --- | --- | --- | --- |
| `health`, `health/liveness`, `health/readiness` | Status `UP` or `DOWN`, groups `liveness` and `readiness` | Yes | QA run (`{"groups":["liveness","readiness"],"status":"UP"}`); `PostgresOutageIntegrationTests` (503 during an outage) |
| `info` | Git branch and commit, build name, version and time | Yes | QA run |
| `sbom`, `sbom/application` | CycloneDX SBOM of the jar (`application/vnd.cyclonedx+json`) | Yes | QA run (107 components; unknown id gives 404) |
| `caches`, `caches/{name}` | Lists caches; `DELETE` clears them | Yes | `docs/DEPENDENCIES.md` records a live response; [Caching](systems/caching.md) |
| `metrics`, `metrics/{name}` | Micrometer meters | Yes | Inferred from `spring-boot-micrometer-metrics` in the jar; not called in any recorded run |
| `env` | Property sources and values (sensitive values masked by default) | Yes | Inferred from the jar; named in F1 |
| `beans` | All Spring beans | Yes | Inferred from the jar; named in F1 |
| `threaddump` | Thread dump | Yes | Inferred from the jar; named in F1 |
| `heapdump` | Downloads a heap dump file | Yes, inferred | `HeapDumpWebEndpoint` is in the jar; not called |
| `conditions` | Auto-configuration report | Yes, inferred | Not called |
| `configprops` | `@ConfigurationProperties` beans | Yes, inferred | Not called |
| `loggers`, `loggers/{name}` | Read and `POST` log levels at runtime | Yes, inferred | Not called |
| `mappings` | Every request mapping | Yes, inferred | Not called |
| `scheduledtasks` | Scheduled tasks (none in this code) | Yes, inferred | Not called |
| `shutdown` | Stops the application | No, disabled by default | QA run: `POST /actuator/shutdown` returns 404 |
| `httpexchanges` | Recent requests | No: needs an `HttpExchangeRepository` bean, and the code defines none | Inferred |
| `auditevents` | Audit events | No: needs an `AuditEventRepository` bean | Inferred |
| `startup` | Startup steps | No: needs a `BufferingApplicationStartup`, which `PetClinicApplication` does not set | Inferred |
| `logfile` | Log file contents | No: `logging.file.name` is not set | Inferred |
| `prometheus` | Prometheus scrape | No: `micrometer-registry-prometheus` is not in `pom.xml` or the SBOM | Inferred |

Only `health`, `info`, `sbom` and `shutdown` were checked against a running application. The rows marked "inferred" follow from the jar contents and the documented conditions but were not called. Some endpoints change state: `DELETE /actuator/caches/vets` clears the cache, `POST /actuator/loggers/{name}` changes a log level, and `heapdump` writes and returns the process memory, which can contain any data the application holds.

```bash
curl http://localhost:8080/actuator
curl http://localhost:8080/actuator/health
curl http://localhost:8080/actuator/info
curl http://localhost:8080/actuator/sbom/application
curl http://localhost:8080/actuator/metrics/http.server.requests
```

The Gradle build declares Actuator as `runtimeOnly` (`build.gradle`, F11). It still runs, but the Gradle build has no git-commit-id plugin or `buildInfo` task, so `info` from a Gradle-built jar probably lacks the git and build sections (inferred, not checked).

### Kubernetes probe paths

`/livez` and `/readyz` are extra root-level paths for the liveness and readiness groups. They exist only with `management.endpoint.health.probes.add-additional-paths=true`. `src/main/resources/application.properties` does not set it, so a local run returns 404 for both (`docs/RUNBOOK.md`, health checks). `k8s/petclinic.yml` sets it through `SPRING_APPLICATION_JSON`, and `src/test/java/org/springframework/samples/petclinic/PostgresOutageIntegrationTests.java` sets it as a test property. Readiness does not include the database (F2). [How to monitor](how-to-monitor.md) explains what each health path reports, and [Deployment](deployment.md) shows how the probes are wired.

## Related pages

- [Web layer](systems/web-layer.md): every route and content negotiation.
- [Error handling](features/error-handling.md): error page, status codes and JSON error body.
- [How to monitor](how-to-monitor.md): health, info, metrics and logs in operation.
- [Security](security.md): what the open Actuator exposure means.

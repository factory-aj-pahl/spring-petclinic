# How to monitor

PetClinic writes its log to standard output and reports its state through Spring Boot Actuator: health with liveness and readiness groups, build and git info, Micrometer metrics, the SBOM and the caches. There is no metrics backend, no tracing and no alerting in the repository; everything is pulled from the Actuator endpoints.

## Overview

| Signal | Where | Configured in |
| --- | --- | --- |
| Logs | Standard output, Spring Boot's default console format | `src/main/resources/application.properties` (`logging.level.org.springframework=INFO`) |
| Health | `/actuator/health`, `/actuator/health/liveness`, `/actuator/health/readiness`; `/livez`, `/readyz` in Kubernetes | Spring Boot defaults; `k8s/petclinic.yml` |
| Build identity | `/actuator/info` | `git-commit-id-maven-plugin` and the `build-info` goal in `pom.xml` |
| Metrics | `/actuator/metrics` | Micrometer through `spring-boot-starter-actuator` |
| Dependencies | `/actuator/sbom/application` | `cyclonedx-maven-plugin` in `pom.xml` |
| Cache | `/actuator/caches` | Spring Boot cache auto-configuration |
| Traces | None | No tracing dependency |
| Alerts | None | Nothing in the repository |

All Actuator endpoints are exposed without authentication (`management.endpoints.web.exposure.include=*`, follow-up F1). The full endpoint list, with which ones were confirmed, is in [HTTP API](api.md#actuator-endpoints).

## Logging

Spring Boot logs through Logback (`logback-classic` 1.5.38 in `target/classes/META-INF/sbom/application.cdx.json`). There is no `logback.xml` or `logback-spring.xml` in `src/main/resources/` and no `logging.file.name`, so the log goes only to the console in Spring Boot's default pattern. A line from the local QA run's server log:

```text
2026-11-13T13:35:04.183Z  WARN 48245 --- [nio-8080-exec-3] .w.s.m.s.DefaultHandlerExceptionResolver : Resolved [org.springframework.web.HttpMediaTypeNotAcceptableException: No acceptable representation]
```

The fields are timestamp, level, process id, thread, abbreviated logger name and message. The start of the log is the ASCII-art banner from `src/main/resources/banner.txt` followed by "Built with Spring Boot :: 4.1.2".

Levels: the root level is Spring Boot's default `INFO`, and `src/main/resources/application.properties` sets `logging.level.org.springframework=INFO` explicitly, with commented-out lines for `org.springframework.web=DEBUG` and `org.springframework.context.annotation=TRACE`. The application code has no loggers of its own, so everything in the log comes from Spring, Hibernate, HikariCP and Tomcat. Change a level without a restart with `POST /actuator/loggers/{name}` (body `{"configuredLevel":"DEBUG"}`), or at start with `--logging.level.org.springframework.web=DEBUG`.

Errors: an unhandled exception (HTTP 500) is one `ERROR` entry from Tomcat's dispatcher servlet logger with the full stack trace; a 400 or 406 resolved by Spring MVC is one `WARN` line from `DefaultHandlerExceptionResolver`. [Error handling](features/error-handling.md#where-the-details-go) shows both. Successful requests are not logged; there is no access log (`server.tomcat.accesslog.*` is not set).

In Kubernetes the container writes to standard output, so `kubectl logs deployment/petclinic` shows the log, and whatever log collector the cluster runs picks it up. Nothing in `k8s/` configures log shipping. The format is plain text, not JSON; Spring Boot's structured logging (`logging.structured.format.console`) is not enabled.

## Health

| Path | Contents | When it is not 200 |
| --- | --- | --- |
| `/actuator/health` | `{"status":"UP","groups":["liveness","readiness"]}`; details are hidden (`show-details` defaults to `never`) | 503 `DOWN` when any contributor is down, for example the database (`db`) |
| `/actuator/health/liveness` | `livenessState` | Only if Spring Boot marks the application broken |
| `/actuator/health/readiness` | `readinessState` | During startup and shutdown |
| `/livez`, `/readyz` | The same two groups at the root | 404 unless `management.endpoint.health.probes.add-additional-paths=true`, which `k8s/petclinic.yml` sets |

The groups and the `UP` responses were recorded by the local QA run (flow A2 in `.factory/skills/qa-api/SKILL.md`). The overall health includes Spring Boot's auto-configured contributors; the `db` contributor (`DataSourceHealthContributorAutoConfiguration` in `spring-boot-jdbc`) is the one that matters here. The others, such as disk space and ping, follow Spring Boot's defaults and were not listed because details are hidden.

The readiness group does not include the database (F2). `src/test/java/org/springframework/samples/petclinic/PostgresOutageIntegrationTests.java` stops PostgreSQL under a running application and checks:

| Check | During the outage | After the database is back |
| --- | --- | --- |
| `/actuator/health` | 503 | 200 within 60 seconds, without a restart |
| `/livez` | 200 | 200 |
| `/readyz` | 200 | 200 |
| `/owners/1` (needs the database) | 500 error page | 200 |
| `/vets` (cached) | 200 | 200 |

So a Kubernetes readiness probe on `/readyz` keeps the pod in service while most pages fail. Monitor `/actuator/health` separately to see a database outage. To see the details while debugging, start with `--management.endpoint.health.show-details=always`.

## Info

`/actuator/info` reports the git commit and the build. From the QA run:

```json
{"git": {"branch": "security/spring-boot-4.1.2-cve-remediation",
         "commit": {"id": "f9bbb32", "time": "2026-11-13T04:22:51Z"}},
 "build": {"artifact": "spring-petclinic", "name": "petclinic", "version": "4.0.0-SNAPSHOT",
           "group": "org.springframework.samples", "time": "2024-11-28T14:37:52Z",
           "java": {"source": "17", "target": "17"},
           "encoding": {"source": "UTF-8", "reporting": "UTF-8"}}}
```

`git` comes from `BOOT-INF/classes/git.properties` (`git-commit-id-maven-plugin`); Spring Boot's default `simple` mode shows only branch, commit id and time. The file holds more, including committer identity fields, which `management.info.git.mode=full` would expose. `build` comes from `META-INF/build-info.properties`. `build.time` is always the fixed `project.build.outputTimestamp` from `pom.xml`, so use `git.commit.id` to tell which code is running. A Gradle-built jar probably has neither section ([Deployment](deployment.md#build-artifacts)).

## Metrics

`spring-boot-starter-actuator` brings `spring-boot-starter-micrometer-metrics`, Micrometer 1.17.2 (`micrometer-core`, `micrometer-observation`, `micrometer-jakarta9`) and `spring-boot-micrometer-metrics` 4.1.2 (all in the SBOM). No registry for an external system is on the classpath: `pom.xml` and the SBOM (`target/classes/META-INF/sbom/application.cdx.json`, and the copy in the final evidence) have no `micrometer-registry-*` artifact, so there is no Prometheus, OTLP or other export. The `PrometheusScrapeEndpoint` class is in the jar, but the endpoint stays off without the Prometheus registry. Metrics are held in Spring Boot's in-memory simple registry and are available only through the Actuator endpoint:

```bash
curl http://localhost:8080/actuator/metrics
curl http://localhost:8080/actuator/metrics/http.server.requests
curl 'http://localhost:8080/actuator/metrics/http.server.requests?tag=status:500'
curl http://localhost:8080/actuator/metrics/hikaricp.connections.active
```

Which meters exist was not checked against a running application. Based on the jars and the Spring Boot documentation, expect JVM memory, GC and threads, process CPU and uptime, `http.server.requests` (by `uri`, `method`, `status`, `outcome`), Tomcat sessions, HikariCP pool meters (`DataSourcePoolMetricsAutoConfiguration` in `spring-boot-jdbc`), logback event counts and `cache.*` meters for the `vets` cache. The cache meters report no real hits or misses, because Caffeine records statistics only with `recordStats`, which is not configured ([Caching](systems/caching.md)). The simple registry keeps cumulative values per process, so a restart resets them, and there is no history.

To send metrics to a monitoring system, add a registry such as `io.micrometer:micrometer-registry-prometheus` to both `pom.xml` and `build.gradle`, and record it in `docs/DEPENDENCIES.md`. This is a suggestion; nothing in the repository plans it.

## SBOM

`/actuator/sbom` lists `{"ids":["application"]}`, and `/actuator/sbom/application` returns the CycloneDX 1.6 SBOM packed into the jar at `META-INF/sbom/application.cdx.json` (107 components in the QA run). Use it to check which library versions a running instance ships, for example after a Dependabot upgrade:

```bash
curl -s http://localhost:8080/actuator/sbom/application | grep -o '"purl" : "pkg:maven/org.apache.tomcat.embed/tomcat-embed-core@[^"]*"'
```

`docs/RUNBOOK.md` shows how to scan the same file with OSV-Scanner. [Dependencies](reference/dependencies.md) summarizes the versions.

## Caches

`/actuator/caches` shows the `CaffeineCacheManager` and, after the first vets request, the `vets` cache; `DELETE /actuator/caches/vets` clears it. The cache has no size limit. Since commit `0e8563f`, `/vets.html` checks the page range before its cached query, so the cache holds the full vet list plus one entry per existing page; before that, every distinct `/vets.html?page=` value added an entry (F15). Watch `jvm.memory.used` for the heap. [Caching](systems/caching.md) has the details.

## Tracing

There is none. No `micrometer-tracing`, OpenTelemetry, Brave or Zipkin artifact is in `pom.xml`, `build.gradle` or the SBOM. `micrometer-observation` is present, so Spring creates observations for requests, but without a tracer they produce only metrics. Log lines carry no trace or span ids.

## Alerting

The repository has no alert rules, dashboards or on-call configuration. The QA workflow (`.github/workflows/qa.yml`) and the OSV-Scanner workflow (`.github/workflows/osv-scanner.yml`) report on pull requests and pushes, not on a running instance.

Suggested alerts, not implemented anywhere:

| Alert on | Source | Why |
| --- | --- | --- |
| `/actuator/health` not 200 | HTTP check | The only signal for a database outage, because readiness stays 200 (F2) |
| Pod restarts | Kubernetes | Startup fails fast when the database is unreachable at start |
| Rate of `http.server.requests` with `status` 500 | Metrics, after adding a registry | Unknown ids also give 500 (F3), so expect a baseline above zero |
| Many `ERROR` log entries from the dispatcher servlet | Logs | Same failures, without a metrics backend |
| Heap use growing steadily | `jvm.memory.used` | A leak. Check `/actuator/caches` first: the `vets` cache has no size limit, and before `0e8563f` every page number requested added an entry (F15) |
| HikariCP pending connections or connection timeouts | `hikaricp.connections.pending`, logs | Database slowness before it becomes an outage |
| Requests to `/actuator/env`, `/actuator/heapdump` or `DELETE /actuator/caches` from outside | Ingress or proxy logs | Open Actuator endpoints (F1) |

## Related pages

- [Error handling](features/error-handling.md): what a 5xx looks like in the log and in the response.
- [Debugging](how-to-contribute/debugging.md): troubleshooting with these signals.
- [Deployment](deployment.md): probes and the Kubernetes setup.
- [Configuration](reference/configuration.md): logging and management properties.

# Deployment

PetClinic ships as one executable jar, or as a container image built from that jar with Cloud Native Buildpacks. The repository has a Docker Compose file for development databases and two Kubernetes manifests, but no production deployment pipeline: the only deploy in CI is a smoke test on a throwaway kind cluster, and it runs a prebuilt Docker Hub image rather than the code under review.

## Overview

```mermaid
graph LR
    SRC[Source on a branch] -->|"./mvnw verify"| JAR[Executable jar with SBOM and git info]
    JAR -->|"java -jar"| LOCAL[Local process, H2 or a Compose database]
    SRC -->|"./mvnw spring-boot:build-image"| IMG[Local OCI image]
    HUB[Docker Hub image dsyer/petclinic] -->|"image: in k8s/petclinic.yml"| POD[petclinic pod]
    SEC[Secret demo-db] -->|"mounted at /bindings/secret"| POD
    POD -->|"JDBC to Service demo-db"| DB[demo-db pod, postgres:18.4]
    CI[deploy-and-test-cluster.yml] -->|"kubectl apply -f k8s/"| POD
```

The image built from the source never reaches the cluster: nothing in the repository tags, pushes or deploys it. That gap is follow-up F4.

## Build artifacts

| Artifact | How to build | Contents |
| --- | --- | --- |
| `target/spring-petclinic-4.0.0-SNAPSHOT.jar` | `./mvnw verify` or `./mvnw package` | Spring Boot executable jar (`Main-Class: org.springframework.boot.loader.launch.JarLauncher`, `Start-Class: org.springframework.samples.petclinic.PetClinicApplication`). Contains `META-INF/sbom/application.cdx.json` (CycloneDX, from `cyclonedx-maven-plugin`), `META-INF/build-info.properties` (from the `build-info` goal of `spring-boot-maven-plugin`) and `BOOT-INF/classes/git.properties` (from `git-commit-id-maven-plugin`). Layer index included. |
| Gradle jar | `./gradlew build` (writes to `build/libs/`) | Same application. `build.gradle` has the CycloneDX plugin but no git-properties plugin or `buildInfo`, so git and build info are probably missing (inferred). |
| Container image | `./mvnw spring-boot:build-image` (Gradle: `./gradlew bootBuildImage`) | OCI image built by Paketo buildpacks through the local Docker daemon. There is no Dockerfile for the application; `.devcontainer/Dockerfile` is the Gitpod development image. |
| Native image | GraalVM build tools (`native-maven-plugin` in `pom.xml`, `org.graalvm.buildtools.native` in `build.gradle`) | Supported by `PetClinicRuntimeHints`; no CI job builds it. |

`pom.xml` pins `project.build.outputTimestamp` to 2024-11-28T14:37:52Z for reproducible builds, so every file in the jar, and `build.time` in `/actuator/info`, shows that date instead of the real build time. Use the git commit in `/actuator/info` to identify a build.

Nothing in the repository publishes the jar or the image. `mvnw deploy`, `spring-boot.build-image.publish=true`, `docker push` and Gradle `publish*` tasks are blocked for Droid by `.factory/hooks/guard_release_actions.py` (see [Change control](#change-control)).

[Getting started](overview/getting-started.md) has the commands to run the jar and the image locally.

## Environments

| Environment | Database | Files | Purpose |
| --- | --- | --- | --- |
| Local, default | H2 in memory, rebuilt at each start | `src/main/resources/application.properties` | Development, tests, QA |
| Local with Compose | MySQL 9.7 or PostgreSQL 18.4 | `docker-compose.yml`, `src/main/resources/application-mysql.properties`, `src/main/resources/application-postgres.properties` | Development against a real database |
| Kubernetes | PostgreSQL 18.4 in a pod | `k8s/db.yml`, `k8s/petclinic.yml` | Demo and the CI smoke test |
| Dev containers | H2 | `.devcontainer/devcontainer.json`, `.gitpod.yml` | Development environments |

There is no staging or production configuration in the repository: no `application-prod.properties`, no Helm chart, no Terraform and no environment-specific manifests.

### Docker Compose

`docker-compose.yml` defines two services named after the Spring profiles, `mysql` (image `mysql:9.7`, port 3306) and `postgres` (image `postgres:18.4`, port 5432). Neither has a volume for data, and the application itself is not a Compose service; you start it with `./mvnw spring-boot:run -Dspring-boot.run.profiles=mysql` or `postgres`. The file has plain-text credentials and is for local development only. Known gaps: the `mysql` service mounts `./conf.d`, which is not in the repository (F7), and it allows an empty root password while publishing 3306 on all interfaces (F8).

### Kubernetes

| Object | File | Notes |
| --- | --- | --- |
| Secret `demo-db`, type `servicebinding.io/postgresql` | `k8s/db.yml` | Host, port, database name and plain-text credentials in the manifest |
| Deployment `demo-db` | `k8s/db.yml` | One `postgres:18.4` container, environment from the Secret, TCP liveness, readiness and startup probes on 5432. No volume, so data is lost when the pod restarts (F5). |
| Service `demo-db` | `k8s/db.yml` | ClusterIP on 5432 |
| Deployment `petclinic` | `k8s/petclinic.yml` | One replica of `dsyer/petclinic` with no tag (F4). Container port 8080, HTTP probes `/livez` and `/readyz` with default timings. No resource requests or limits. |
| Service `petclinic` | `k8s/petclinic.yml` | NodePort, port 80 to 8080 |

## How configuration reaches the application

- **Profiles.** No profile means H2. `spring.profiles.active=mysql` or `postgres` (or `SPRING_PROFILES_ACTIVE`) loads the matching properties file, which sets `database` and the datasource. `k8s/petclinic.yml` sets `SPRING_PROFILES_ACTIVE=postgres`.
- **Environment variables.** The profile files read `MYSQL_URL`, `MYSQL_USER`, `MYSQL_PASS` or `POSTGRES_URL`, `POSTGRES_USER`, `POSTGRES_PASS`, and fall back to a database named `petclinic` on `localhost`.
- **`SPRING_APPLICATION_JSON`.** `k8s/petclinic.yml` uses it to set `management.endpoint.health.probes.add-additional-paths=true`, which creates `/livez` and `/readyz`.
- **Service bindings.** `k8s/petclinic.yml` projects the `demo-db` Secret to `/bindings/secret` and sets `SERVICE_BINDING_ROOT=/bindings`. Spring Boot does not read bindings by itself. This works only because Paketo buildpacks add Spring Cloud Bindings to the image, which then maps the binding to `spring.datasource.*`. Neither build file declares Spring Cloud Bindings, so an image built another way ignores `/bindings` and tries `localhost` (F6, status "Inferred" in `docs/DEPENDENCIES.md`). Whether `dsyer/petclinic` was built with buildpacks is not known.

Every property is listed in [Configuration](reference/configuration.md).

## Probes and startup

`k8s/petclinic.yml` points the liveness probe at `/livez` and the readiness probe at `/readyz`. Both are backed by Spring Boot's availability state, not by the database: during a database outage they stay 200 while `/actuator/health` turns 503 (`src/test/java/org/springframework/samples/petclinic/PostgresOutageIntegrationTests.java`). Kubernetes therefore keeps routing traffic to a pod whose pages fail (F2). There is no startup probe, so a slow start relies on the default liveness timings (inferred; with the schema scripts and Hibernate start-up this was not measured in a cluster).

If the database is unreachable at startup, the application exits within seconds (`src/test/java/org/springframework/samples/petclinic/DatabaseUnavailableAtStartupTests.java`) and Kubernetes restarts the container until `demo-db` is up. With the `postgres` profile, `spring.sql.init.mode=always` runs `src/main/resources/db/postgres/schema.sql` and `src/main/resources/db/postgres/data.sql` at every start; the scripts are idempotent. [Persistence](systems/persistence.md) covers the database side and [How to monitor](how-to-monitor.md) the health endpoints.

## The CI deploy test

`.github/workflows/deploy-and-test-cluster.yml` runs on pushes and pull requests to `main` that change `k8s/**`. It creates a kind cluster with `helm/kind-action@v1`, runs `kubectl apply -f k8s/`, and waits up to 180 seconds each for the `demo-db` and `petclinic` pods to become ready. It does not build the repository, sends no HTTP request, and runs the untagged `dsyer/petclinic` image from Docker Hub. A pass shows that the manifests are valid and that some version of PetClinic starts against them, not that the code under review works in Kubernetes (F4). Changes to Java code do not trigger it.

## Known gaps

| ID | Gap | Where |
| --- | --- | --- |
| F4 | Untagged image of unknown provenance; CI tests that image, not the pull request | `k8s/petclinic.yml`, `.github/workflows/deploy-and-test-cluster.yml` |
| F5 | Plain-text database credentials in the manifest; no persistent volume | `k8s/db.yml` |
| F6 | Datasource in Kubernetes depends on Spring Cloud Bindings inside the image | `k8s/petclinic.yml` |
| F7 | `./conf.d` mount for MySQL is missing from the repository | `docker-compose.yml` |
| F8 | Empty MySQL root password allowed; ports 3306 and 5432 on all interfaces | `docker-compose.yml` |
| F2 | Readiness ignores the database | `k8s/petclinic.yml`, Spring Boot defaults |
| F1 | Every Actuator endpoint is exposed without authentication, also in the cluster | `src/main/resources/application.properties` |
| F22 | The cluster workflow has no `permissions:` block, so its token gets the repository default | `.github/workflows/deploy-and-test-cluster.yml` |

The Service `petclinic` is a NodePort with no Ingress or TLS, and there is one replica. Suggested fixes are in the follow-ups table of `docs/RUNBOOK.md`; [Pitfalls](background/pitfalls.md) collects them with the other known issues.

## Rollback

The runbook's [Roll back](../docs/RUNBOOK.md#roll-back) section covers code (revert the commit; `PatchedDependencyVersionsTests` fails on purpose if vulnerable versions come back), data (the Spring Boot 4.1.2 upgrade changed no scripts) and Kubernetes. For Kubernetes there is nothing to roll back to: the manifest uses the untagged `dsyer/petclinic` image, so there is no earlier tag (F4). On H2 every restart starts from the seed data, and on the `demo-db` pod data does not survive a restart either (F5).

## Change control

People deploy. `AGENTS.md` says agents push a feature branch and open a pull request, and must not merge or approve pull requests, push to `main`, force-push, push tags, publish releases, images or Maven artifacts, or change a Kubernetes cluster or Helm release.

For Droid, `.factory/hooks.json` runs `.factory/hooks/guard_release_actions.py` before every shell command. It exits with status 2, which blocks the command, when the text matches `gh pr merge`, an approving `gh pr review`, merge or branch-protection calls through `gh api`, `gh release create|delete|edit|upload`, `kubectl apply|create|delete|patch|scale|rollout restart` and similar, `helm install|upgrade|uninstall|rollback`, `docker push`, `docker buildx build --push`, `mvnw deploy`, `spring-boot.build-image.publish=true` and Gradle `publish` tasks. For `git push` it blocks force pushes, `--mirror`, `--all`, tag pushes and pushes to `main` or `master`. It matches command text, so it is a guardrail and not a security boundary; branch protection on `main` is still needed and could not be checked (F13). Its tests are in `.factory/hooks/test_guard_release_actions.py`. [Development workflow](how-to-contribute/development-workflow.md) describes the pull request process.

## Key files

| File | Purpose |
| --- | --- |
| `pom.xml` | Jar, SBOM, build info, git info, native and image plugins |
| `build.gradle` | Gradle equivalent, without git and build info |
| `docker-compose.yml` | MySQL and PostgreSQL for development |
| `k8s/db.yml` | PostgreSQL Deployment, Service and binding Secret |
| `k8s/petclinic.yml` | Application Deployment, NodePort Service, probes, bindings |
| `.github/workflows/deploy-and-test-cluster.yml` | kind smoke test |
| `docs/RUNBOOK.md` | Run, health, rollback, follow-ups |
| `.factory/hooks/guard_release_actions.py` | Blocks deploy and release commands for Droid |

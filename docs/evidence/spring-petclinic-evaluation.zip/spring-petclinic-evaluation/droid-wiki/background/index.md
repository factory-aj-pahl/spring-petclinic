# Background

This section explains why PetClinic is built the way it is and where it surprises people. It is for contributors who want to know the reason behind a rule before they change it, and for operators who need to know which behavior is intended and which is a known defect.

## What is here

| Page | What it covers |
| --- | --- |
| [Design decisions](design-decisions.md) | The decisions that shape the code, the build and the repository process, each with the reason that a commit, code comment or document gives, and what it costs today. It includes the decisions made on the branch `security/spring-boot-4.1.2-cve-remediation` on 2026-11-13. |
| [Pitfalls](pitfalls.md) | Traps a contributor or operator runs into, grouped by area: build and tests, database, web and paging, caching, translations, Actuator, Kubernetes and Compose, and agent tooling. Each entry names the evidence and what to do. |

## Why the section exists

Most of PetClinic's rules are short lines in `AGENTS.md` or `docs/RUNBOOK.md`, such as "keep Gradle in step with Maven" or "do not lower the version guard minimums". The reasons are spread over commit messages from 2013 to 2026, code comments and the runbook follow-ups F1 to F20. These pages collect them in one place and link back to the source, so a reader can check each statement.

## Related pages

- [Lore](../lore.md) tells the history era by era, from the 2009 Spring 3 sample to the 2026 security upgrade. The design decisions page links to it instead of retelling it.
- [Security](../security.md) covers trust boundaries, Actuator exposure, input handling, dependency advisories and the agent guardrails.
- [Cleanup opportunities](../cleanup-opportunities.md) lists code to remove or refactor. Pitfalls covers behavior, not cleanup.
- `docs/RUNBOOK.md` keeps the authoritative list of open follow-ups (F1 to F22).

# Pitfalls

These are the places where PetClinic behaves differently from what a contributor or operator expects. Each entry says what surprises people, where the evidence is, and what to do. Code that should be removed or refactored is on [Cleanup opportunities](../cleanup-opportunities.md) instead.

> `docs/RUNBOOK.md` keeps the authoritative list of follow-ups (F1 to F22) with their evidence and suggested changes. This page explains the traps behind them and adds others; when the two disagree, the runbook wins.

## Build and tests

| What surprises people | Evidence | What to do |
| --- | --- | --- |
| A build without Docker passes with fewer tests. 116 tests run with Docker. Without it, `MySqlIntegrationTests` shows as skipped, `PostgresIntegrationTests` is not counted at all, and `PostgresOutageIntegrationTests` should show as skipped (F9). | `@Testcontainers(disabledWithoutDocker = true)` on the MySQL and outage tests; `assumeTrue(DockerClientFactory.instance().isDockerAvailable(), ...)` in a `@BeforeAll` of `src/test/java/org/springframework/samples/petclinic/PostgresIntegrationTests.java`; `docs/RUNBOOK.md` "Build and test". | Check the test count. `AGENTS.md` asks you to report skipped tests as skipped, not as passed. [Testing](../how-to-contribute/testing.md) explains each Docker-based test. |
| The nohttp check fails on files you never committed. It scans every file in the working tree, untracked ones and Markdown included, except build output, `.git/`, `.idea/` and `qa-results/`. | `pom.xml` Checkstyle `excludes`, `src/checkstyle/nohttp-checkstyle-suppressions.xml`, `docs/RUNBOOK.md` "Build and test". | Use `https://` links, or `http://localhost`. Keep scratch notes outside the repository. |
| Any test with the `mysql` profile talks to a Testcontainers MySQL, not to the URL you configured (F10). | `src/test/java/org/springframework/samples/petclinic/MysqlTestApplication.java` is a `@Configuration` with a `@Profile("mysql")` `@ServiceConnection` container bean. `DatabaseUnavailableAtStartupTests` has to exclude it. | Exclude it with a `TypeExcludeFilter` as `DatabaseUnavailableAtStartupTests` does, until the bean moves to an explicit `@TestConfiguration`. |
| Running `PostgresIntegrationTests` replaces the Compose `postgres` container, so data you entered in it locally is likely lost. | The test starts Compose with `--force-recreate,--renew-anon-volumes`, and the `postgres` service in `docker-compose.yml` has no named volume (inferred from both files; not run). | Use a separate database for data you want to keep. |
| A dependency change or a revert fails the build in `PatchedDependencyVersionsTests`. | It fails when a library resolves below its first patched version. `docs/RUNBOOK.md` "Roll back" says the revert fails on purpose. | Upgrade, usually Spring Boot. Lower a minimum only with a recorded risk acceptance; `AGENTS.md` forbids lowering it to get another change through. |
| Maven and Gradle builds are not equivalent (F11). Gradle puts Actuator in `runtimeOnly`, has fewer test starters, no JaCoCo, no git or build info, and no CSS profile. | `build.gradle`, `pom.xml`, `README.md` "Compiling the CSS". | Treat Maven as the reference build. Change versions in both files (`AGENTS.md`). |
| Error page properties found in older guides do nothing. Spring Boot 4 names them `spring.web.error.*`. | `src/test/java/org/springframework/samples/petclinic/system/CrashControllerIntegrationTests.java` sets `spring.web.error.include-message=ALWAYS`. | Use the `spring.web.error.*` names. [Configuration](../reference/configuration.md) lists the properties in use. |
| The build fails in `validate` before any test runs. | `spring-javaformat:validate` runs in that phase (`AGENTS.md`). | Run `./mvnw spring-javaformat:apply` before committing. |
| The Maven, Gradle and cluster workflows run with the repository's default `GITHUB_TOKEN` permissions (F22). | No `permissions:` block in `.github/workflows/maven-build.yml`, `.github/workflows/gradle-build.yml` and `.github/workflows/deploy-and-test-cluster.yml`. | Check the repository's default token permissions until the owner decides on F22; the suggested change is `permissions: contents: read`. |

## Database

| What surprises people | Evidence | What to do |
| --- | --- | --- |
| Owner search is case-insensitive on H2 and case-sensitive on PostgreSQL (F18). On H2 `davis` finds both Davis owners; on PostgreSQL it finds none and `Davis` finds both. MySQL depends on the column collation. | `last_name VARCHAR_IGNORECASE(30)` in `src/main/resources/db/h2/schema.sql`, `TEXT` in `src/main/resources/db/postgres/schema.sql`; run against the jar (runbook F18). | Do not rely on H2 for search behavior. The intended behavior is an open owner decision. |
| PostgreSQL has no length limits. Its columns are `TEXT`, while H2 and MySQL use `VARCHAR` sizes that match the entity annotations. | `src/main/resources/db/*/schema.sql`, commit `3c7ab98`. | When you add a column, add a matching `@Size` to the entity, or a long value gives HTTP 500 on H2 and MySQL instead of a form error. [Patterns and conventions](../how-to-contribute/patterns-and-conventions.md#validation-rules-live-on-the-entities) has the table. |
| On MySQL, the second of two simultaneous requests that add the same pet name gets HTTP 500 instead of a form error (F17). | The MySQL `UNIQUE (owner_id, name)` has no name, and `PetController.isDuplicatePetNameViolation` looks for `unique_owner_pet_name`. Inferred; no MySQL test runs the race. | Name the constraint when you touch the MySQL schema; existing databases need a rename. |
| Editing a `CREATE TABLE` statement does not change an existing MySQL or PostgreSQL database, and Hibernate does not fix it either. | The scripts use `CREATE TABLE IF NOT EXISTS` and run at every start (`spring.sql.init.mode=always`); `spring.jpa.hibernate.ddl-auto=none`. H2 drops and recreates its tables at every start. | Write an explicit migration for existing databases, or recreate them. [Persistence](../systems/persistence.md) compares how the three script sets behave on a rerun. |
| `vet_specialties` has no primary key in any schema. H2 has only foreign keys, so duplicate rows are possible there; MySQL and PostgreSQL have a unique key. | `src/main/resources/db/*/schema.sql`. | Keep the seed data free of duplicates. The fix is listed on [Cleanup opportunities](../cleanup-opportunities.md). |
| `/h2-console` returns 404. Spring Boot 4 moved the console to the `spring-boot-h2console` module, which is not a dependency. | `README.md` "Database configuration", commit `0d8c589`. | Add the module locally if you need the console; [Debugging](../how-to-contribute/debugging.md#inspect-the-database) explains how. |

## Web and paging

| What surprises people | Evidence | What to do |
| --- | --- | --- |
| Page 2 of a filtered owner search shows all owners (F16). The paging links drop `lastName`. | `src/main/resources/templates/owners/ownersList.html` builds `/owners?page=N`; run against the jar (runbook F16). | Known open defect. The fix is to add `lastName` to the links. |
| An out-of-range page number does not give an error. Any page below 1 or above the last page, including `2147483647`, redirects to page 1; a malformed number such as `abc` or `2147483648` gives HTTP 400. | `OwnerController.processFindForm`, `VetController.showVetList`, `UntrustedInputIntegrationTests`. | Expect a 302 in tests and scripts. [Owners](../features/owners.md) and [Vets](../features/vets.md) describe the paging. |
| The two lists bound the page in different ways. Owners cap the page at `Integer.MAX_VALUE / 5` before the query; vets check the range against the cached full list first and never query a page that does not exist. | Comments in `src/main/java/org/springframework/samples/petclinic/owner/OwnerController.java` and `src/main/java/org/springframework/samples/petclinic/vet/VetController.java`; commits `3a5a0bc`, `0e8563f`. | For a new paged list, copy the vets pattern if the query is cached, the owners pattern otherwise. |
| A search with exactly one match skips the list and opens that owner's page. An empty last name lists every owner. | `OwnerController.processFindForm`. | Test with names that match more than one owner when you check the list page. |
| An unknown owner or pet id gives HTTP 500, not 404 (F3). On the pet edit route an unknown pet id fails later, because `PetController.findPet` returns `null`. | `UntrustedInputIntegrationTests`, `@ModelAttribute` loaders in `src/main/java/org/springframework/samples/petclinic/owner/`. | Known open issue; see [Error handling](../features/error-handling.md). |
| The owner form's error message never appears (F20). The handler adds an `error` flash attribute and then renders the form, but flash attributes survive only a redirect. | `src/main/java/org/springframework/samples/petclinic/owner/OwnerController.java` lines 80 and 159; run against the jar (runbook F20). | Use `BindingResult` errors for form messages, or redirect if you need a flash message. |
| The script at the end of the owner page can throw a `TypeError` when either message element is absent (F20, inferred from the code). | `src/main/resources/templates/owners/ownerDetails.html` sets `style.display` on `success-message` and `error-message` without null checks. | Check the browser console when you change that page. |
| A form field named `id`, or ending in `.id`, is silently ignored. | `dataBinder.setDisallowedFields("id", "*.id")` in every form controller. | Take ids from path variables, as the existing handlers do. Do not remove the rule. |
| `/vets` returns JSON or XML depending on `Accept`, and HTTP 406 for other types. Only the JSON case has a unit test; the format without an `Accept` header is not confirmed. | `VetControllerTests`, QA flow A1 in `.factory/skills/qa-api/SKILL.md`. | Send an explicit `Accept` header. See [HTTP API](../api.md). |

## Caching

| What surprises people | Evidence | What to do |
| --- | --- | --- |
| Vets changed directly in the database do not show up. The `vets` cache has no expiry. | No `spring.cache.*` property in `src/main/resources/application.properties`. | Restart, or clear the cache with `DELETE /actuator/caches/vets` ([How to monitor](../how-to-monitor.md)). |
| During a database outage only cached responses work. `/vets` survives only if it was requested before the outage; `/vets.html` is not tested during an outage. | `PostgresOutageIntegrationTests`, `docs/RUNBOOK.md` "Failure behavior". | Do not read a working `/vets` as a healthy database; use `/actuator/health`. |
| F15 is fixed, but the cache is still unbounded. Before `0e8563f`, 5,000 distinct page numbers left 5,000 cached pages. Now only existing pages are cached. | `UntrustedInputIntegrationTests.outOfRangeVetPagesAreNotCached`, runbook F15. | Never cache a query whose key comes from user input without bounding it. The runbook suggests `spring.cache.caffeine.spec` as the remaining hardening. |
| The cache statistics promised in `CacheConfiguration` are never enabled (F12). The `JCacheManagerCustomizer` needs a JCache provider, and Spring Boot uses Caffeine directly. | `/actuator/caches` reports a `CaffeineCacheManager`; `src/main/java/org/springframework/samples/petclinic/system/CacheConfiguration.java`. | Do not add cache settings to that class; they have no effect. See [Caching](../systems/caching.md). |

## Internationalization

| What surprises people | Evidence | What to do |
| --- | --- | --- |
| `I18nPropertiesSyncTest` passes while English text still reaches the page (F19). It checks literal text between HTML tags in templates and missing keys in bundles. It collects Java files but does not check them, and it misses labels passed as fragment arguments. | `src/test/java/org/springframework/samples/petclinic/system/I18nPropertiesSyncTest.java`; English labels in `src/main/resources/templates/pets/createOrUpdatePetForm.html` and `src/main/resources/templates/pets/createOrUpdateVisitForm.html`; English flash messages in the controllers. | Pass `#{...}` keys to fragments and use message keys in Java code too, even though the test does not catch it. |
| Some validation errors have no translation. The codes `size` (`PetValidator`) and `mismatch` (`OwnerController`) have no message keys, and two German messages contain U+FFFD replacement characters. | `src/main/resources/messages/messages_de.properties` lines 7-8; runbook F19. | Add keys for new error codes to `src/main/resources/messages/messages.properties` and every translation. |
| The language chosen with `?lang=` sticks for the whole session. | `SessionLocaleResolver` with default English in `src/main/java/org/springframework/samples/petclinic/system/WebConfiguration.java`. | Use a new session, or `?lang=en`, to get back to English. [Internationalization](../features/internationalization.md) has the details. |

## Actuator and operations

| What surprises people | Evidence | What to do |
| --- | --- | --- |
| Every Actuator endpoint is open without authentication, including `env`, `beans`, `threaddump` and `sbom` (F1). | `management.endpoints.web.exposure.include=*` in `src/main/resources/application.properties`, whose comment says not to do this in production. | Expose only `health,info` outside development, or add authentication. See [Security](../security.md). |
| `/livez` and `/readyz` return 404 when you run the jar. They exist only with `management.endpoint.health.probes.add-additional-paths=true`. | `k8s/petclinic.yml` sets it through `SPRING_APPLICATION_JSON`; `docs/RUNBOOK.md` "Health checks". | Use `/actuator/health/liveness` and `/actuator/health/readiness`, or set the property. |
| Readiness stays UP while the database is down (F2). `/actuator/health` returns 503, but `/livez` and `/readyz` stay 200. | `PostgresOutageIntegrationTests`. | Watch `/actuator/health` for the database. Adding `db` to readiness is an open owner decision. |
| `/actuator/info` has no git or build section for a Gradle jar (F11, inferred from `build.gradle`). For a Maven jar, `build.time` likely shows the fixed `project.build.outputTimestamp` from `pom.xml`, not the real build time (inferred, not checked against a running jar). | `pom.xml` lines 22-23 and the `build-info` goal. | Use `git.commit.id` to identify the running code, not `build.time`. |
| The jar's `git.properties` holds the default git properties, including the committer's and the builder's names and email addresses. `/actuator/info` shows only branch, commit id and time in its default mode, but anyone with the jar can read the file. | `git-commit-id-maven-plugin` in `pom.xml` has no include or exclude list. | Consider an include list before publishing jars outside the team. |
| With the `mysql` or `postgres` profile, the process exits within seconds when the database is unreachable. This is intended. | `DatabaseUnavailableAtStartupTests`. | Start the database first, or let a supervisor restart the process. |

## Kubernetes and Compose

| What surprises people | Evidence | What to do |
| --- | --- | --- |
| `kubectl apply -f k8s/` does not deploy this repository's code. It runs `dsyer/petclinic` with no tag, and the kind workflow tests that image, not the pull request (F4). | `k8s/petclinic.yml`, `.github/workflows/deploy-and-test-cluster.yml`. | Build and push your own image before relying on the manifests. [Deployment](../deployment.md) has the details. |
| The Kubernetes database loses its data when the pod restarts, and its credentials are in the manifest (F5). | `k8s/db.yml` has no volume. | Use a PersistentVolumeClaim and a managed secret for anything beyond a demo. |
| An image not built with buildpacks ignores `/bindings` and connects to `localhost` (F6). | Neither build file declares Spring Cloud Bindings; `docs/DEPENDENCIES.md` marks the binding as Inferred. | Build with `./mvnw spring-boot:build-image`, or set `POSTGRES_URL`, `POSTGRES_USER` and `POSTGRES_PASS`. |
| `docker compose up mysql` creates an empty, root-owned `conf.d/` directory in the repository (F7). | `docker-compose.yml` mounts `./conf.d`, which is not in the repository. | Do not commit it. Remove it with `sudo` if it gets in the way. |
| The Compose services publish ports 3306 and 5432 on all interfaces, and MySQL allows an empty root password (F8). | `docker-compose.yml`. | Use them on a development machine only, or bind the ports to `127.0.0.1`. |
| `docker compose up` without a service name starts both databases. | Commit `0d8c589` fixed the setup notes for this reason. | Name the service: `docker compose up mysql` or `docker compose up postgres`. |

## Agent tooling

| What surprises people | Evidence | What to do |
| --- | --- | --- |
| The Droid hook blocks harmless commands that only mention a blocked action, such as an `echo` of a merge command, and it can be bypassed on purpose. It is not an access control (F13: branch protection could not be checked). | Docstring of `.factory/hooks/guard_release_actions.py`; 6 tests in `.factory/hooks/test_guard_release_actions.py`. | Rephrase harmless commands. Rely on branch protection and review on GitHub for the real control. |
| A QA comment can say INCONCLUSIVE or "QA did not run" on a healthy pull request. Pull requests that change only docs, CI or tests get INCONCLUSIVE; a missing `FACTORY_API_KEY` means no run, which is the normal case for Dependabot pull requests unless the key is also a Dependabot secret (read F21 first); forks get no secrets. | `docs/RUNBOOK.md` "QA check on pull requests", `.github/workflows/qa.yml`. | Treat QA as information. It is not a required check. |
| The wiki pull request may run no build checks. Opened with the built-in `GITHUB_TOKEN`, it starts no other workflows. When the builds do run, their nohttp check scans the wiki pages too. | `docs/RUNBOOK.md` "Wiki refresh", `.github/workflows/droid-wiki-refresh.yml`. | Set `FACTORY_WIKI_PR_TOKEN`. Do not edit `droid-wiki/` by hand (`AGENTS.md`). |
| The QA plugin and the Droid CLI are not pinned (F21). A QA run can change behavior without a change in this repository. | `docs/DEPENDENCIES.md` "CI and developer environments", `.factory/settings.json`. | Note the CLI version from the workflow log when you compare runs. |

## Related pages

- [Design decisions](design-decisions.md) explains why many of these traps exist.
- [Debugging](../how-to-contribute/debugging.md) has symptom-to-fix tables for build and runtime errors.
- [Cleanup opportunities](../cleanup-opportunities.md) lists the code changes that would remove some of these traps.

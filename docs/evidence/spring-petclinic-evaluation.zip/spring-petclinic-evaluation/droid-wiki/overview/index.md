# Spring PetClinic overview

Spring PetClinic is the Spring team's sample application. Staff at a veterinary clinic use it to find and register pet owners, add their pets, book visits and look up the clinic's vets. It is one Spring Boot web application that renders its pages on the server and keeps its data in an in-memory H2 database unless you choose MySQL or PostgreSQL.

## Who uses it

The upstream project at `https://github.com/spring-projects/spring-petclinic` is a teaching example. Developers read it to see how a typical Spring Boot application is put together, and many forks build on it (`README.md` lists several). The application has no login, so anyone who can reach it can read and change every record.

This repository is upstream `main` up to commit `500158f` plus the branch `security/spring-boot-4.1.2-cve-remediation`. That branch upgrades Spring Boot from 4.1.0 to 4.1.2 to fix 20 published advisories and adds tests, operations documents and Droid automation. [Lore](../lore.md) tells the story, and [Security](../security.md) lists the advisories.

## What it does

| Capability | What a user can do | Details |
| --- | --- | --- |
| Owners | Search by last name, page through the results, add and edit owners | [Owners](../features/owners.md) |
| Pets | Add and edit an owner's pets with a name, type and birth date | [Pets](../features/pets.md) |
| Visits | Book a visit for a pet and see its earlier visits | [Visits](../features/visits.md) |
| Vets | List the vets and their specialties as a web page, JSON or XML | [Vets](../features/vets.md) |
| Languages | Switch the interface between 10 languages with the `lang` parameter | [Internationalization](../features/internationalization.md) |
| Errors | Get an error page without internal details when something fails | [Error handling](../features/error-handling.md) |

## Technology

| Layer | Technology on this branch | Defined in |
| --- | --- | --- |
| Language | Java 17 | `pom.xml` (`java.version`), `build.gradle` |
| Framework | Spring Boot 4.1.2 with Spring Framework 7.0.10 | parent of `pom.xml`, plugins of `build.gradle` |
| Web | Spring MVC on embedded Tomcat 11.0.27, Thymeleaf templates, Bootstrap 5.3.8 | `src/main/resources/templates/` |
| Data | Spring Data JPA with Hibernate 7.4; H2 by default, MySQL 9.7 or PostgreSQL 18.4 through profiles | `src/main/resources/db/` |
| Cache | Caffeine through Spring's cache abstraction | `src/main/java/org/springframework/samples/petclinic/vet/VetRepository.java` |
| Operations | Spring Boot Actuator: health, info, SBOM and more | `src/main/resources/application.properties` |
| Build | Maven wrapper (main build) and Gradle wrapper, kept in step | `pom.xml`, `build.gradle` |

[Dependencies](../reference/dependencies.md) has the versions and where each one comes from.

## At a glance

- 30 Java source files (about 1,900 lines) in four packages, 12 Thymeleaf templates and 11 message bundles.
- 24 test classes (about 2,900 lines). `./mvnw verify` runs 116 tests when Docker is available.
- One deployable, `target/spring-petclinic-4.0.0-SNAPSHOT.jar`, which listens on port 8080.
- No login and no outside services apart from the database.

[By the numbers](../by-the-numbers.md) has more statistics.

## Where to go next

- [Architecture](architecture.md): how a request moves through the code.
- [Getting started](getting-started.md): build, run and test on your machine.
- [Glossary](glossary.md): the terms used in the code and in this wiki.
- [How to contribute](../how-to-contribute/index.md): the workflow for changes, including the rules for coding agents.
- [Deployment](../deployment.md), [Security](../security.md) and [How to monitor](../how-to-monitor.md): what to know before you run it anywhere shared.
- In the repository: `docs/RUNBOOK.md` for operations, `docs/DEPENDENCIES.md` for every dependency with a confidence label, and `AGENTS.md` for coding agents.

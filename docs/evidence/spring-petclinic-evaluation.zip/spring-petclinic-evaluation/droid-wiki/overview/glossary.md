# Glossary

Terms used in the PetClinic code, its documents and this wiki. Domain terms come first, then project and tooling terms.

## Domain

| Term | Meaning | Where |
| --- | --- | --- |
| Owner | A pet owner: first and last name, address, city and a 10-digit telephone number. Owns the pets and, through them, the visits. | `src/main/java/org/springframework/samples/petclinic/owner/Owner.java` |
| Pet | An animal that belongs to one owner, with a name that is unique for that owner, a birth date and a type. | `src/main/java/org/springframework/samples/petclinic/owner/Pet.java` |
| Pet type | The kind of animal (bird, cat, dog, hamster, lizard, snake). Stored in the `types` table. | `src/main/java/org/springframework/samples/petclinic/owner/PetType.java` |
| Visit | A booked appointment for a pet: a date after today and a description. | `src/main/java/org/springframework/samples/petclinic/owner/Visit.java` |
| Vet | A veterinarian with zero or more specialties. Read-only in the application. | `src/main/java/org/springframework/samples/petclinic/vet/Vet.java` |
| Specialty | A vet's field (radiology, surgery, dentistry). | `src/main/java/org/springframework/samples/petclinic/vet/Specialty.java` |
| `Vets` | Wrapper around the vet list, so `/vets` can return one JSON object or XML document. | `src/main/java/org/springframework/samples/petclinic/vet/Vets.java` |
| Seed data | The sample owners, pets, visits and vets loaded at startup by the data.sql script of the active database. | `src/main/resources/db/h2/data.sql` |

## Code

| Term | Meaning | Where |
| --- | --- | --- |
| `BaseEntity`, `NamedEntity`, `Person` | Mapped superclasses that add an `id`, a `name`, or a first and last name to an entity. | `src/main/java/org/springframework/samples/petclinic/model/` |
| Aggregate | `Owner` together with its pets and their visits. They are loaded and saved as one unit through `OwnerRepository`. | [Persistence](../systems/persistence.md) |
| `database` property | Chooses which folder of SQL scripts runs at startup: `h2`, `mysql` or `postgres`. | `src/main/resources/application.properties` |
| Profile | A Spring profile. `mysql` and `postgres` switch the database; without one the application uses H2. | `src/main/resources/application-mysql.properties`, `src/main/resources/application-postgres.properties` |
| Flash message | A one-time message carried across a redirect, such as "New Owner Created", shown in green on the owner page. | [Patterns and conventions](../how-to-contribute/patterns-and-conventions.md) |
| Layout fragment | The Thymeleaf template that wraps every page with the navigation bar and footer. Each page passes the name of its menu item. | `src/main/resources/templates/fragments/layout.html` |
| `PetValidator` | Spring `Validator` for the pet form: name required and at most 30 characters, type required for new pets, birth date required. | `src/main/java/org/springframework/samples/petclinic/owner/PetValidator.java` |
| `PetTypeFormatter` | Converts between a pet type and the name shown in the form's drop-down list. | `src/main/java/org/springframework/samples/petclinic/owner/PetTypeFormatter.java` |
| Page bounds redirect | A page number below 1 or past the last page redirects to page 1 instead of failing. Huge numbers are capped first. | [Owners](../features/owners.md) |
| `/oups` | A page that throws an exception on purpose, to show the error page. Linked as "Error" in the navigation bar. | `src/main/java/org/springframework/samples/petclinic/system/CrashController.java` |

## Project and tooling

| Term | Meaning | Where |
| --- | --- | --- |
| Advisory | A published vulnerability report (GHSA or CVE id) for a library version. | `docs/DEPENDENCIES.md` |
| Version guard | `PatchedDependencyVersionsTests`, which fails the build when a library resolves below the first version that fixed a known advisory. | `src/test/java/org/springframework/samples/petclinic/PatchedDependencyVersionsTests.java` |
| Confirmed, Inferred, Unknown | Labels in `docs/DEPENDENCIES.md` for how sure we are about a dependency: seen running, read from configuration only, or not determined. | `docs/DEPENDENCIES.md` |
| Follow-ups F1 to F22 | Known issues found during the 2026-11-13 review, with evidence and a suggested change. F1 to F20 are open on purpose, except F15, which is fixed and stays listed so that the IDs do not change. F21 and F22 wait for an owner decision. | `docs/RUNBOOK.md` |
| SBOM | Software bill of materials. The build puts a CycloneDX SBOM in the jar, and `/actuator/sbom/application` serves it. | [How to monitor](../how-to-monitor.md) |
| OSV-Scanner | Google's scanner that checks dependencies against the OSV vulnerability database. Runs in CI on every pull request. | `.github/workflows/osv-scanner.yml` |
| Dependabot | GitHub's service that proposes dependency updates every week. | `.github/dependabot.yml` |
| DCO | Developer Certificate of Origin. Every commit needs a `Signed-off-by` line (`git commit -s`). | `.github/dco.yml` |
| nohttp | Checkstyle rule that fails the build on `http://` links other than localhost. | `src/checkstyle/nohttp-checkstyle.xml` |
| spring-javaformat | Formatter and check for Spring's Java code style (tabs). | `pom.xml` |
| Testcontainers | Library that starts databases in Docker for tests. | `src/test/java/org/springframework/samples/petclinic/MySqlIntegrationTests.java` |
| kind | Kubernetes in Docker. A CI workflow deploys `k8s/` to a temporary kind cluster. | `.github/workflows/deploy-and-test-cluster.yml` |
| Service binding | Kubernetes convention for passing database credentials as files under `/bindings`; used by `k8s/petclinic.yml`. | [Deployment](../deployment.md) |
| Droid | Factory's coding agent. This repository configures it in `.factory/`. | `AGENTS.md` |
| Droid hook | `.factory/hooks/guard_release_actions.py`, which stops Droid from merging, deploying or pushing to `main`. | [Security](../security.md) |
| QA skill | Droid skill that builds the branch, starts it and tests it like a user: browser flows W1 to W9 and API flows A1 to A3. | `.factory/skills/qa/SKILL.md` |
| droid-control | Droid plugin that drives the browser for the QA skill. | `.factory/settings.json` |
| Rolling wiki pull request | The single pull request from `factory/droid-wiki` that the Droid Wiki Refresh workflow keeps up to date with these pages. | `.github/workflows/droid-wiki-refresh.yml` |

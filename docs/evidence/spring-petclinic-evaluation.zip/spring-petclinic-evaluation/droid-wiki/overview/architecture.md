# Architecture

PetClinic is a layered Spring MVC application that runs in one process. Controllers handle the HTTP requests, Spring Data repositories read and write the database through JPA, and Thymeleaf templates render the HTML. There is no service layer and no messaging, and the database is the only outside system.

## System context

```mermaid
graph LR
    Browser -->|HTML pages and form posts| App[PetClinic jar, port 8080]
    Client[API client] -->|GET /vets as JSON or XML| App
    Ops[Operator or Kubernetes] -->|Actuator health, info, SBOM| App
    App -->|JDBC| DB[(H2 in memory, MySQL or PostgreSQL)]
```

Everything a user does goes through server-rendered pages. The only machine-readable business endpoint is `/vets`; the rest of the API surface is Spring Boot Actuator (see [HTTP API](../api.md)).

## Components

```mermaid
graph TD
    DS[DispatcherServlet] -->|/owners/**| OC[OwnerController]
    DS -->|/owners/id/pets/**| PC[PetController]
    DS -->|/owners/id/pets/id/visits/**| VC[VisitController]
    DS -->|/vets.html, /vets| VetC[VetController]
    DS -->|/ and /oups| SC[WelcomeController, CrashController]
    OC -->|find, save| OR[OwnerRepository]
    PC --> OR
    PC -->|pet types| PTR[PetTypeRepository]
    VC --> OR
    VetC -->|findAll| VR[VetRepository]
    VR -->|cached in| Cache[(Caffeine cache vets)]
    OR --> JPA[Hibernate]
    PTR --> JPA
    VR --> JPA
    JPA --> DB[(Database)]
```

Each controller returns a view name, and Thymeleaf renders the matching template from `src/main/resources/templates/` inside the shared layout `src/main/resources/templates/fragments/layout.html`. [Web layer](../systems/web-layer.md) covers controllers and templates, [Persistence](../systems/persistence.md) covers repositories and databases, and [Caching](../systems/caching.md) covers the vets cache.

## Packages

Code is grouped by feature under `src/main/java/org/springframework/samples/petclinic/`:

| Package | Contents | Wiki page |
| --- | --- | --- |
| `owner` | Entities `Owner`, `Pet`, `PetType` and `Visit`; `OwnerController`, `PetController` and `VisitController`; `OwnerRepository` and `PetTypeRepository`; `PetValidator` and `PetTypeFormatter` | [Owners](../features/owners.md), [Pets](../features/pets.md), [Visits](../features/visits.md) |
| `vet` | Entities `Vet` and `Specialty`, the `Vets` wrapper for JSON and XML, `VetController` and `VetRepository` | [Vets](../features/vets.md) |
| `system` | `WelcomeController`, `CrashController`, `WebConfiguration` (language switching) and `CacheConfiguration` | [Internationalization](../features/internationalization.md), [Error handling](../features/error-handling.md) |
| `model` | Base classes `BaseEntity` (id), `NamedEntity` (name) and `Person` (first and last name) | [Data models](../reference/data-models.md) |

The entry point is `src/main/java/org/springframework/samples/petclinic/PetClinicApplication.java`, a `@SpringBootApplication` that also imports `src/main/java/org/springframework/samples/petclinic/PetClinicRuntimeHints.java`. The runtime hints register the SQL scripts, message bundles and serializable entity classes for GraalVM native images.

## Request lifecycle

Every form follows the same post-redirect-get cycle. This is what happens when a user adds a pet:

```mermaid
sequenceDiagram
    participant B as Browser
    participant D as DispatcherServlet
    participant P as PetController
    participant R as OwnerRepository
    participant T as Thymeleaf
    B->>D: POST /owners/1/pets/new
    D->>P: model attributes: findOwner(1), populatePetTypes()
    P->>R: findById(1)
    R-->>P: Owner with pets and visits
    D->>P: bind the form without id fields, run PetValidator
    alt the form has errors
        P->>T: pets/createOrUpdatePetForm
        T-->>B: 200, the form with a message under each bad field
    else the form is valid
        P->>R: saveAndFlush(owner)
        P-->>B: 302 to /owners/1 with a flash message
        B->>D: GET /owners/1
        D->>T: owners/ownerDetails
        T-->>B: 200, owner page showing "New Pet has been Added"
    end
```

The steps are in `src/main/java/org/springframework/samples/petclinic/owner/PetController.java`: `@ModelAttribute` methods load the owner and the pet types before every handler, `@InitBinder` stops the form from setting `id` fields, and the handler saves through `OwnerRepository` and redirects. [Patterns and conventions](../how-to-contribute/patterns-and-conventions.md) describes these patterns in detail.

## Data model

```mermaid
erDiagram
    OWNERS ||--o{ PETS : has
    TYPES ||--o{ PETS : classifies
    PETS ||--o{ VISITS : has
    VETS }o--o{ SPECIALTIES : "vet_specialties"
```

`Owner` is the aggregate root: `Owner.pets` and `Pet.visits` are `@OneToMany(cascade = ALL, fetch = EAGER)` in `src/main/java/org/springframework/samples/petclinic/owner/Owner.java` and `src/main/java/org/springframework/samples/petclinic/owner/Pet.java`, so saving an owner saves its pets and visits. Vets are separate and read-only in the application. [Data models](../reference/data-models.md) lists every table, column and constraint.

## Databases and profiles

The `database` property in `src/main/resources/application.properties` (default `h2`) picks the schema and seed scripts in `src/main/resources/db/<database>/`, which Spring Boot runs at startup. The `mysql` and `postgres` profiles switch to those databases and read the connection settings from environment variables. Hibernate never changes the schema (`spring.jpa.hibernate.ddl-auto=none`). Details are in [Persistence](../systems/persistence.md) and [Configuration](../reference/configuration.md).

## Cross-cutting concerns

| Concern | How it works | Page |
| --- | --- | --- |
| Validation | Bean Validation annotations on the entities, `PetValidator` for pets, and extra checks in the controllers | [Patterns and conventions](../how-to-contribute/patterns-and-conventions.md) |
| Languages | `src/main/java/org/springframework/samples/petclinic/system/WebConfiguration.java` keeps the language in the session and switches it on `?lang=` | [Internationalization](../features/internationalization.md) |
| Caching | `VetRepository.findAll` is `@Cacheable("vets")`, backed by Caffeine | [Caching](../systems/caching.md) |
| Errors | Spring Boot renders `src/main/resources/templates/error.html` without exception details | [Error handling](../features/error-handling.md) |
| Monitoring | Actuator exposes every endpoint, including health, info and the SBOM | [How to monitor](../how-to-monitor.md) |
| Security | No authentication or authorization; id fields cannot be bound from forms | [Security](../security.md) |

## Languages in the repository

Lines in tracked files by type, on this branch:

```mermaid
xychart-beta horizontal
    title "Lines by file type"
    x-axis ["Java", "Markdown", "YAML", "Properties", "HTML", "XML", "SCSS", "SQL", "Python", "Gradle"]
    y-axis "Lines" 0 --> 5000
    bar [4758, 1011, 862, 579, 536, 461, 388, 344, 249, 98]
```

Java is 30 source files (1,903 lines) and 24 test files (2,855 lines). The Python is the Droid hook in `.factory/hooks/`, and most of the YAML is GitHub Actions workflows.

## Build and delivery

Maven (`pom.xml`) is the main build and Gradle (`build.gradle`) mirrors it. Both check formatting and `http://` links, run the tests and produce an executable jar that contains a CycloneDX SBOM; only the Maven jar also carries git and build information for `/actuator/info` (F11). GitHub Actions builds every pull request with both tools. There is no Dockerfile for the application; `./mvnw spring-boot:build-image` builds a container image with buildpacks. See [Tooling](../how-to-contribute/tooling.md) and [Deployment](../deployment.md).

## Key source files

| File | Purpose |
| --- | --- |
| `src/main/java/org/springframework/samples/petclinic/PetClinicApplication.java` | Application entry point |
| `src/main/java/org/springframework/samples/petclinic/owner/OwnerController.java` | Owner search, list, create, edit and details pages |
| `src/main/java/org/springframework/samples/petclinic/owner/PetController.java` | Add and edit pets |
| `src/main/java/org/springframework/samples/petclinic/owner/VisitController.java` | Book visits |
| `src/main/java/org/springframework/samples/petclinic/vet/VetController.java` | Vets page and the `/vets` JSON and XML resource |
| `src/main/java/org/springframework/samples/petclinic/owner/OwnerRepository.java` | Spring Data repository for the owner aggregate |
| `src/main/java/org/springframework/samples/petclinic/vet/VetRepository.java` | Read-only, cached repository for vets |
| `src/main/java/org/springframework/samples/petclinic/system/WebConfiguration.java` | Language resolver and `lang` interceptor |
| `src/main/resources/application.properties` | Database choice, JPA, Actuator and message settings |
| `src/main/resources/templates/fragments/layout.html` | Page layout and navigation bar shared by every page |

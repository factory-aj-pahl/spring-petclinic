# Getting started

You need JDK 17 or newer to build and run PetClinic. Docker is optional: the application runs on its in-memory database without it, but the MySQL and PostgreSQL setups and three of the tests need it.

## Prerequisites

| Tool | Version | Needed for |
| --- | --- | --- |
| JDK | 17 or newer; CI uses Temurin 17 | Building and running |
| Docker with Compose v2 | A current release | MySQL and PostgreSQL, and the tests `MySqlIntegrationTests`, `PostgresIntegrationTests` and `PostgresOutageIntegrationTests` |
| Maven or Gradle | Nothing to install | The wrappers `mvnw` and `gradlew` download the versions the build expects |

## Run the application

From the repository root:

```bash
./mvnw spring-boot:run
```

or, with Gradle:

```bash
./gradlew bootRun
```

Then open `http://localhost:8080/`. The H2 database starts empty and Spring Boot loads the seed data from `src/main/resources/db/h2/data.sql` on every start: 10 owners, 13 pets, 4 visits and 6 vets. Anything you add is gone when the process stops.

To check that the application is up:

```bash
curl http://localhost:8080/actuator/health
```

It answers `{"groups":["liveness","readiness"],"status":"UP"}`.

## Use MySQL or PostgreSQL

`docker-compose.yml` has one service per database, named after the Spring profile:

| Database | Start the database | Start the application |
| --- | --- | --- |
| MySQL 9.7 | `docker compose up mysql` | `./mvnw spring-boot:run -Dspring-boot.run.profiles=mysql` |
| PostgreSQL 18.4 | `docker compose up postgres` | `./mvnw spring-boot:run -Dspring-boot.run.profiles=postgres` |

The profiles read `MYSQL_URL`, `MYSQL_USER` and `MYSQL_PASS`, or `POSTGRES_URL`, `POSTGRES_USER` and `POSTGRES_PASS`, from the environment. Their defaults point at the Compose services on localhost (`src/main/resources/application-mysql.properties`, `src/main/resources/application-postgres.properties`). The schema and seed scripts run on every start and are written so that a second run changes nothing. [Persistence](../systems/persistence.md) explains the setup, and the setup notes in `src/main/resources/db/mysql/petclinic_db_setup_mysql.txt` and `src/main/resources/db/postgres/petclinic_db_setup_postgres.txt` cover manual installs.

## Build and test

| Task | Command |
| --- | --- |
| Full build: format check, `http://` link check, all tests, coverage report, jar | `./mvnw verify` |
| Full Gradle build | `./gradlew build` |
| One test class | `./mvnw test -Dtest=OwnerControllerTests` |
| Fix Java formatting | `./mvnw spring-javaformat:apply` |
| Test the Droid hook | `python3 -B -m unittest discover -s .factory/hooks` |

`./mvnw verify` takes about a minute on 4 CPUs and runs 116 tests when Docker is running. Without Docker the MySQL tests are reported as skipped and the PostgreSQL tests are not counted, so the build still passes with fewer tests; check the count when it matters. [Testing](../how-to-contribute/testing.md) explains the test layers.

The build fails on formatting differences and on `http://` links in any file other than localhost links. [Tooling](../how-to-contribute/tooling.md) lists every check.

## Run the jar

`./mvnw verify` (or `./mvnw package`) writes `target/spring-petclinic-4.0.0-SNAPSHOT.jar`:

```bash
java -jar target/spring-petclinic-4.0.0-SNAPSHOT.jar
java -jar target/spring-petclinic-4.0.0-SNAPSHOT.jar --spring.profiles.active=postgres
```

## Build a container image

There is no Dockerfile for the application (`.devcontainer/Dockerfile` is the Gitpod workspace image). With Docker running, `./mvnw spring-boot:build-image` builds an image with Cloud Native Buildpacks. Find its name and tag with `docker images | grep petclinic`, then run it with `docker run -p 8080:8080 <image>`. [Deployment](../deployment.md) covers images, Compose and Kubernetes.

## Work in an IDE or a dev container

`README.md` has steps for Eclipse or Spring Tools and for IntelliJ IDEA. The test classes `PetClinicIntegrationTests`, `MysqlTestApplication` and `PostgresIntegrationTests` in `src/test/java/org/springframework/samples/petclinic/` have `main` methods that start the application against H2, a Testcontainers MySQL or the Compose PostgreSQL, which is handy from an IDE. The repository also has a dev container definition in `.devcontainer/devcontainer.json` (Java 21) and a Gitpod setup in `.gitpod.yml`.

## Next steps

- [Architecture](architecture.md) for how the pieces fit together.
- [Development workflow](../how-to-contribute/development-workflow.md) before you open a pull request.
- [Debugging](../how-to-contribute/debugging.md) when something does not start.

# Security

PetClinic has no authentication or authorization: every page, form, the `/vets` resource and every Spring Boot Actuator endpoint answer any client that can reach port 8080. What protection it has comes from input validation, Thymeleaf output escaping, error pages without internal details, a build-time check against vulnerable library versions, and guardrails for agents and CI. This page maps the trust boundaries and names the file behind each behavior.

## Trust boundaries

Neither `pom.xml` nor `build.gradle` declares Spring Security, and `src/main` has no security configuration, servlet filter or CORS setting; the only interceptor is the locale switch in `src/main/java/org/springframework/samples/petclinic/system/WebConfiguration.java`. There are no logins, accounts, roles or API keys, so anyone who reaches the port can read, create and edit owners, pets and visits, and call Actuator. The network is the only boundary: who can reach port 8080 on a developer machine, or the NodePort Service in `k8s/petclinic.yml`, which has no Ingress and no TLS ([Deployment](deployment.md)). `src/main/resources/application.properties` sets no `server.ssl.*` property.

```mermaid
graph LR
    CLIENT[Browser or curl, any network client]
    subgraph APP[PetClinic process, port 8080]
        MVC[Spring MVC pages, forms, /vets]
        ACT[Actuator /actuator/**]
    end
    DB[(H2, MySQL or PostgreSQL)]
    SECRET[Secret demo-db in k8s/db.yml]
    DEV[Developer or Droid session]
    HOOK[Droid hook guard_release_actions.py]
    GH[GitHub repository and pull requests]
    CI[GitHub Actions workflows]
    FACTORY[Factory API]
    CLIENT -->|"HTTP, no login, no CSRF token"| MVC
    CLIENT -->|"HTTP, no login"| ACT
    MVC -->|"JDBC with profile credentials"| DB
    SECRET -->|"mounted at /bindings, needs Spring Cloud Bindings"| APP
    DEV -->|"shell commands checked by"| HOOK
    HOOK -->|"feature branch and pull request"| GH
    GH -->|"pull_request and push events"| CI
    CI -->|"FACTORY_API_KEY, repository code"| FACTORY
```

## Actuator exposure (F1)

`src/main/resources/application.properties` line 21 sets `management.endpoints.web.exposure.include=*`, under a comment that says not to do this in production. Nothing overrides it in `k8s/petclinic.yml`, so the cluster exposes the same endpoints. `docs/RUNBOOK.md` (F1) and `docs/DEPENDENCIES.md` record a live run that served `env`, `beans`, `threaddump` and `sbom` without authentication, and the local QA run recorded `health`, `info` and `sbom`.

Others, such as `configprops`, `mappings`, `loggers`, `caches`, `metrics` and `heapdump`, follow from Spring Boot 4.1.2's defaults and the jars in the build, and were not called. By those defaults, `POST /actuator/loggers/{name}` changes a log level and `DELETE /actuator/caches` clears caches; neither write was tested. `shutdown` is off by default, and the QA run confirmed a 404. The per-endpoint table is in [HTTP API](api.md#actuator-endpoints).

What the sensitive endpoints reveal, according to the Spring Boot 4.1.2 configuration metadata:

- `env` and `configprops` list property names and sources but mask values, because `management.endpoint.env.show-values` and `management.endpoint.configprops.show-values` default to `never`.
- `heapdump` is not masked. It returns the process memory, which can hold the datasource password and any owner data in use (inferred; not called).
- `beans`, `mappings`, `threaddump` and `conditions` describe the internals of the running application.

`docs/RUNBOOK.md` suggests exposing only `health,info` outside development, or adding authentication. The owner kept this as an open follow-up.

## Input handling

All form input goes through Spring MVC data binding into the entities:

- **Id binding is disallowed.** Every form controller calls `setDisallowedFields("id", "*.id")` in an `@InitBinder` method: `src/main/java/org/springframework/samples/petclinic/owner/OwnerController.java`, `src/main/java/org/springframework/samples/petclinic/owner/PetController.java` (for `owner` and `pet`) and `src/main/java/org/springframework/samples/petclinic/owner/VisitController.java`. A client cannot choose or overwrite ids; the owner and pet are loaded by the `@ModelAttribute` methods from the path.
- **Bean Validation** limits names to 30 characters (`src/main/java/org/springframework/samples/petclinic/model/Person.java`), `address` to 255 and `city` to 80, and requires a 10-digit `telephone` (`src/main/java/org/springframework/samples/petclinic/owner/Owner.java`). A visit description is required and at most 255 characters (`src/main/java/org/springframework/samples/petclinic/owner/Visit.java`).
- **`PetValidator`** (`src/main/java/org/springframework/samples/petclinic/owner/PetValidator.java`) requires a pet name of at most 30 characters, a type for new pets and a birth date. `PetController` also rejects future birth dates and duplicate names. [Patterns and conventions](how-to-contribute/patterns-and-conventions.md) has the full validation table.
- **Output escaping.** No template under `src/main/resources/templates/` uses `th:utext` or unescaped inlining (`[(...)]`). Values are written with `th:text`, `th:field` or `[[...]]`, which Thymeleaf HTML-escapes. No test submits markup to confirm this.
- **Page parameters.** `OwnerController.findPaginatedForOwnersLastName` caps the page at `Integer.MAX_VALUE / 5` before it builds the `PageRequest`. `VetController.showVetList` checks the range against the cached list of all vets before it runs the cached page query (F15, fixed). Out-of-range pages redirect to page 1 on both lists.
- **Malformed and unknown values.** A non-numeric or overflowing id or page gives HTTP 400. An unknown owner or pet id gives HTTP 500 instead of 404 (F3). Both are tested by `src/test/java/org/springframework/samples/petclinic/UntrustedInputIntegrationTests.java`; the status codes are listed in [Error handling](features/error-handling.md#status-codes).

No controller takes a `@RequestBody`. The application parses form fields and query parameters only, and `/vets` only writes JSON or XML.

## Cross-site request forgery

Spring Security is what would add CSRF tokens in a Spring MVC application, and it is not in the build. The POST forms in `src/main/resources/templates/owners/createOrUpdateOwnerForm.html`, `src/main/resources/templates/pets/createOrUpdatePetForm.html` and `src/main/resources/templates/pets/createOrUpdateVisitForm.html` therefore carry no token, and the server checks none. Any page that can make a browser submit a form to the application can create or change owners, pets and visits, although with no login this gives an attacker nothing that a direct request would not. Response headers such as `X-Frame-Options` are also not set by the application (inferred from the absence of Spring Security; no response headers were recorded).

## Denial of service and resource use

- **Vets cache (F15, fixed).** Before commit `0e8563f`, every distinct `/vets.html?page=` value added an entry to the `vets` cache; a run against the jar left 5,000 entries after 5,000 page numbers. The range check now runs first, and `UntrustedInputIntegrationTests.outOfRangeVetPagesAreNotCached` checks that out-of-range pages leave no entry. The cache itself still has no size limit or expiry, because no `spring.cache.caffeine.spec` is set ([Caching](systems/caching.md)).
- **Owner search.** The page size is fixed at 5 in `OwnerController`, and owner paging is not cached. The `lastName` search value has no length check of its own (the search handler has no `@Valid`); only the servlet container's request size limits apply (inferred from Tomcat defaults).
- **Unlimited writes.** Anyone can add owners, pets and visits, and `Owner.pets` and `Pet.visits` are loaded eagerly, so an owner page grows with every visit added. No rate limiting exists in `pom.xml`, `build.gradle` or `src/main`.
- **`/vets`** returns the full list without paging. Vets cannot be added through the application, since `src/main/java/org/springframework/samples/petclinic/vet/VetRepository.java` is read-only.

## Information exposure

- **Error pages.** `src/main/resources/templates/error.html` shows a heading and a status line. Its `${message}` paragraph is empty because `spring.web.error.include-message` defaults to `never`, and no `spring.web.error.*` property is set. Clients without `text/html` in `Accept` get a JSON body with `timestamp`, `status`, `error` and `path` only. Stack traces go to the log. [Error handling](features/error-handling.md) shows both.
- **`/actuator/info`.** Shows the git branch, commit id and commit time (`management.info.git.mode` defaults to `simple`) and the build name, version and fixed `build.time` from `META-INF/build-info.properties`.
- **`git.properties` in the jar.** `git-commit-id-maven-plugin` in `pom.xml` has no include or exclude list, so `BOOT-INF/classes/git.properties` holds every default git property. They include the name and email of the committer and of the user who ran the build, the build host, the remote origin URL and full commit messages. `/actuator/info` shows only the simple subset, but anyone with the jar or the image can read the file, and `management.info.git.mode=full` would publish it.
- **SBOM.** `/actuator/sbom/application` returns the exact version of every library in the jar, which helps operators ([How to monitor](how-to-monitor.md#sbom)) and anyone matching versions against advisories.

## Secrets and credentials

- **Application profiles.** `src/main/resources/application-mysql.properties` and `src/main/resources/application-postgres.properties` read `MYSQL_URL`, `MYSQL_USER`, `MYSQL_PASS` and `POSTGRES_URL`, `POSTGRES_USER`, `POSTGRES_PASS`. Each falls back to a local development default written in the file. Set the variables in any shared environment. [Configuration](reference/configuration.md#environment-variables) lists them.
- **Kubernetes Secret (F5).** `k8s/db.yml` defines the Secret `demo-db` with `stringData` in plain text, committed to the repository. The PostgreSQL container reads its user, password and database name from it.
- **Service binding (F6).** `k8s/petclinic.yml` mounts that Secret at `/bindings/secret` and sets `SERVICE_BINDING_ROOT=/bindings`. Spring Boot does not read bindings on its own; it works only if the image contains Spring Cloud Bindings, which Paketo buildpacks add (status Inferred in `docs/DEPENDENCIES.md`). Otherwise the application falls back to the `localhost` defaults.
- **Docker Compose (F8).** `docker-compose.yml` sets an empty MySQL root password with `MYSQL_ALLOW_EMPTY_PASSWORD=true` and publishes `3306:3306`, which binds all interfaces. The `postgres` service publishes `5432:5432` the same way. Both are meant for local development only.

## Dependency vulnerabilities and supply chain

- **Spring Boot 4.1.2 upgrade.** Moving from 4.1.0 to 4.1.2 fixed 20 published advisories (7 critical, 7 high, 6 moderate) in six packages: `tomcat-embed-core` (7), `jackson-databind` (7), `spring-webmvc` (2), `jackson-core` (2), `postgresql` (1) and `log4j-api` (1). About half are judged unreachable in this configuration; the rest could not be ruled out. Several Jackson ones are marked Unknown because Actuator write endpoints accept JSON without authentication, which ties them to F1. The advisory table is in `docs/DEPENDENCIES.md`, summarized in [Dependencies](reference/dependencies.md#advisories-fixed-by-spring-boot-412).
- **Version guard.** `src/test/java/org/springframework/samples/petclinic/PatchedDependencyVersionsTests.java` reads `Implementation-Version` from the jar manifests on the test classpath and fails the build if `tomcat-embed-core` is below 11.0.25, `spring-webmvc` below 7.0.9, `jackson-databind` or `jackson-core` below 3.1.7, `postgresql` below 42.7.12 or `log4j-api` below 2.25.5.
- **OSV-Scanner.** `.github/workflows/osv-scanner.yml` scans `pom.xml` (`--lockfile=pom.xml`) on pull requests and merge groups, failing on new vulnerabilities, and runs a full report on pushes to `main` and every Monday. It does not scan `build.gradle` or the SBOM; `docs/RUNBOOK.md` shows how to scan the SBOM locally. SARIF upload is off.
- **Dependabot.** `.github/dependabot.yml` opens weekly updates for Maven, Gradle and GitHub Actions (actions grouped into one pull request).
- **GitHub Actions references.** The workflows reference actions by version tag (`actions/checkout@v4`, `actions/setup-java@v4`, `helm/kind-action@v1`, the OSV-Scanner reusable workflows at `@v2.7.1` and others), so a moved tag changes what runs. The one exception is `peter-evans/create-pull-request` in `.github/workflows/droid-wiki-refresh.yml`, pinned to a commit SHA with a `# v8.1.1` comment.
- **Unpinned tools in CI (F21).** `.github/workflows/qa.yml` and `.github/workflows/droid-wiki-refresh.yml` install the Droid CLI with `curl -fsSL https://app.factory.ai/cli | sh`, which installs whatever version is current. `.factory/settings.json` enables the `droid-control` plugin from the `Factory-AI/factory-plugins` marketplace, also unpinned.
- **Kubernetes image (F4).** `k8s/petclinic.yml` runs `dsyer/petclinic` with no tag or digest. No workflow builds it, so its provenance and library versions are unknown, and the 4.1.2 fixes reach the cluster only if someone rebuilds it.

## Agent and CI guardrails

`AGENTS.md` says people merge, release and deploy; agents push a feature branch and open a pull request. `.factory/hooks.json` registers `.factory/hooks/guard_release_actions.py` as a `PreToolUse` hook for the `Execute` tool. The script exits with status 2, which blocks the command, when the command text matches merging or approving a pull request, merge or branch-protection calls through `gh api`, `gh release` changes, changing `kubectl` and `helm` commands, `docker push`, Maven `deploy`, publishing an image or Gradle artifacts, and force, mirror, tag or `main`/`master` pushes. Its docstring states the limits: it matches text, so it can be bypassed on purpose and also blocks commands that only mention an action, and it lets through any input it cannot parse. It does not see other tools, such as file edits. It is a guardrail, not an access control; `.factory/hooks/test_guard_release_actions.py` has 6 tests. [Development workflow](how-to-contribute/development-workflow.md) covers the pull request process.

CI secrets:

- **`FACTORY_API_KEY` in `.github/workflows/qa.yml`.** The job runs only for `workflow_dispatch` or when the pull request's head repository is this repository, so pull requests from forks skip it. Checkout uses `persist-credentials: false` so the GitHub token stays out of `.git/config`, because Droid runs with `--auto high`. The workflow token has `contents: read` and `pull-requests: write`, and only the comment step receives it as `GH_TOKEN`. The Droid step builds and runs the pull request's code and follows its `.factory/` skills with the key in its environment, and the commands it starts can read the key: in a local Droid session, the commands Droid ran saw a `FACTORY_API_KEY` variable (names checked, not values). Dependabot pull requests read Dependabot secrets instead, so storing the key there runs each dependency update with the key available to the new library versions (F21).
- **`FACTORY_API_KEY` and `FACTORY_WIKI_PR_TOKEN` in `.github/workflows/droid-wiki-refresh.yml`.** It runs on pushes to `main`. The `wiki-refresh` job, which runs Droid with the API key, has `contents: read` only. The separate `wiki-publish` job has `contents: write` and `pull-requests: write` and passes `FACTORY_WIKI_PR_TOKEN`, or the built-in token as a fallback, to the pull request action. `docs/DEPENDENCIES.md` notes that Droid sends the code it reads to Factory's API.
- `.github/workflows/maven-build.yml`, `.github/workflows/gradle-build.yml` and `.github/workflows/deploy-and-test-cluster.yml` have no `permissions:` block, so their token gets the repository's default permissions, which could not be checked (F22).

Review controls: `.github/dco.yml` sets `require.members: false`, so the DCO app checks sign-offs only for people outside the GitHub organization. The repository has no CODEOWNERS file, and branch protection on `main` could not be checked (F13).

## Open security follow-ups

All IDs come from the follow-ups table in `docs/RUNBOOK.md`, which has the evidence and suggested changes. [Pitfalls](background/pitfalls.md) collects them with other known traps.

| ID | Status | Issue |
| --- | --- | --- |
| F1 | Open | Every Actuator endpoint is exposed without authentication, locally and in Kubernetes. |
| F2 | Open | Readiness ignores the database, so traffic keeps reaching a pod whose database is down. |
| F3 | Open | Unknown owner or pet ids return 500 instead of 404. |
| F4 | Open | Kubernetes runs the untagged `dsyer/petclinic` image of unknown provenance. |
| F5 | Open | Plain-text database credentials in `k8s/db.yml`, and no persistent volume. |
| F6 | Open | Kubernetes credentials depend on Spring Cloud Bindings being in the image. |
| F8 | Open | MySQL in Compose allows an empty root password, and both Compose services publish their ports on all interfaces. |
| F13 | Open | No CODEOWNERS, and branch protection on `main` is unverified. |
| F14 | Open | Unmaintained Font Awesome 4.7.0 and deprecated LibSass. |
| F15 | Fixed in `0e8563f` | The vets page range is checked before the cached query. Remaining hardening: a size limit with `spring.cache.caffeine.spec`. |
| F21 | Open, waiting for an owner decision | `FACTORY_API_KEY` reaches the commands that Droid starts in the QA workflow, which matters if the key becomes a Dependabot secret. The Droid CLI is installed unpinned. |
| F22 | Open, waiting for an owner decision | Three workflows have no `permissions:` block. |

## Related pages

- [HTTP API](api.md): every route and Actuator endpoint.
- [Error handling](features/error-handling.md): error page, status codes, untrusted input tests.
- [Deployment](deployment.md): jar, image, Compose, Kubernetes and the CI deploy test.
- [Configuration](reference/configuration.md): properties, profiles and environment variables.
- [Dependencies](reference/dependencies.md): versions and the advisory table.
- [Caching](systems/caching.md): the `vets` cache.
- [How to monitor](how-to-monitor.md): health, info, metrics and the SBOM.

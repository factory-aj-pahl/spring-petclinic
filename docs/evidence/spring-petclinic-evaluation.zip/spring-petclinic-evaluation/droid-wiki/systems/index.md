# Systems

PetClinic has three internal building blocks under its features: the web layer that turns HTTP requests into pages, the persistence layer that stores owners, pets, visits and vets, and a small cache in front of the vets queries. This section describes each one. The user-visible behaviour built on top of them is in [Features](../features/index.md).

```mermaid
graph TD
    Browser[Browser or API client] -->|HTTP| Web[Web layer: DispatcherServlet, controllers, Thymeleaf]
    Web -->|find, save| Repos[Spring Data repositories]
    Repos -->|vets findAll| Cache[(Caffeine cache vets)]
    Repos -->|queries and merges| JPA[Hibernate JPA]
    JPA -->|JDBC through HikariCP| DB[(H2, MySQL or PostgreSQL)]
    Web -->|static files, webjars| Static[CSS, images, fonts]
```

## Persistence

[Persistence](persistence.md) covers the JPA entities in `src/main/java/org/springframework/samples/petclinic/model/`, `owner/` and `vet/`, the three repositories, where transactions start, the JPA settings in `src/main/resources/application.properties`, and the schema and seed scripts for H2, MySQL and PostgreSQL in `src/main/resources/db/`. It also explains the `mysql` and `postgres` profiles, the connection pool and what happens when the database is unreachable.

## Web layer

[Web layer](web-layer.md) covers the Spring MVC controllers and a table of every route, the Thymeleaf layout and form fragments in `src/main/resources/templates/fragments/`, the static files under `src/main/resources/static/resources/`, the Bootstrap and Font Awesome webjars, how `src/main/resources/static/resources/css/petclinic.css` is compiled from `src/main/scss/`, and the language interceptor.

## Caching

[Caching](caching.md) covers the `vets` cache on both `findAll` methods of `src/main/java/org/springframework/samples/petclinic/vet/VetRepository.java`. Spring Boot backs it with Caffeine, it never expires, and it keeps `/vets` working during a database outage. The page also explains why the JCache customizer in `src/main/java/org/springframework/samples/petclinic/system/CacheConfiguration.java` never runs.

## Related pages

- [Architecture](../overview/architecture.md) shows how the layers fit together and follows one request from browser to database.
- [Configuration](../reference/configuration.md) lists every property these systems read.
- [Data models](../reference/data-models.md) lists every table, column and constraint.

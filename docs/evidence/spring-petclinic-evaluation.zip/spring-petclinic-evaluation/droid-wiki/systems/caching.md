# Caching

Active contributors: Dave Syer, Moritz Halbritter, Patrick Baumgartner

PetClinic caches one thing: the list of vets. Both `findAll` methods of `VetRepository` are `@Cacheable("vets")`, Spring Boot backs the cache with Caffeine, and nothing ever evicts or expires an entry.

## Purpose

Vets are read on every visit to the vets page and the `/vets` resource, and the application never changes them, so the query results are kept in memory. The cache also keeps `/vets` working while the database is down. The code involved is two files: `src/main/java/org/springframework/samples/petclinic/system/CacheConfiguration.java` (53 lines, 11 commits from 7 people on `origin/main`) and `src/main/java/org/springframework/samples/petclinic/vet/VetRepository.java`. The only test that looks inside the cache is `UntrustedInputIntegrationTests.outOfRangeVetPagesAreNotCached` in `src/test/java/org/springframework/samples/petclinic/UntrustedInputIntegrationTests.java`.

## Key abstractions

| Type | File | What it is |
| --- | --- | --- |
| `CacheConfiguration` | `src/main/java/org/springframework/samples/petclinic/system/CacheConfiguration.java` | `@EnableCaching`, plus a `JCacheManagerCustomizer` bean that never runs |
| `VetRepository` | `src/main/java/org/springframework/samples/petclinic/vet/VetRepository.java` | `findAll()` and `findAll(Pageable)`, both `@Transactional(readOnly = true)` and `@Cacheable("vets")` |
| `CaffeineCacheManager` | Spring Boot auto-configuration | The cache manager that actually runs |

## Which provider runs

`@EnableCaching` in `CacheConfiguration` turns on Spring's cache abstraction, and `spring-boot-starter-cache` lets Spring Boot pick a provider from the classpath. The dependencies in `pom.xml` and `build.gradle` are:

| Dependency | Scope | Role |
| --- | --- | --- |
| `spring-boot-starter-cache` | compile | Cache auto-configuration |
| `com.github.ben-manes.caffeine:caffeine` (3.2.4) | runtime | The provider in use |
| `javax.cache:cache-api` (1.1.1) | compile | The JCache API only, with no implementation |

Spring Boot uses JCache only when a JCache provider (a `CachingProvider` implementation) is on the classpath. `cache-api` has none, so Spring Boot falls through to Caffeine and creates a `CaffeineCacheManager`. No `spring.cache.*` property is set anywhere in `src/main/resources/`, so the manager has no fixed cache names and no Caffeine spec: it creates the `vets` cache on first use with Caffeine's defaults, which means no size limit and no expiry. `docs/DEPENDENCIES.md` records that `/actuator/caches` reports a `CaffeineCacheManager` on a live run.

## The JCache customizer that never runs

`CacheConfiguration` declares a `JCacheManagerCustomizer` that would create the `vets` cache with `MutableConfiguration().setStatisticsEnabled(true)`, so that statistics show up over JMX. Spring Boot calls `JCacheManagerCustomizer` beans only while it configures a JCache cache manager, which never happens here. The bean exists but has no effect, and no cache statistics are enabled. This is follow-up F12 in `docs/RUNBOOK.md`.

The history explains it. The project used Ehcache, a JCache provider, until commit `f53e0d0` (2022-10-16, "Additional setup to support native image creation") replaced it with Caffeine because Caffeine works in GraalVM native images. The JCache customizer and the `cache-api` dependency stayed behind.

## How it works

```mermaid
graph TD
    VH["GET /vets.html?page=n"] -->|"findAll() to count the pages"| VR[VetRepository proxy]
    VH -->|"findAll(PageRequest n-1, 5), only for an existing page"| VR
    VJ["GET /vets"] -->|"findAll()"| VR
    VR -->|"lookup in cache vets"| C[(Caffeine cache vets)]
    C -->|hit| Ret[Return cached result]
    C -->|miss| H[Hibernate query]
    H -->|SELECT vets and specialties| DB[(Database)]
    H -->|store result| C
```

Both methods share the `vets` cache, with different keys from Spring's default key generator:

| Method | Cache key | Cached value |
| --- | --- | --- |
| `findAll()` | `SimpleKey.EMPTY` (no arguments) | The full `Collection<Vet>`, used by `/vets` and by the page count of `/vets.html` |
| `findAll(Pageable)` | The `PageRequest` itself (page index, size 5, unsorted) | One `Page<Vet>` per existing page, used by `/vets.html` |

### Page numbers and cache size (F15)

`VetController.showVetList` in `src/main/java/org/springframework/samples/petclinic/vet/VetController.java` first reads the cached full list, computes the last page from its size, and redirects any page below 1 or above the last page to `/vets.html?page=1`. Only an existing page reaches the cached paged query, so the cache holds at most the full list plus one entry per page: three entries with the six seeded vets.

Before commit `0e8563f` the controller ran the paged query first and checked the range afterwards. Every distinct page number from 1 to 429,496,729 then added an entry that was never removed, so any client could grow the heap (follow-up F15 in `docs/RUNBOOK.md`). Against the built jar, 5,000 different page numbers left 5,000 cached pages. Against the fixed jar, the same requests leave one, for page 2, the only one of them that exists. Two tests now pin the fix: `UntrustedInputIntegrationTests.outOfRangeVetPagesAreNotCached` requests pages 3 to 202 and checks that none of them is in the cache, and `VetControllerTests.showVetListRedirectsOutOfRangePagesWithoutQueryingThem` checks that out-of-range pages never call `findAll(Pageable)`. The cache itself still has no size limit, so a new cached query with arguments from the client would bring the problem back; see [Entry points for modification](#entry-points-for-modification). [Pitfalls](../background/pitfalls.md) tracks traps of this kind.

## No eviction, no expiry

The code has no `@CacheEvict` or `@CachePut`, no `spring.cache.caffeine.spec`, and the application has no way to write vets. Once loaded, the vet list stays the same for the life of the process. A vet inserted or changed directly in the database does not appear on `/vets` or `/vets.html` until the application restarts or someone clears the cache through Actuator. On H2 this does not matter, because the database is rebuilt at every start.

## During a database outage

`src/test/java/org/springframework/samples/petclinic/PostgresOutageIntegrationTests.java` calls `/vets` once while PostgreSQL is up, stops the container, and asserts that `/vets` still returns 200 ("vets list served from the cache") while `/owners/1` returns the error page and `/actuator/health` returns 503. Only results that were cached before the outage are served: a `/vets.html` page that nobody requested beforehand needs the database and fails. The full failure table is in `docs/RUNBOOK.md` and the database side is on [Persistence](persistence.md).

## Inspect and clear the cache

Actuator exposes every endpoint (`management.endpoints.web.exposure.include=*` in `src/main/resources/application.properties`), including `caches`:

```bash
curl http://localhost:8080/actuator/caches
curl http://localhost:8080/actuator/caches/vets
curl -X DELETE http://localhost:8080/actuator/caches/vets
```

The first two list the cache manager and the `vets` cache; the `DELETE` clears it, so the next request reloads vets from the database. The endpoint has no authentication, so anyone who can reach the application can clear the cache (follow-up F1). `/actuator/caches` lists only caches that exist, so `vets` appears after the first vets request. Spring Boot can publish cache metrics under `/actuator/metrics`, but Caffeine counts hits and misses only when `recordStats` is configured, which it is not here; whether `cache.*` metrics appear at all was not checked. See [How to monitor](../how-to-monitor.md).

## Integration points

- **Repositories.** The annotations sit on the `VetRepository` interface methods and apply to the Spring Data proxy.
- **Web layer.** `VetController` is the only caller; see [Web layer](web-layer.md) and [Vets](../features/vets.md).
- **Tests.** `PetClinicIntegrationTests`, `MySqlIntegrationTests` and `PostgresIntegrationTests` call `vets.findAll()` twice with the comment "served from cache" but do not assert that the second call skips the database. `VetControllerTests` mocks the repository, so the cache is not involved. `UntrustedInputIntegrationTests.outOfRangeVetPagesAreNotCached` reads the `vets` cache from the `CacheManager` to check that out-of-range pages leave no entry.

## Entry points for modification

To bound or expire the cache, set `spring.cache.cache-names=vets` and a `spring.cache.caffeine.spec` such as `maximumSize=100,expireAfterWrite=10m,recordStats` in `src/main/resources/application.properties`; `recordStats` also gives real hit and miss counts. `docs/RUNBOOK.md` suggests this limit as the remaining part of F15. Then delete the `JCacheManagerCustomizer` bean and, if nothing else needs it, the `cache-api` dependency from both build files, as F12 suggests. To cache another query, add `@Cacheable` with a new cache name on the repository method.

## Key source files

| File | Purpose |
| --- | --- |
| `src/main/java/org/springframework/samples/petclinic/system/CacheConfiguration.java` | Enables caching; unused JCache customizer |
| `src/main/java/org/springframework/samples/petclinic/vet/VetRepository.java` | The two cached methods |
| `src/main/java/org/springframework/samples/petclinic/vet/VetController.java` | The callers, including the page range check before the paged query |
| `pom.xml`, `build.gradle` | `spring-boot-starter-cache`, Caffeine, `cache-api` |
| `src/test/java/org/springframework/samples/petclinic/PostgresOutageIntegrationTests.java` | Proves `/vets` is served from the cache during an outage |
| `src/test/java/org/springframework/samples/petclinic/UntrustedInputIntegrationTests.java` | Checks that out-of-range `/vets.html` pages are not cached |
| `docs/RUNBOOK.md` | Follow-ups F1, F12 and F15 |

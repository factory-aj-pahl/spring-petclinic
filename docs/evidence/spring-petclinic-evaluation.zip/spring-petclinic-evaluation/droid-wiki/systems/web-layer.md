# Web layer

Active contributors: shivam tiwari, jang8584, Patrick Baumgartner

PetClinic's web layer is plain Spring MVC on embedded Tomcat. Six controllers map 17 routes, Thymeleaf renders 12 templates inside one shared layout, and Spring Boot serves the CSS, images, fonts and webjars from the classpath.

## Purpose

The web layer turns HTTP requests into repository calls and HTML pages, plus one JSON and XML resource (`/vets`). It holds no business logic of its own beyond form checks; controllers call the repositories directly (see [Patterns and conventions](../how-to-contribute/patterns-and-conventions.md)). The six controllers and `WebConfiguration` are 721 lines; their tests (`*ControllerTests`, `I18nPropertiesSyncTest`, `UntrustedInputIntegrationTests`) are about 1,180 lines. On `origin/main` the templates have 40 commits from 21 people, and the SCSS styles 11 commits from 2 people.

## Directory layout

```text
src/main/java/org/springframework/samples/petclinic/
  owner/   OwnerController, PetController, VisitController, PetValidator, PetTypeFormatter
  vet/     VetController, Vets (JSON/XML wrapper)
  system/  WelcomeController, CrashController, WebConfiguration
src/main/resources/
  templates/
    fragments/  layout.html, inputField.html, selectField.html
    owners/     findOwners, ownersList, ownerDetails, createOrUpdateOwnerForm
    pets/       createOrUpdatePetForm, createOrUpdateVisitForm
    vets/       vetList
    welcome.html, error.html
  static/resources/
    css/        petclinic.css (compiled, 9,531 lines)
    fonts/      montserrat-webfont.*, varela_round-webfont.* (eot, svg, ttf, woff)
    images/     favicon.png, pets.png, spring-logo.svg, spring-logo-dataflow.png, spring-logo-dataflow-mobile.png
src/main/scss/  petclinic.scss, header.scss, typography.scss, responsive.scss
```

## Key abstractions

| Type | File | What it is |
| --- | --- | --- |
| `OwnerController` | `src/main/java/org/springframework/samples/petclinic/owner/OwnerController.java` | Owner search, list, details, create and edit |
| `PetController` | `src/main/java/org/springframework/samples/petclinic/owner/PetController.java` | Add and edit pets, under `@RequestMapping("/owners/{ownerId}")` |
| `VisitController` | `src/main/java/org/springframework/samples/petclinic/owner/VisitController.java` | Book a visit |
| `VetController` | `src/main/java/org/springframework/samples/petclinic/vet/VetController.java` | Paged vets page and the `/vets` resource |
| `WelcomeController` | `src/main/java/org/springframework/samples/petclinic/system/WelcomeController.java` | Maps `/` to the `welcome` view |
| `CrashController` | `src/main/java/org/springframework/samples/petclinic/system/CrashController.java` | `/oups` throws a `RuntimeException` to show the error page |
| `WebConfiguration` | `src/main/java/org/springframework/samples/petclinic/system/WebConfiguration.java` | `SessionLocaleResolver` and the `lang` interceptor |
| `PetTypeFormatter` | `src/main/java/org/springframework/samples/petclinic/owner/PetTypeFormatter.java` | `@Component` `Formatter<PetType>` that Spring Boot registers for form binding |
| `layout` fragment | `src/main/resources/templates/fragments/layout.html` | Page frame, navigation bar and scripts |

## Routes

Every `@GetMapping` and `@PostMapping` in `src/main/java`. Controllers return view names that resolve to `src/main/resources/templates/<name>.html`.

| Method | Path | Handler | View or response |
| --- | --- | --- | --- |
| GET | `/` | `WelcomeController.welcome` | `welcome` |
| GET | `/oups` | `CrashController.triggerException` | Throws; Spring Boot renders `error` with HTTP 500 |
| GET | `/owners/find` | `OwnerController.initFindForm` | `owners/findOwners` |
| GET | `/owners?lastName=&page=` | `OwnerController.processFindForm` | `owners/ownersList`; `owners/findOwners` with "has not been found"; redirect to `/owners/{id}` for one match; redirect to page 1 when out of range |
| GET | `/owners/new` | `OwnerController.initCreationForm` | `owners/createOrUpdateOwnerForm` |
| POST | `/owners/new` | `OwnerController.processCreationForm` | The form on errors, else redirect to `/owners/{id}` |
| GET | `/owners/{ownerId}` | `OwnerController.showOwner` | `owners/ownerDetails` (a `ModelAndView`) |
| GET | `/owners/{ownerId}/edit` | `OwnerController.initUpdateOwnerForm` | `owners/createOrUpdateOwnerForm` |
| POST | `/owners/{ownerId}/edit` | `OwnerController.processUpdateOwnerForm` | The form on errors, redirect to `/owners/{ownerId}/edit` on an id mismatch, else redirect to `/owners/{ownerId}` |
| GET | `/owners/{ownerId}/pets/new` | `PetController.initCreationForm` | `pets/createOrUpdatePetForm` |
| POST | `/owners/{ownerId}/pets/new` | `PetController.processCreationForm` | The form on errors, else redirect to `/owners/{ownerId}` |
| GET | `/owners/{ownerId}/pets/{petId}/edit` | `PetController.initUpdateForm` | `pets/createOrUpdatePetForm` |
| POST | `/owners/{ownerId}/pets/{petId}/edit` | `PetController.processUpdateForm` | The form on errors, else redirect to `/owners/{ownerId}` |
| GET | `/owners/{ownerId}/pets/{petId}/visits/new` | `VisitController.initNewVisitForm` | `pets/createOrUpdateVisitForm` |
| POST | `/owners/{ownerId}/pets/{petId}/visits/new` | `VisitController.processNewVisitForm` | The form on errors, else redirect to `/owners/{ownerId}` |
| GET | `/vets.html?page=` | `VetController.showVetList` | `vets/vetList`, or redirect to `/vets.html?page=1` when out of range |
| GET | `/vets` | `VetController.showResourcesVetList` | `@ResponseBody Vets`, written as JSON or XML |

Spring Boot adds `/error` and the Actuator endpoints under `/actuator/**`; [HTTP API](../api.md) lists those. The behaviour of each page is on the feature pages: [Owners](../features/owners.md), [Pets](../features/pets.md), [Visits](../features/visits.md), [Vets](../features/vets.md) and [Error handling](../features/error-handling.md).

## How a request is handled

```mermaid
graph TD
    T[Tomcat] --> DS[DispatcherServlet]
    DS -->|preHandle| LCI[LocaleChangeInterceptor: lang]
    DS -->|"@ModelAttribute, @InitBinder"| C[Controller]
    C -->|find, save| R[Repositories]
    C -->|view name| TL[Thymeleaf]
    TL -->|th:replace| L[fragments/layout.html]
    C -->|"@ResponseBody Vets"| MC[Jackson or JAXB converter]
    DS -->|exception| E[Spring Boot error handling: error.html]
```

`@ModelAttribute` methods run before every handler in their controller. In `OwnerController`, `findOwner` returns a new `Owner` when the path has no `ownerId`, which is how the search form's `lastName` binds on `/owners`, and otherwise loads the owner (so `/owners/{ownerId}` reads the owner twice: once there and once in `showOwner`). `@InitBinder` methods disallow `id` and `*.id`, and `PetController` also sets `PetValidator` on the `pet` binder. The form controller pattern is described in [Patterns and conventions](../how-to-contribute/patterns-and-conventions.md).

### Content negotiation for `/vets`

`showResourcesVetList` returns a `Vets` object, the `@XmlRootElement` wrapper in `src/main/java/org/springframework/samples/petclinic/vet/Vets.java`. Spring MVC picks the message converter from the `Accept` header: Jackson 3 writes JSON, and the JAXB converter writes XML. JAXB works because `jakarta.xml.bind-api` is declared in `pom.xml` and `build.gradle`, and `jaxb-runtime` 4.0.9 arrives through `hibernate-core` (SBOM `target/classes/META-INF/sbom/application.cdx.json`). Other media types such as `text/csv` get HTTP 406. `src/test/java/org/springframework/samples/petclinic/vet/VetControllerTests.java` tests only the JSON case; the XML and 406 cases are checked by the QA flow A1 in `.factory/skills/qa-api/SKILL.md`. Which format a request without an `Accept` header gets depends on converter order and is not confirmed here.

### Interceptors

`WebConfiguration` registers one interceptor, a `LocaleChangeInterceptor` on the parameter `lang`, and a `SessionLocaleResolver` with English as the default. Any URL with `?lang=de` switches the session's language. [Internationalization](../features/internationalization.md) has the details.

## Templates and fragments

`spring.thymeleaf.mode=HTML` in `src/main/resources/application.properties` sets HTML mode (also Spring Boot's default). Every page template is a full HTML file whose root element replaces itself with the layout:

```html
<html xmlns:th="https://www.thymeleaf.org" th:replace="~{fragments/layout :: layout (~{::body},'owners')}">
```

| Fragment | File | Arguments | What it does |
| --- | --- | --- | --- |
| `layout (template, menu)` | `src/main/resources/templates/fragments/layout.html` | The page body; the active menu name | Head with favicon, Font Awesome CSS and `src/main/resources/static/resources/css/petclinic.css`; navigation bar; the body; Spring logo; `bootstrap.bundle.min.js` |
| `menuItem (link, active, title, glyph, text)` | Same file, inside a `th:remove="all"` list so the template copy never renders | Link, menu name, tooltip, Font Awesome icon name, label | One navigation entry; it gets `nav-link active` when `active` equals the layout's `menu` argument |
| `input (label, name, type)` | `src/main/resources/templates/fragments/inputField.html` | Label, field name, `'text'` or `'date'` | Bound input with error class and message; date inputs get `min` from `minVisitDate` |
| `select (label, name, items)` | `src/main/resources/templates/fragments/selectField.html` | Label, field name, items | Bound `<select>` with error class and message |

The menu names in use are `home` (`src/main/resources/templates/welcome.html`), `owners` (all owner and pet pages), `vets` (`vets/vetList.html`) and `error` (`src/main/resources/templates/error.html`). The navigation bar has four entries: Home, Find owners, Veterinarians and Error (`/oups`). Labels come from message keys. A few form labels and buttons, such as `'Name'`, `'Birth Date'` and `'Add Pet'` in `src/main/resources/templates/pets/createOrUpdatePetForm.html`, are literal strings passed to fragments. `src/test/java/org/springframework/samples/petclinic/system/I18nPropertiesSyncTest.java` does not catch them, because it only flags text between tags (`>text<`) on lines without `#{` or `th:text`; strings inside attributes pass. The test also walks the Java files in `src/main` but applies no check to them.

## Static resources and webjars

Spring Boot serves `src/main/resources/static/` at the root, so `static/resources/css/petclinic.css` is `/resources/css/petclinic.css`. Templates link them with `@{/resources/...}`.

The webjars are runtime dependencies in `pom.xml` (and `build.gradle`) and are served under `/webjars/`. `webjars-locator-lite` 1.1.3 lets templates leave out the version:

| Webjar | Version | Used as |
| --- | --- | --- |
| `org.webjars.npm:bootstrap` | 5.3.8 (`webjars-bootstrap.version`) | `/webjars/bootstrap/dist/js/bootstrap.bundle.min.js` in the layout; its SCSS is compiled into `src/main/resources/static/resources/css/petclinic.css` |
| `org.webjars.npm:font-awesome` | 4.7.0 (`webjars-font-awesome.version`) | `/webjars/font-awesome/css/font-awesome.min.css`; icons such as `fa-search` and `fa-th-list` |

There are no CDN links. `spring.web.resources.cache.cachecontrol.max-age=12h` makes Spring Boot send `Cache-Control: max-age=43200` for files served by its resource handlers, which covers `/resources/**` and `/webjars/**`. URLs carry no content hash, so after a CSS change a browser can show the old file for up to 12 hours.

## Styles

`src/main/resources/static/resources/css/petclinic.css` is a generated file checked into Git. Its source is `src/main/scss/petclinic.scss`, which imports Bootstrap's SCSS, overrides colours and spacing with the Spring palette, and imports `src/main/scss/typography.scss` (the Montserrat and Varela Round fonts), `src/main/scss/header.scss` (navigation bar and logo sprite) and `src/main/scss/responsive.scss`. The compiled file's header says Bootstrap v5.3.8.

To rebuild it, run the Maven `css` profile:

```bash
./mvnw package -P css
```

The profile in `pom.xml` unpacks the Bootstrap webjar into `target/webjars` with `maven-dependency-plugin`, then runs `libsass-maven-plugin` 0.3.4 in `generate-resources` to compile `src/main/scss/` into `src/main/resources/static/resources/css/`. Gradle has no equivalent task (`build.gradle`, and `README.md` says the same), so a CSS change must be compiled with Maven and committed. LibSass is deprecated upstream (follow-up F14 in `docs/RUNBOOK.md`). Some variables in `src/main/scss/petclinic.scss`, such as `$navbar-default-link-color` and `$icon-font-path`, are Bootstrap 3 names; whether Bootstrap 5 still reads them was not checked.

## Integration points

- **Persistence.** Controllers get detached entities, so templates rely on eager loading; see [Persistence](persistence.md).
- **Caching.** `/vets` and `/vets.html` read through the `vets` cache; see [Caching](caching.md).
- **Errors.** There is no `@ControllerAdvice`; exceptions go to Spring Boot's error handling and `src/main/resources/templates/error.html`.
- **Messages.** All visible text should come from `src/main/resources/messages/`; see [Internationalization](../features/internationalization.md).

## Entry points for modification

A new page needs a handler in the feature's controller, a template that calls the `layout` fragment with the right menu name, and message keys in all 11 bundles. Use `src/main/resources/templates/fragments/inputField.html` and `src/main/resources/templates/fragments/selectField.html` for form fields so errors display the same way. For style changes, edit `src/main/scss/`, run `./mvnw package -P css`, and commit both the SCSS and the regenerated CSS.

## Key source files

| File | Purpose |
| --- | --- |
| `src/main/java/org/springframework/samples/petclinic/owner/OwnerController.java` | Owner routes and paging |
| `src/main/java/org/springframework/samples/petclinic/owner/PetController.java` | Pet routes and duplicate-name handling |
| `src/main/java/org/springframework/samples/petclinic/owner/VisitController.java` | Visit routes |
| `src/main/java/org/springframework/samples/petclinic/vet/VetController.java` | Vets page and JSON/XML resource |
| `src/main/java/org/springframework/samples/petclinic/system/WebConfiguration.java` | Locale resolver and interceptor |
| `src/main/resources/templates/fragments/layout.html` | Shared layout and `menuItem` fragment |
| `src/main/resources/templates/fragments/inputField.html` | Text and date input fragment |
| `src/main/resources/templates/fragments/selectField.html` | Select fragment |
| `src/main/scss/petclinic.scss` | Style source |
| `pom.xml` | Webjar versions and the `css` profile |

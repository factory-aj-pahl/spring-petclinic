# Patterns and conventions

PetClinic is small, and its code follows a few patterns consistently. Follow them when you add a page or a field, so the new code looks like the rest. `AGENTS.md` has the short version for coding agents.

## Code organization

- **Packages by feature.** Each feature keeps its entity, controller, repository and helpers in one package under `src/main/java/org/springframework/samples/petclinic/`: `owner`, `vet` and `system`, plus `model` for shared base classes. Controllers are package-private (`class OwnerController`), so nothing outside the package uses them.
- **No service layer.** Controllers call Spring Data repositories directly, for example `OwnerController` uses `OwnerRepository` in `src/main/java/org/springframework/samples/petclinic/owner/OwnerController.java`. Add a service class only if logic needs to be shared between controllers.
- **Constructor injection.** Each controller takes its repositories as `final` constructor parameters. There is no `@Autowired` on fields.
- **Repositories are interfaces.** `OwnerRepository` extends `JpaRepository` and uses derived queries such as `findByLastNameStartingWith`. `VetRepository` extends the minimal `Repository` interface, so the application cannot change vets. `PetTypeRepository` has one JPQL query.

## Controller pattern

Every form controller (`OwnerController`, `PetController`, `VisitController`) has the same shape:

```mermaid
graph LR
    A["@ModelAttribute loaders"] -->|owner, pet, types| B["@InitBinder: disallow id"]
    B --> C["@Valid binding and validation"]
    C -->|errors| D[Return the form view]
    C -->|valid| E[Save through the repository]
    E --> F[Redirect with a flash message]
```

1. **Load before every handler.** `@ModelAttribute` methods read path variables and load the owner, pet or pet types into the model. For example `VisitController.loadPetWithVisit` in `src/main/java/org/springframework/samples/petclinic/owner/VisitController.java` loads the owner and pet and attaches a new `Visit`.
2. **Protect ids.** `@InitBinder` calls `dataBinder.setDisallowedFields("id", "*.id")`, so a form post cannot set or change a database id. Keep this in any new form controller.
3. **Validate.** `@Valid` runs Bean Validation on the entity, and `PetController` also registers `PetValidator`. Rules that need the database or the current date live in the handler and report through `BindingResult.rejectValue(field, code, defaultMessage)`, for example the duplicate pet name and the birth date in the future in `src/main/java/org/springframework/samples/petclinic/owner/PetController.java`.
4. **Post, redirect, get.** On success the handler saves, adds a flash attribute named `message` ("New Owner Created", "Owner Values Updated", "New Pet has been Added", "Pet details has been edited", "Your visit has been booked") and redirects to the owner page. `src/main/resources/templates/owners/ownerDetails.html` shows the message and hides it after 3 seconds.
5. **On errors, return the view name.** The form is rendered again with the bound values and a message under each invalid field.

## Validation rules live on the entities

| Field | Rule | Where |
| --- | --- | --- |
| First and last name | Required, at most 30 characters | `@NotBlank @Size(max = 30)` in `src/main/java/org/springframework/samples/petclinic/model/Person.java` |
| Address, city | Required, at most 255 and 80 characters | `src/main/java/org/springframework/samples/petclinic/owner/Owner.java` |
| Telephone | Exactly 10 digits, message key `telephone.invalid` | `@Pattern(regexp = "\\d{10}")` in `src/main/java/org/springframework/samples/petclinic/owner/Owner.java` |
| Pet name, type, birth date | Name required and at most 30 characters; type required for new pets; birth date required and not in the future | `src/main/java/org/springframework/samples/petclinic/owner/PetValidator.java`, `src/main/java/org/springframework/samples/petclinic/owner/PetController.java` |
| Visit | Description required, at most 255 characters; date after today | `src/main/java/org/springframework/samples/petclinic/owner/Visit.java`, `src/main/java/org/springframework/samples/petclinic/owner/VisitController.java` |

The size limits match the `VARCHAR` sizes in `src/main/resources/db/h2/schema.sql` and `src/main/resources/db/mysql/schema.sql`. The PostgreSQL schema (`src/main/resources/db/postgres/schema.sql`) uses `TEXT`, so there the entity annotations are the only limit. When you add a column, add the same limit to the entity, or a long value causes a database error and an HTTP 500 instead of a form message. The database also enforces unique pet names per owner. On H2 and PostgreSQL the constraint is named `unique_owner_pet_name`, and `PetController` turns its violation into a form error; the MySQL constraint has no name, so there the violation is rethrown (follow-up F17 in `docs/RUNBOOK.md`).

## Paging

Lists show 5 rows per page, and both paged handlers redirect page numbers below 1 or past the last page to page 1. The owner list (`src/main/java/org/springframework/samples/petclinic/owner/OwnerController.java`) clamps the page to `Integer.MAX_VALUE / pageSize` before it builds a `PageRequest`, because Spring Data JPA rejects larger offsets. The vets list (`src/main/java/org/springframework/samples/petclinic/vet/VetController.java`) checks the page against the number of vets before it runs the paged query, because that query is cached and every page number it sees becomes a cache entry (F15). For a new paged list, check the range before the query whenever the query is cached.

## Errors

An unknown owner id, or an unknown pet id on the visit routes, makes the `@ModelAttribute` loaders throw `IllegalArgumentException`. An unknown pet id on the pet edit route is different: `PetController.findPet` returns `null` and the request fails later. In both cases Spring Boot's error handling renders `src/main/resources/templates/error.html`, which never shows exception details. There is no `@ControllerAdvice`, so an unknown owner or pet id gives HTTP 500 rather than 404 (follow-up F3 in `docs/RUNBOOK.md`). [Error handling](../features/error-handling.md) has the full list of status codes.

## Templates and text

- Every page starts with `th:replace="~{fragments/layout :: layout (~{::body},'owners')}"`; the second argument selects the active menu item in `src/main/resources/templates/fragments/layout.html`.
- Form fields use the fragments `src/main/resources/templates/fragments/inputField.html` and `src/main/resources/templates/fragments/selectField.html`, which add the error styling and messages.
- Visible text should come from message keys, as in `th:text="#{findOwners}"`, with English defaults in `src/main/resources/messages/messages.properties`. `src/test/java/org/springframework/samples/petclinic/system/I18nPropertiesSyncTest.java` fails the build on literal text between HTML tags and on keys missing from any of the nine translations (it skips `src/main/resources/messages/messages_en.properties`, which is empty on purpose), so add every new key to all of them. The test does not check Java code or literals passed as fragment arguments, and some pet and visit form labels are still English literals (follow-up F19). See [Internationalization](../features/internationalization.md).

## Java style

- `spring-javaformat` enforces Spring's formatting (tabs, braces, line breaks). The build fails on differences; run `./mvnw spring-javaformat:apply` before committing.
- Java files start with the Apache License 2.0 header (three files lack it, see [Cleanup opportunities](../cleanup-opportunities.md)), and classes carry `@author` tags.
- Fields are referenced with `this.` in most classes.
- No logging in the application code: there are no loggers in `src/main/java`. Errors reach the log through Spring Boot's own handlers.

## Tests

Test classes end in `Tests` (one exception, `I18nPropertiesSyncTest`) and most sit in the same package as the code they test; `ClinicServiceTests` tests the repositories from its own `service` package. Controller tests are `@WebMvcTest` slices with MockMvc and `@MockitoBean` repositories, repository tests use `@DataJpaTest`, and end-to-end tests use `@SpringBootTest` with a random port. Most assertions use AssertJ; the MockMvc tests use Spring's result matchers. For a bug fix, write the failing test first. [Testing](testing.md) explains each layer.

## Commits and documents

- Sign off every commit with `git commit -s`. `.github/dco.yml` configures the DCO app, which checks pull requests for `Signed-off-by`; its `require.members: false` setting exempts members of the GitHub organization, and `AGENTS.md` asks for the sign-off anyway.
- Keep one purpose per commit and explain the reason in the message.
- When you add, remove or upgrade a dependency or an outside service, update `docs/DEPENDENCIES.md`; when operations change, update `docs/RUNBOOK.md`.
- Change a dependency version in `pom.xml` and `build.gradle` together.

[Development workflow](development-workflow.md) describes the full cycle from branch to pull request.

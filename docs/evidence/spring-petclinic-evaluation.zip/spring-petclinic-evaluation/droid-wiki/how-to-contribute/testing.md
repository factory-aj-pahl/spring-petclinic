# Testing

PetClinic has 116 automated JUnit 5 tests, from plain unit tests to full application tests against real MySQL and PostgreSQL containers, plus a Droid QA skill that uses the running application like a person would. Three test classes need Docker; without it they do not run and the build still passes, so always say which tests were skipped.

## Test layers

```mermaid
graph TD
    U[Unit tests: validators, formatter, entities] --> S["Slice tests: @WebMvcTest controllers, @DataJpaTest repositories"]
    S --> I["Full application: @SpringBootTest on H2"]
    I --> C["Containers: MySQL and PostgreSQL (needs Docker)"]
    C --> Q[QA skill: browser and curl against a running jar]
    I -.->|no Docker needed| F[Failure scenarios and version guard]
```

| Layer | Tools | Speed |
| --- | --- | --- |
| Unit | JUnit 5, AssertJ, Mockito (`@ExtendWith(MockitoExtension.class)`) | Milliseconds |
| Controller slice | `@WebMvcTest`, MockMvc, `@MockitoBean` repositories | Fast, no database |
| Repository slice | `@DataJpaTest` with `@AutoConfigureTestDatabase(replace = Replace.NONE)`, so the configured H2 database and its scripts are used | Fast |
| Full application | `@SpringBootTest(webEnvironment = RANDOM_PORT)` with `RestTemplate` or `TestRestTemplate` | Seconds per context |
| Containers | Testcontainers, Spring Boot Docker Compose support, `@ServiceConnection` | Slow, needs Docker |
| QA | Droid `qa` skill, agent-browser, curl | Minutes, not part of the build |

## Every test class

All paths are under `src/test/java/org/springframework/samples/petclinic/`.

| Class | Type | What it covers | Needs Docker |
| --- | --- | --- | --- |
| `owner/OwnerControllerTests.java` | `@WebMvcTest` | Owner create and edit forms, field-length errors, search by last name (whitespace, no match, single match), paging bounds and huge page numbers, owner details, the id-mismatch branch | No |
| `owner/PetControllerTests.java` | `@WebMvcTest` | Pet create and update forms: blank name, duplicate name, missing type, invalid birth date, unique-constraint violation | No |
| `owner/VisitControllerTests.java` | `@WebMvcTest` | Visit form, missing fields, date not in the future, description too long | No |
| `owner/PetValidatorTests.java` | Unit (Mockito) | `PetValidator` rules for name, type, birth date and name length | No |
| `owner/PetTypeFormatterTests.java` | Unit (Mockito) | Printing and parsing pet types, unknown type | No |
| `owner/OwnerTests.java` | Unit | `Owner.addPet` adds a persisted pet and rejects a duplicate | No |
| `vet/VetControllerTests.java` | `@WebMvcTest` | `/vets.html` list, out-of-range and huge page numbers redirected before the paged query, the `PageRequest` for a real page, `/vets` JSON | No |
| `vet/VetTests.java` | Unit | `Vet` Java serialization | No |
| `model/ValidatorTests.java` | Unit (Bean Validation) | Empty first and last names are rejected | No |
| `service/ClinicServiceTests.java` | `@DataJpaTest` on H2 | Repository queries and saves: owners by last name, pets, pet types, vets, visits, duplicate pet names per owner | No |
| `service/EntityUtils.java` | Helper | Finds an entity by id in a collection; not a test | No |
| `system/WelcomeControllerTests.java` | `@WebMvcTest` | The welcome page | No |
| `system/CrashControllerTests.java` | Unit | `/oups` handler throws | No |
| `system/CrashControllerIntegrationTests.java` | `@SpringBootTest` without a database | JSON error body and HTML error page for `/oups` | No |
| `system/I18nPropertiesSyncTest.java` | File scan | Literal text between HTML tags in templates, and keys missing from a message bundle | No |
| `src/test/java/org/springframework/samples/petclinic/PetClinicIntegrationTests.java` | `@SpringBootTest` on H2 | Vets query twice, `/owners/1` and `/owners?lastName=` return 200; `main` starts the app for IDE use | No |
| `src/test/java/org/springframework/samples/petclinic/PetClinicConcurrencyTests.java` | `@SpringBootTest` on H2 | Two simultaneous requests add the same pet name; exactly one succeeds | No |
| `src/test/java/org/springframework/samples/petclinic/UntrustedInputIntegrationTests.java` | `@SpringBootTest` on H2 | Status codes and hidden details for bad page numbers, malformed numbers and unknown ids; out-of-range vets pages leave no cache entry | No |
| `src/test/java/org/springframework/samples/petclinic/DatabaseUnavailableAtStartupTests.java` | `SpringApplication` run | Startup with `mysql` and `postgres` profiles fails fast when nothing listens | No |
| `src/test/java/org/springframework/samples/petclinic/PatchedDependencyVersionsTests.java` | Classpath check | Six libraries resolve at or above their first patched versions | No |
| `src/test/java/org/springframework/samples/petclinic/MySqlIntegrationTests.java` | `@SpringBootTest`, Testcontainers `mysql:9.7` | Vets query and `/owners/1` on MySQL | Yes |
| `src/test/java/org/springframework/samples/petclinic/PostgresIntegrationTests.java` | `@SpringBootTest`, Docker Compose `postgres` service | Vets query and `/owners/1` on PostgreSQL; `main` starts the app for IDE use | Yes |
| `src/test/java/org/springframework/samples/petclinic/PostgresOutageIntegrationTests.java` | `@SpringBootTest`, Testcontainers `postgres:18.4` | Database stopped and restarted while the app runs | Yes |
| `src/test/java/org/springframework/samples/petclinic/MysqlTestApplication.java` | Test configuration | Declares a Testcontainers MySQL bean for the `mysql` profile and a `main` method; not a test | Yes, when used |

Most controller and container tests carry `@DisabledInNativeImage` and `@DisabledInAotMode`, so they do not run in a native or AOT test run. [Patterns and conventions](patterns-and-conventions.md#tests) covers naming and assertion style.

## Running tests

| Goal | Command |
| --- | --- |
| Everything, with the format and nohttp checks and coverage | `./mvnw verify` |
| One class | `./mvnw test -Dtest=OwnerControllerTests` |
| Everything with Gradle | `./gradlew build` |
| Only Gradle tests | `./gradlew test` |
| The Droid hook's own tests (Python) | `python3 -B -m unittest discover -s .factory/hooks` |

On commit `2aff817`, with Docker running, `./mvnw clean verify` ran 116 tests with 0 failures, 0 errors and 0 skipped in 1 minute 1 second, and `./gradlew clean build` ran 116 tests with 0 failures in 1 minute 26 seconds. The hook's 6 Python tests passed.

### With and without Docker

- **With Docker**, all 116 tests run.
- **Without Docker**, `docs/RUNBOOK.md` reports that the MySQL tests show as skipped and the PostgreSQL tests are not counted at all, so the total drops and the build still passes. `MySqlIntegrationTests` and `PostgresOutageIntegrationTests` use `@Testcontainers(disabledWithoutDocker = true)`; `PostgresIntegrationTests` uses `assumeTrue(DockerClientFactory.instance().isDockerAvailable(), ...)` in a `@BeforeAll` method.

`AGENTS.md` asks you to report skipped tests as skipped, not to count them as passed. Follow-up F9 in `docs/RUNBOOK.md` suggests failing CI when they are skipped; nothing enforces that today.

### How the container tests get a database

| Test | Mechanism |
| --- | --- |
| `MySqlIntegrationTests` | A static `@Container @ServiceConnection` `MySQLContainer` (`mysql:9.7`); Spring Boot points the data source at it. Also activates the `mysql` profile. |
| `MysqlTestApplication` | A `@Bean @ServiceConnection @Profile("mysql")` container. Because it is a `@Configuration` on the test classpath, any test with the `mysql` profile gets this container instead of the configured URL (F10). `DatabaseUnavailableAtStartupTests` excludes it with a `TypeExcludeFilter` for that reason. |
| `PostgresIntegrationTests` | Spring Boot's Docker Compose support (`spring-boot-docker-compose`) starts the `postgres` service from `docker-compose.yml` with `--force-recreate,--renew-anon-volumes`. |
| `PostgresOutageIntegrationTests` | A `GenericContainer` running `postgres:18.4` on a fixed host port, so the address stays the same after the test stops and restarts it through the Docker client. |

## Failure-scenario tests and the version guard

Commit `23d0c67` added four test classes that pin down behavior under bad input, missing databases and vulnerable dependencies. [Error handling](../features/error-handling.md#failure-scenario-tests-on-this-branch) describes the first three in detail.

- `UntrustedInputIntegrationTests`: out-of-range pages redirect to page 1, malformed numbers give 400, unknown ids give the 500 error page (F3), and no response shows exception text, stack lines or JDBC URLs. Commit `0e8563f` added a check that out-of-range `/vets.html` pages leave no entry in the `vets` cache (F15).
- `DatabaseUnavailableAtStartupTests`: the application exits within 20 seconds with a `ConnectException` root cause when its database is unreachable.
- `PostgresOutageIntegrationTests`: during an outage, database pages give a clean 500, `/vets` still works from the cache, `/actuator/health` gives 503, and everything recovers without a restart.
- `PatchedDependencyVersionsTests`: reads `Implementation-Version` from the jar manifests on the test classpath and fails if `tomcat-embed-core` is below 11.0.25, `spring-webmvc` below 7.0.9, `jackson-databind` or `jackson-core` below 3.1.7, `postgresql` below 42.7.12 or `log4j-api` below 2.25.5. A second test checks the numeric version comparison. Raise a minimum when an upgrade fixes a new advisory; never lower one to get a change through.

## Coverage

`./mvnw verify` (or `./mvnw package`) runs the JaCoCo agent during tests and writes the report to `target/site/jacoco/index.html` in the `prepare-package` phase; `./mvnw test` alone does not write it. The Gradle build has no JaCoCo plugin.

On commit `2aff817` line coverage was 94.5 percent (312 of 330 lines) and branch coverage 84.4 percent (103 of 122 branches). Per package, from the JaCoCo CSV of that run:

| Package | Lines covered | Line coverage | Branches covered | Notes |
| --- | --- | --- | --- | --- |
| `org.springframework.samples.petclinic` | 1 of 12 | 8 percent | none | `PetClinicRuntimeHints` (native image hints) and `PetClinicApplication.main` do not run in tests |
| `owner` | 245 of 251 | 97.6 percent | 91 of 110 | Most missed branches are in `PetController` (10) and `Owner` (7) |
| `vet` | 33 of 33 | 100 percent | 8 of 8 | |
| `system` | 15 of 16 | 93.8 percent | none | The JCache customizer in `CacheConfiguration` never runs (F12) |
| `model` | 18 of 18 | 100 percent | 4 of 4 | |

## QA skill

The Droid QA skill is a separate layer that tests the built jar from the outside. It is not part of `./mvnw verify`.

- `.factory/skills/qa/SKILL.md` is the orchestrator. It maps the git diff to apps with the `path_patterns` in `.factory/skills/qa/config.yaml`, builds the jar once without the format and nohttp checks, starts it on H2, checks `git.commit.id` in `/actuator/info`, runs only the flows the diff can affect plus targeted extra tests, and writes `qa-results/report.md`.
- `.factory/skills/qa-web/SKILL.md` has browser flows W1 to W9: home and navigation, find owners, owner paging and page bounds, owner forms, pet forms, visits, vets list and paging, error page, language switch.
- `.factory/skills/qa-api/SKILL.md` has curl flows A1 to A3: vets as JSON and XML (and 406 for `text/csv`), health and build info, and the runtime SBOM checked against the same minimums as `PatchedDependencyVersionsTests`.
- In CI, `.github/workflows/qa.yml` runs it on pull requests and posts the report as a comment. It is informational and must not become a required check.
- The local run against commit `f9bbb32` passed 16 of 16 test cases in about 6 minutes.

To run it locally, start Droid in the repository and ask it to run the `qa` skill. Output goes to `qa-results/<run id>/`, which Git and the nohttp check ignore.

## Load test plan

`src/test/jmeter/petclinic_test_plan.jmx` is an Apache JMeter plan. Its thread group has 500 threads with 10 loops each, and it requests the home page, CSS, JS, vets, owner search, an owner, the owner edit form and post, a new pet and a new visit. Host and port come from the `PETCLINIC_HOST` and `PETCLINIC_PORT` variables (the plan's defaults point at localhost port 8080). It is not run by any build or workflow, and `docs/DEPENDENCIES.md` marks it as not run during the review.

## Add a test for a bug fix

1. Reproduce the bug in a test that fails on the current code. Pick the smallest layer that shows it:
   - a wrong status, redirect or form error in one controller: a `@WebMvcTest` next to the existing ones, such as `owner/OwnerControllerTests.java`;
   - a query or constraint: `service/ClinicServiceTests.java`;
   - behavior that needs the real filters, error handling or several requests: a `@SpringBootTest`, such as `src/test/java/org/springframework/samples/petclinic/UntrustedInputIntegrationTests.java`;
   - database-specific behavior: a container test.
2. Run it alone (`./mvnw test -Dtest=...`) and see it fail for the right reason.
3. Fix the code, run the class again, then `./mvnw verify`.
4. In the pull request, name the test and say which tests were skipped.

Commit `3a5a0bc` is an example: it added the huge-page-number cases to `OwnerControllerTests`, `VetControllerTests` and `UntrustedInputIntegrationTests` together with the fix. Commit `0e8563f` is another: its two out-of-range tests failed before the change (2 failures) and pass after it.

## Known gaps

- No automated test requests an unknown path to check the 404 page; only QA flow W8 does.
- The XML response of `/vets` and the 406 for an unsupported `Accept` type are covered only by QA flow A1. `VetControllerTests` checks JSON only.
- `PostgresOutageIntegrationTests` checks the cached `/vets` during an outage, not `/vets.html`.
- `PetClinicIntegrationTests`, `MySqlIntegrationTests` and `PostgresIntegrationTests` call the vets query twice, but no test asserts that the second call came from the cache.
- The Docker-based tests are skipped silently without Docker (F9).
- `MysqlTestApplication` replaces the MySQL connection in every test with the `mysql` profile (F10).
- No test covers concurrent duplicate pet names on MySQL, where the unique constraint has no name (F17).

[Pitfalls](../background/pitfalls.md) has the full list of known issues, and [Persistence](../systems/persistence.md) and [Caching](../systems/caching.md) explain what the database and cache tests exercise.

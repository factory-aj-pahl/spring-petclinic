# Development workflow

Every change follows the same cycle: a feature branch, a test, the code, formatting, a full build, signed-off commits, a pull request, CI and a person's review, then a merge by that person. This page lists the commands for each step and what happens after the pull request is opened and after it is merged.

## The cycle

```mermaid
graph LR
    A[Feature branch] -->|bug fix: failing test first| B[Code and tests]
    B -->|spring-javaformat:apply| C[Format]
    C -->|./mvnw verify| D[Full build]
    D -->|git commit -s| E[Signed-off commits]
    E -->|push branch| F[Pull request]
    F -->|maven, gradle, osv, qa| G[CI checks]
    G -->|person reviews| H[Merge to main]
    H -->|push to main| I[Wiki refresh pull request]
```

## Step by step

### 1. Branch

Work on a feature branch, never on `main`. This branch, for example, is `security/spring-boot-4.1.2-cve-remediation`.

```bash
git switch -c fix/owner-paging main
```

### 2. Write the test, then the code

For a bug fix, `AGENTS.md` asks for a test that fails first, then the fix. [Testing](testing.md#add-a-test-for-a-bug-fix) shows where each kind of test goes. Follow [Patterns and conventions](patterns-and-conventions.md) for the code itself.

Run one class while you work:

```bash
./mvnw test -Dtest=OwnerControllerTests
./mvnw test -Dtest='OwnerControllerTests#processFindFormByLastName'
```

The second form, with a method name, is standard Maven Surefire syntax and is not documented in the repository.

### 3. Format

```bash
./mvnw spring-javaformat:apply
```

The `validate` phase runs `spring-javaformat:validate` (`pom.xml`), so an unformatted file fails every build before a test runs.

### 4. Build and test everything

```bash
./mvnw verify
```

This runs the format check, the nohttp check, all tests, the JaCoCo report and the jar with its SBOM, in about a minute on 4 CPUs. With Docker running it runs 116 tests. Without Docker the MySQL and PostgreSQL tests do not run, and the build still passes; report them as skipped ([Testing](testing.md#running-tests)).

If you changed `build.gradle`, `pom.xml` or a dependency, also run:

```bash
./gradlew build
```

The Gradle build ran the same 116 tests on commit `2aff817`. Its plugins differ slightly from Maven's ([Tooling](tooling.md#build-plugins)).

### 5. Commit with a sign-off

```bash
git add -p
git commit -s
```

Rules from `AGENTS.md`:

- **Sign off** every commit (`-s` adds `Signed-off-by`), for the DCO.
- **One purpose per commit**, and the message explains the reason. The branch history is a model: "Upgrade Spring Boot to 4.1.2 to fix 20 known vulnerabilities", "Add dependency version guard and failure-scenario tests", "Redirect instead of failing for very large page numbers" are separate commits.
- **Maven and Gradle in step.** A version changed in `pom.xml` changes in `build.gradle` in the same commit, and the reverse.
- **Documents with the change.** Add, remove or upgrade a dependency or external service: update `docs/DEPENDENCIES.md`. Change how the application is built, run, checked or recovered: update `docs/RUNBOOK.md`.

### 6. Push and open a pull request

```bash
git push -u origin fix/owner-paging
```

Fill in `.github/PULL_REQUEST_TEMPLATE.md`; [How to contribute](index.md#pull-requests) lists its parts. Agents stop here: they never merge, approve, push to `main`, force-push or push tags, and the Droid hook blocks those commands ([Tooling](tooling.md#droid-tooling)).

## After you open the pull request

| Check | File | What it does | If it fails |
| --- | --- | --- | --- |
| Java CI with Maven | `.github/workflows/maven-build.yml` | `./mvnw -B verify` on Temurin 17 | Reproduce with `./mvnw verify`; see [Debugging](debugging.md#troubleshooting) |
| Java CI with Gradle | `.github/workflows/gradle-build.yml` | `./gradlew build` on Temurin 17 | Reproduce with `./gradlew build` |
| OSV-Scanner | `.github/workflows/osv-scanner.yml` | Scans the dependency tree of `pom.xml` and fails on newly added known vulnerabilities | Upgrade the dependency; the [runbook scan section](../../docs/RUNBOOK.md#check-dependencies-for-known-vulnerabilities) has the local commands |
| QA | `.github/workflows/qa.yml` | Droid builds the branch, starts it with H2, runs the QA flows the diff can affect, and posts or updates one "QA Report" comment | Informational only. Read the report and the `qa-results-<run id>-<attempt>` artifact ([runbook](../../docs/RUNBOOK.md#qa-check-on-pull-requests)) |
| Deploy and Test Cluster | `.github/workflows/deploy-and-test-cluster.yml` | Only for changes under `k8s/**`: creates a kind cluster, `kubectl apply -f k8s/`, waits for pods `demo-db` and `petclinic` | It deploys the Docker Hub image `dsyer/petclinic`, not your code (F4); see [Deployment](../deployment.md) |

Notes:

- The QA job runs only for branches in the same repository, because forks get no secrets. Without `FACTORY_API_KEY` the comment says QA did not run. A pull request that changes only docs, CI or tests gets an INCONCLUSIVE QA result.
- The Maven and Gradle builds run on GitHub-hosted Ubuntu runners, which have Docker, so CI is expected to run all 116 tests. Check the test count in the log when it matters (follow-up F9).

Push fixes as new commits to the same branch. Every new commit also needs a sign-off.

## Review and merge

A person reviews, asks for changes and merges. Nobody is assigned automatically because there is no `CODEOWNERS` file, and the required checks on `main` are not confirmed (F13). The merge method is not prescribed anywhere in the repository.

## After the merge

On every push to `main`:

- The Maven and Gradle builds and a full OSV-Scanner scan run again (`scan-full` job, which reports every known vulnerability, including new advisories on old dependencies).
- `.github/workflows/droid-wiki-refresh.yml` runs Droid's `/wiki` on the new `main`, restores the previous pages from the `factory/droid-wiki` branch, rewrites the pages whose code changed, and opens or updates one rolling pull request titled "docs: refresh wiki" (label `droid-wiki`). A person reviews and merges it like any other pull request. The QA check skips it, but the Maven and Gradle builds run on it when `FACTORY_WIKI_PR_TOKEN` is set, and their nohttp check fails on `http://` links in the pages. See the [runbook wiki section](../../docs/RUNBOOK.md#wiki-refresh).

Do not edit `droid-wiki/` by hand; the next refresh overwrites it.

## Dependency upgrades

`.github/dependabot.yml` opens weekly pull requests for three ecosystems:

| Ecosystem | Limit | Notes |
| --- | --- | --- |
| Maven (`pom.xml`) | 5 open pull requests | Spring Boot manages most library versions, so a Spring Boot update usually arrives as one pull request per build tool |
| Gradle (`build.gradle`) | 5 open pull requests | The Maven and Gradle pull requests for the same update are separate; make sure both versions end up the same |
| GitHub Actions | One grouped pull request | All action updates in one group |

Dependabot pull requests read Dependabot secrets, so QA runs on them only if `FACTORY_API_KEY` is also stored there. Read F21 in `docs/RUNBOOK.md` before you store it there: the build and the application of a dependency update then run with the key in their environment.

To upgrade Spring Boot yourself, for example to fix an advisory, follow the [runbook procedure](../../docs/RUNBOOK.md#upgrade-spring-boot-to-fix-an-advisory). In short:

1. Find the first Spring Boot release whose BOM manages fixed versions.
2. Change the parent version in `pom.xml` and the `org.springframework.boot` plugin version in `build.gradle`.
3. With Docker running, run `./mvnw verify` and `./gradlew build`; both must run the full test count.
4. Run the two OSV-Scanner scans from the runbook.
5. If the upgrade fixes new advisories, raise the minimums in `src/test/java/org/springframework/samples/petclinic/PatchedDependencyVersionsTests.java` and update the advisory table in `docs/DEPENDENCIES.md`.
6. Commit with `git commit -s` and open a pull request.

Prefer upgrading Spring Boot to overriding one library. If an override cannot wait, set the same BOM property in `pom.xml` and `build.gradle` and remove it at the next Spring Boot upgrade. Never lower a minimum in `PatchedDependencyVersionsTests` to get another change through; a rollback that does so needs a recorded risk acceptance ([runbook](../../docs/RUNBOOK.md#roll-back)). [Dependencies](../reference/dependencies.md) summarizes the current versions.

# Tooling

PetClinic builds with Maven (the main build) or Gradle, both through wrappers checked into the repository, and CI runs on GitHub Actions. This page lists the build plugins and the checks they add, every workflow, the dependency tooling, the development environments, and the Droid configuration in `.factory/`.

## Wrappers

| Tool | Version | Defined in | Command |
| --- | --- | --- | --- |
| Maven | 3.9.16, Maven Wrapper 3.3.4 (`distributionType=only-script`) | `.mvn/wrapper/maven-wrapper.properties` | `./mvnw` (`mvnw.cmd` on Windows) |
| Gradle | 9.5.1 | `gradle/wrapper/gradle-wrapper.properties`, `gradle/wrapper/gradle-wrapper.jar` | `./gradlew` (`gradlew.bat` on Windows) |
| JDK | 17 (`java.version` in `pom.xml`, toolchain in `build.gradle`) | Not provided; install a JDK 17 or newer | CI uses Temurin 17 |

`AGENTS.md` makes Maven the reference build and requires `build.gradle` to follow every version change in `pom.xml`. [Getting started](../overview/getting-started.md) covers installation and first run.

## Build plugins

### Maven (`pom.xml`)

The parent is `spring-boot-starter-parent` 4.1.2, which manages the versions of plugins without an explicit version.

| Plugin | Version | Phase or use | What it does |
| --- | --- | --- | --- |
| `maven-enforcer-plugin` | Boot managed | `validate` | Fails the build on a JDK older than 17 |
| `spring-javaformat-maven-plugin` | 0.0.47 | `validate` (`validate` goal) | Fails on code not in Spring's format; `./mvnw spring-javaformat:apply` fixes it |
| `maven-checkstyle-plugin` | 3.6.0, Checkstyle 12.3.1, `nohttp-checkstyle` 0.0.11 | `validate` (execution `nohttp-checkstyle-validation`) | Runs only the nohttp rule from `src/checkstyle/nohttp-checkstyle.xml` over every file under the project root, excluding `.git`, `.idea`, `target`, `.flattened-pom.xml`, class files and `qa-results/`. `src/checkstyle/nohttp-checkstyle-suppressions.xml` also skips `build/`, `node_modules/` and binary files. A comment in `pom.xml` keeps Checkstyle on 12 because 13 needs JDK 21. |
| `jacoco-maven-plugin` | 0.8.15 | `prepare-agent`, `report` in `prepare-package` | Coverage report in `target/site/jacoco/`; see [Testing](testing.md#coverage) |
| `spring-boot-maven-plugin` | Boot managed | `build-info` goal; `spring-boot:run`, `spring-boot:build-image` | Writes `META-INF/build-info.properties` for `/actuator/info`, repackages the executable jar, builds a container image with Cloud Native Buildpacks |
| `git-commit-id-maven-plugin` | Boot managed | Boot parent default | Writes `git.properties` for `/actuator/info`; does not fail without a `.git` directory |
| `cyclonedx-maven-plugin` | Boot managed | Boot parent default | CycloneDX SBOM at `META-INF/sbom/application.cdx.json`, served at `/actuator/sbom/application` |
| `native-maven-plugin` (GraalVM) | Boot managed | Only with the Boot parent's `native` profile | Native image build; not exercised in this repository's CI or review |

Profiles:

- **`css`**: `maven-dependency-plugin` unpacks the Bootstrap 5.3.8 webjar into `target/webjars`, and `libsass-maven-plugin` 0.3.4 compiles `src/main/scss/` into `src/main/resources/static/resources/css/`. Run `./mvnw package -P css` after changing SCSS or upgrading Bootstrap. LibSass is deprecated upstream (F14). Gradle has no equivalent.
- **`m2e`**: active only inside Eclipse; tells m2e to ignore the Checkstyle, build-info and format goals.

`project.build.outputTimestamp` is fixed for reproducible builds, which is why `build.time` in `/actuator/info` looks old.

### Gradle (`build.gradle`)

| Plugin | Version | What it does |
| --- | --- | --- |
| `org.springframework.boot` | 4.1.2 | `bootRun`, `bootJar`, `bootBuildImage` |
| `io.spring.dependency-management` | 1.1.7 | Applies the Spring Boot BOM |
| `io.spring.javaformat` | 0.0.47 | `format` and `checkFormat` tasks; the AOT variants are disabled |
| `checkstyle` | Checkstyle 12.3.1 with `spring-javaformat-checkstyle` 0.0.47 on its classpath | `checkstyleMain` and `checkstyleTest` use `src/checkstyle/nohttp-checkstyle.xml` |
| `io.spring.nohttp` | 0.0.11 | `checkstyleNohttp` scans the repository; `qa-results/**` is excluded |
| `org.cyclonedx.bom` | 3.2.4 | SBOM; test configurations skipped |
| `org.graalvm.buildtools.native` | 1.1.2 | Native image tasks; not exercised |

`build.gradle` has no JaCoCo, git-commit-id or `buildInfo` configuration, so the Gradle build writes no coverage report and, as far as the file shows, its jar has no git or build information for `/actuator/info`. Its dependency scopes also differ from Maven's: Actuator is `runtimeOnly` and some test starters are missing (F11).

## CI workflows

All workflows are in `.github/workflows/`.

| File | Trigger | Purpose |
| --- | --- | --- |
| `.github/workflows/maven-build.yml` | Push and pull request to `main` | `./mvnw -B verify` on Temurin 17 with the Maven cache. No `permissions:` block (F22). |
| `.github/workflows/gradle-build.yml` | Push and pull request to `main` | `./gradlew build` on Temurin 17 with `gradle/actions/setup-gradle@v4`. No `permissions:` block (F22). |
| `.github/workflows/osv-scanner.yml` | Pull request and merge group to `main` (`scan-pr`); push to `main` and Mondays 06:30 UTC (`scan-full`) | Google's OSV-Scanner reusable workflows v2.7.1 with `--lockfile=pom.xml`. `scan-pr` fails when a pull request adds a known vulnerability; `scan-full` reports all. SARIF upload is off. |
| `.github/workflows/qa.yml` | Pull request to `main` unless only `droid-wiki/**` changed; manual `workflow_dispatch` | Installs agent-browser 0.43.0 and the latest Droid CLI (not pinned, F21), runs the `qa` skill with `droid exec --auto high`, uploads `qa-results/` for 14 days, and keeps one comment starting with `<!-- qa-report -->` up to date. Same-repository pull requests only. Needs `FACTORY_API_KEY`. Informational. |
| `.github/workflows/deploy-and-test-cluster.yml` | Push and pull request to `main` touching `k8s/**` | Creates a kind cluster with `helm/kind-action@v1`, `kubectl apply -f k8s/`, waits up to 180 seconds each for the `demo-db` and `petclinic` pods. Deploys the prebuilt image, not the pull request (F4). No `permissions:` block (F22). |
| `.github/workflows/droid-wiki-refresh.yml` | Push to `main` | Job `wiki-refresh` (read-only token) installs the latest Droid CLI (not pinned, F21), restores `droid-wiki/` from `factory/droid-wiki` and runs `/wiki` without upload; job `wiki-publish` opens or updates the rolling "docs: refresh wiki" pull request with `peter-evans/create-pull-request` (pinned to the v8.1.1 commit), signed off, excluding `droid-wiki/video/` and `droid-wiki/images/`. One run at a time. Needs `FACTORY_API_KEY` and `FACTORY_WIKI_PR_TOKEN`. |

[Development workflow](development-workflow.md#after-you-open-the-pull-request) explains how these fit into a change, and [Deployment](../deployment.md) covers the cluster workflow.

## Dependency tooling

- **Dependabot** (`.github/dependabot.yml`): weekly updates for Maven and Gradle (up to 5 open pull requests each) and GitHub Actions (one grouped pull request).
- **OSV-Scanner**: in CI as above; locally with the commands in the [runbook](../../docs/RUNBOOK.md#check-dependencies-for-known-vulnerabilities), which scan `pom.xml` and the jar's SBOM. Only the Maven dependency tree is scanned; `build.gradle` is not.
- **Version guard**: `src/test/java/org/springframework/samples/petclinic/PatchedDependencyVersionsTests.java` fails the build when a library resolves below its first patched version ([Testing](testing.md#failure-scenario-tests-and-the-version-guard)).
- **Inventory**: `docs/DEPENDENCIES.md`, summarized in [Dependencies](../reference/dependencies.md).

## Development environments

| File | What it sets up |
| --- | --- |
| `.devcontainer/devcontainer.json` | Dev container on `mcr.microsoft.com/devcontainers/base:ubuntu` with the Java feature (21, Oracle), Azure CLI, Docker-in-Docker and GitHub CLI, plus the VS Code Java and XML extensions. Java 21 differs from CI's 17. |
| `.devcontainer/Dockerfile` | Image for Gitpod (its own comment says the dev container does not use it): `mcr.microsoft.com/vscode/devcontainers/java:0-17-bullseye` with Java 17.0.7 from SDKMAN and volumes for `~/.m2` and `~/.gradle` |
| `.gitpod.yml` | Gitpod workspace from that Dockerfile; runs `./mvnw install` on init |
| `.editorconfig` | UTF-8, LF, final newline; tabs for Java and XML, two spaces for `pom.xml`, HTML, SQL and Gradle files |
| `docker-compose.yml` | Local MySQL 9.7 and PostgreSQL 18.4 services ([Getting started](../overview/getting-started.md#use-mysql-or-postgresql)) |

None of the development environments was exercised during the review.

## Droid tooling

Factory Droid configuration lives in `.factory/` and two workflows.

| File | What it does |
| --- | --- |
| `.factory/hooks.json` | Registers a `PreToolUse` hook for the `Execute` tool that runs `python3 "$FACTORY_PROJECT_DIR"/.factory/hooks/guard_release_actions.py` with a 15-second timeout |
| `.factory/hooks/guard_release_actions.py` | Reads the pending call as JSON and exits 2 (blocked) for: `gh pr merge`, `gh pr review --approve`, merges and branch-protection changes through `gh api`, `gh release create/delete/edit/upload`, changing `kubectl` and `helm` subcommands, `docker push` and `docker buildx build --push`, `mvn deploy`, `spring-boot.build-image.publish=true`, `gradle publish*` (not `publishToMavenLocal`), and `git push` with force, `--tags`, `--mirror`, `--all`, tag refspecs or a destination of `main` or `master` (including a plain push from those branches). Everything else, and unreadable input, exits 0. It matches command text, so it is a guardrail, not a security boundary. |
| `.factory/hooks/test_guard_release_actions.py` | 6 `unittest` tests with temporary repositories on `security/fix` and `main`; run with `python3 -B -m unittest discover -s .factory/hooks` |
| `.factory/settings.json` | Adds the `Factory-AI/factory-plugins` marketplace from GitHub and enables the `droid-control` plugin, which drives the browser for QA. Not pinned to a version. |
| `.factory/skills/qa/` | QA orchestrator: `.factory/skills/qa/SKILL.md` (steps from loading config to the report), `.factory/skills/qa/config.yaml` (local H2 target, `visitor` persona, `web` and `api` apps with path patterns and build command, evidence settings), `.factory/skills/qa/REPORT-TEMPLATE.md`, and `.factory/skills/qa/.install-progress.yaml` (state of the skill installer) |
| `.factory/skills/qa-web/SKILL.md` | Browser flows W1 to W9 and known failure modes |
| `.factory/skills/qa-api/SKILL.md` | curl flows A1 to A3 and known failure modes |
| `.github/workflows/qa.yml`, `.github/workflows/droid-wiki-refresh.yml` | Run Droid in CI, as described above |

`AGENTS.md` is the instruction file Droid and other agents read. [Testing](testing.md#qa-skill) describes the QA flows, and [Security](../security.md) discusses what the hook does and does not protect.

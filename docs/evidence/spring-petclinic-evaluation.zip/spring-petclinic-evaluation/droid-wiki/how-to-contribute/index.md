# How to contribute

Contributions to PetClinic go through a pull request against `main` that a person reviews and merges. This page covers where work comes from, what a pull request must contain, which checks run on it, and when a change is done. The four pages below go into detail.

| Page | What it covers |
| --- | --- |
| [Development workflow](development-workflow.md) | Branch, code, format, test, sign off, pull request, review and merge, with exact commands |
| [Testing](testing.md) | Test layers, every test class, Docker-based tests, coverage, QA skill, how to add a test |
| [Debugging](debugging.md) | Logs, Actuator endpoints, and a troubleshooting table for common build and runtime problems |
| [Tooling](tooling.md) | Maven and Gradle wrappers, build plugins, CI workflows, Dependabot, dev containers, Droid configuration |
| [Patterns and conventions](patterns-and-conventions.md) | How the code is organized and written |

New to the project? Start with [Getting started](../overview/getting-started.md) to build and run it.

## Picking up work

- **Issues.** `README.md` points to the upstream issue tracker on GitHub for bugs, feature requests and pull requests. There is no other backlog in the repository.
- **Issue forms.** `.github/ISSUE_TEMPLATE/bug_report.yml` asks for what happened, steps to reproduce, expected behavior, the commit (`git rev-parse --short HEAD`) and the database (H2, MySQL or PostgreSQL). `.github/ISSUE_TEMPLATE/dependency_vulnerability.yml` asks for the advisory ID, the affected package and version, the first fixed version, how it was found and whether the vulnerable code is reachable. That form is for published advisories in dependencies only, not for undisclosed vulnerabilities in PetClinic itself. `.github/ISSUE_TEMPLATE/config.yml` allows blank issues.
- **Known open items.** The follow-ups table in `docs/RUNBOOK.md` (F1 and later) lists issues found during the 2026 review that were left open on purpose. [Pitfalls](../background/pitfalls.md) explains each one. Pick one only after the owner decision it needs has been made.
- **Dependency updates.** Dependabot opens them weekly; see [Development workflow](development-workflow.md#dependency-upgrades).

## Pull requests

`.github/PULL_REQUEST_TEMPLATE.md` has four parts:

1. **What and why**, with a link to the issue or advisory.
2. **How it was tested**: the commands you ran and their results, including which tests were skipped (for example the Docker-based tests). Check boxes for `./mvnw verify` and, when build files or dependencies changed, `./gradlew build`.
3. **Dependencies and operations**: either no dependency or runtime change, or `docs/DEPENDENCIES.md` and `docs/RUNBOOK.md` are updated; and `pom.xml` and `build.gradle` use the same versions.
4. **Review**: every commit is signed off, and a person reviews and merges. Agents do not merge, release or deploy.

## Checks on a pull request

| Workflow | File | Runs when | Blocks merging? |
| --- | --- | --- | --- |
| Java CI with Maven | `.github/workflows/maven-build.yml` | Every pull request to `main` | Depends on branch protection (see below) |
| Java CI with Gradle | `.github/workflows/gradle-build.yml` | Every pull request to `main` | Depends on branch protection |
| OSV-Scanner | `.github/workflows/osv-scanner.yml` | Every pull request to `main`; fails when the change adds a known vulnerability | Depends on branch protection |
| QA | `.github/workflows/qa.yml` | Pull requests to `main` from the same repository, unless only `droid-wiki/**` changed | No, informational by design |
| Deploy and Test Cluster | `.github/workflows/deploy-and-test-cluster.yml` | Only when `k8s/**` changes | Depends on branch protection |
| DCO | `.github/dco.yml` (configuration for the DCO check) | Every pull request | Depends on branch protection |

[Tooling](tooling.md#ci-workflows) describes each workflow, and [Development workflow](development-workflow.md#after-you-open-the-pull-request) explains what to do with the results.

## Sign-off (DCO)

`AGENTS.md`, `README.md` and the pull request template require a `Signed-off-by` trailer on every commit, which `git commit -s` adds. It states that you agree to the Developer Certificate of Origin. `.github/dco.yml` contains `require: members: false`; going by the DCO app's documented settings, that exempts members of the GitHub organization from the check, so a missing sign-off from a member may not be caught automatically. Sign off anyway.

## Review

- A person reviews every pull request. There is no `CODEOWNERS` file, so nobody is requested automatically, and branch protection on `main` could not be checked during the 2026 review (follow-up F13 in `docs/RUNBOOK.md`). Which checks are required before merging is therefore not confirmed.
- The QA report comment from `.github/workflows/qa.yml` helps the reviewer, but it never blocks a merge.
- Reviewers look for the items in the definition of done below. The pull request description should state skipped tests as skipped, not as passed.

## Definition of done

A change is done when:

- [ ] A bug fix comes with a test that failed before the fix ([Testing](testing.md#add-a-test-for-a-bug-fix)); new behavior has tests.
- [ ] `./mvnw verify` passes. Say whether Docker was running, because without it the Docker-based tests do not run.
- [ ] `./gradlew build` passes when build files or dependencies changed.
- [ ] Java code is formatted (`./mvnw spring-javaformat:apply`); `spring-javaformat:validate` fails the build otherwise.
- [ ] No `http://` links other than localhost in any file, Markdown included (nohttp Checkstyle rule).
- [ ] Visible text in templates comes from message keys present in every `src/main/resources/messages/messages*.properties` file (`I18nPropertiesSyncTest`).
- [ ] A dependency or external service change updates `docs/DEPENDENCIES.md`; an operational change updates `docs/RUNBOOK.md`.
- [ ] `pom.xml` and `build.gradle` use the same versions.
- [ ] `PatchedDependencyVersionsTests` passes without lowering its minimums.
- [ ] Every commit has one purpose, explains why, and is signed off.

## Rules for agents

`AGENTS.md` sets the rules for coding agents such as Droid. Agents push a feature branch and open a pull request. People merge, release and deploy. Agents must not merge or approve pull requests, push to `main`, force-push, push tags, publish releases, container images or Maven artifacts, or change a Kubernetes cluster or Helm release. Nobody edits `droid-wiki/` by hand; `.github/workflows/droid-wiki-refresh.yml` regenerates it after pushes to `main`.

For Droid, `.factory/hooks.json` runs `.factory/hooks/guard_release_actions.py` before every shell command and blocks those actions ([Tooling](tooling.md#droid-tooling)). The hook matches command text, so it is a guardrail and not a security boundary. Branch protection on `main` is still needed (F13). [Security](../security.md) covers the agent guardrails as part of the trust model.

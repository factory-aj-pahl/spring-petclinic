# Debugging

PetClinic logs to standard output, hides error details from users, and exposes every Actuator endpoint, so most problems can be traced from the console log plus a few Actuator calls. This page shows where to look and lists common build and runtime problems with their fixes.

## Logs

- **Where they go.** Spring Boot's default console logging; no `logging.file.*` property is set in `src/main/resources/application.properties`. Under `./mvnw spring-boot:run` the log is in your terminal, under `java -jar` in the process's standard output, and in a container in `docker logs` or `kubectl logs`.
- **Levels.** `src/main/resources/application.properties` sets `logging.level.org.springframework=INFO` and has two commented-out lines you can enable: `logging.level.org.springframework.web=DEBUG` (request mapping and handler details) and `logging.level.org.springframework.context.annotation=TRACE` (configuration class processing).
- **Without editing files**, pass a level on the command line, for example `./mvnw spring-boot:run -Dspring-boot.run.arguments=--logging.level.org.hibernate.SQL=DEBUG` or `java -jar target/spring-petclinic-4.0.0-SNAPSHOT.jar --logging.level.org.springframework.web=DEBUG`. `--debug` prints Spring Boot's auto-configuration report.
- **At runtime**, change a level through the `loggers` Actuator endpoint, which is exposed with the rest (see below). This is standard Spring Boot behavior and was not exercised during the review:

  ```bash
  curl -X POST -H 'Content-Type: application/json' \
    -d '{"configuredLevel":"DEBUG"}' http://localhost:8080/actuator/loggers/org.springframework.web
  ```
- **SQL.** `PetClinicIntegrationTests` sets `logging.level.sql=DEBUG`, so its test output shows every statement; use the same property when you run the application.
- The application code has no loggers of its own (no logger in `src/main/java`), so everything in the log comes from Spring, Hibernate, HikariCP or Tomcat.

## How errors show up

A failing request gives the user `src/main/resources/templates/error.html` (or a JSON body for non-browser clients) without exception details. The details are in the log: an unhandled exception is an `ERROR` entry from Tomcat's `dispatcherServlet` logger with the full stack trace; a 400 or 406 that Spring MVC resolves itself is a single `WARN` line from `DefaultHandlerExceptionResolver`. [Error handling](../features/error-handling.md) has the status-code table and the log formats. An unknown owner or pet id giving 500 is the known issue F3, not a new bug.

## Actuator endpoints for debugging

`management.endpoints.web.exposure.include=*` in `src/main/resources/application.properties` exposes every endpoint over HTTP without authentication (follow-up F1). That is convenient locally and must not reach production. Useful ones:

| Endpoint | What it tells you |
| --- | --- |
| `/actuator/health` | `UP`, or `DOWN` with 503 when the database is unreachable. Groups `liveness` and `readiness`; readiness ignores the database (F2). |
| `/actuator/info` | Git commit and build info of the running jar; confirms which code is running |
| `/actuator/env` | Every property and where it came from: active profiles, `database`, data source URL |
| `/actuator/configprops` | Bound configuration properties, such as the data source and JPA settings |
| `/actuator/beans` | Every bean in the context, to check that a component was picked up |
| `/actuator/mappings` | Every request mapping and its handler method |
| `/actuator/caches` | Cache managers and caches (`vets`); see [Caching](../systems/caching.md) |
| `/actuator/loggers` | Current log levels; POST to change one |
| `/actuator/threaddump` | Thread stacks, for hangs such as a pool waiting for a connection |
| `/actuator/metrics` | Metric names, for example `hikaricp.connections.active` or `http.server.requests` |
| `/actuator/sbom/application` | Library versions in the running jar |

`/actuator/shutdown` is not enabled (QA flow A2 checks that a POST returns 404). [How to monitor](../how-to-monitor.md) covers health, metrics and logs for operators, and [HTTP API](../api.md) lists the endpoints.

## Inspect the database

The H2 console is not included: `README.md` explains that since Spring Boot 4 it is a separate module, `org.springframework.boot:spring-boot-h2console`, which is not in `pom.xml`. To use it locally, add that dependency; Spring Boot Devtools then enables the console under `./mvnw spring-boot:run` (with `java -jar`, also set `spring.h2.console.enabled=true`). It is then at `http://localhost:8080/h2-console`, with the `jdbc:h2:mem:<uuid>` URL printed at startup. Do not commit the dependency without a reason, and update `docs/DEPENDENCIES.md` if you do. For MySQL or PostgreSQL, connect to the Compose service with any client; [Persistence](../systems/persistence.md) has the settings.

## Debug in an IDE

Run the `main` method of `src/test/java/org/springframework/samples/petclinic/PetClinicIntegrationTests.java` (H2), `src/test/java/org/springframework/samples/petclinic/MysqlTestApplication.java` (Testcontainers MySQL) or `src/test/java/org/springframework/samples/petclinic/PostgresIntegrationTests.java` (Compose PostgreSQL) in debug mode. `README.md` recommends these for development. To debug a single test, run it from the IDE, or attach to Surefire with `./mvnw test -Dtest=OwnerControllerTests -Dmaven.surefire.debug` (standard Surefire option, waits for a debugger on port 5005).

## Troubleshooting

| Symptom | Cause | Fix |
| --- | --- | --- |
| Startup fails with "Port 8080 was already in use" | Another process, often an earlier PetClinic, listens on 8080 | Stop it, or start on another port: `./mvnw spring-boot:run -Dspring-boot.run.arguments=--server.port=18080` or `java -jar ... --server.port=18080` |
| With `mysql` or `postgres` profile, the process exits within seconds; the root cause is `ConnectException` / "Connection refused" | The database is not running or `MYSQL_URL` / `POSTGRES_URL` points elsewhere. This fail-fast behavior is intended and tested by `DatabaseUnavailableAtStartupTests` | Start it with `docker compose up mysql` or `docker compose up postgres`, or fix the environment variables. See the [runbook failure table](../../docs/RUNBOOK.md#failure-behavior) |
| Pages give 500 while `/vets` still works and `/actuator/health` is 503 | The database went away while the application runs; `/vets` is served from the cache | Restore the database; the application recovers without a restart (`PostgresOutageIntegrationTests`) |
| Build fails in `validate` at `spring-javaformat-maven-plugin` (`validate` goal), naming the unformatted files | A Java file is not in Spring's format | `./mvnw spring-javaformat:apply` (Gradle: `./gradlew format`), then rebuild |
| Build fails in `validate` from `maven-checkstyle-plugin` with a NoHttp violation naming a file and line | An `http://` URL other than localhost, in any scanned file, Markdown and untracked files included (`src/checkstyle/nohttp-checkstyle.xml`) | Change it to `https://`. Build output (`target/`, `build/`), `.git/` and `qa-results/` are excluded; images and jars are suppressed in `src/checkstyle/nohttp-checkstyle-suppressions.xml` |
| `I18nPropertiesSyncTest.checkNonInternationalizedStrings` fails with "Hardcoded (non-internationalized) strings found" | Literal text between HTML tags in a template under `src/main` | Use `th:text="#{key}"` and add the key ([Internationalization](../features/internationalization.md)) |
| `I18nPropertiesSyncTest.checkI18nPropertyFilesAreInSync` fails | A key in `src/main/resources/messages/messages.properties` is missing from another bundle (`src/main/resources/messages/messages_en.properties` is skipped on purpose) | Add the key to every `src/main/resources/messages/messages_*.properties` file |
| `PatchedDependencyVersionsTests` fails with `<artifact> resolved to <version>; <minimum> is the first version without the known advisories` | A dependency change, an override or a downgrade brought back a vulnerable version | Upgrade, usually Spring Boot. Do not lower the minimum ([Development workflow](development-workflow.md#dependency-upgrades)) |
| Test count is lower than 116, or MySQL tests show as skipped | Docker is not running or not reachable by Testcontainers | Start Docker and rerun, or report the tests as skipped (F9) |
| A test with the `mysql` profile connects to a container instead of the configured URL | `MysqlTestApplication` declares a `@Profile("mysql")` Testcontainers bean that every such test picks up (F10) | Exclude it, as `DatabaseUnavailableAtStartupTests` does with a `TypeExcludeFilter` |
| An empty, root-owned `conf.d/` directory appears in the repository root after `docker compose up mysql` | `docker-compose.yml` mounts `./conf.d` into the MySQL container, but the directory is not in the repository (F7) | Harmless for running; remove it with `sudo` if you need to. Do not commit it |
| A Droid command fails with "Blocked by .factory/hooks/guard_release_actions.py: ..." | The hook matched a merge, approval, push to `main`, force-push, tag push, release, deploy or publish command. It matches text, so a command that only mentions one (an `echo`) is blocked too | Push a feature branch and open a pull request; a person does the blocked action. Rephrase harmless commands that only mention one |
| QA comment says QA did not run | No `FACTORY_API_KEY` secret for this run. Dependabot pull requests read Dependabot secrets, so they get no key unless it is stored there too (read F21 in `docs/RUNBOOK.md` first) | See the [runbook QA section](../../docs/RUNBOOK.md#qa-check-on-pull-requests) |
| Owner list page 2 of a search shows all owners | Known defect F16: the paging links drop `lastName` | Not a local problem; see [Pitfalls](../background/pitfalls.md) |

[Configuration](../reference/configuration.md) lists every property that can change these behaviors.

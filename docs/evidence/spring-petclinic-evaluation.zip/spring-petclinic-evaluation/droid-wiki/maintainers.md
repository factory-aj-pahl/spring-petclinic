# Maintainers

This page lists, for each area of the repository, the people who changed it most recently on `origin/main`, when it last changed, and how many commits and distinct authors it has in total. It helps you find who to ask or who to add as a reviewer.

## How to read this page

- Data comes from `git log origin/main` for the paths of each area, with bot accounts excluded. The current branch is not counted.
- "Recent contributors" are the most recent distinct human authors of the area, newest first. They are not owners or approvers.
- "Commits" and "Distinct authors" are totals for the whole area over its history. They are not per-person figures, and a commit that touches several areas counts in each.
- There is no CODEOWNERS file in the repository (follow-up F13 in `docs/RUNBOOK.md`), so no area has a formal owner and this page has no CODEOWNERS column. Reviews are requested by hand; see [How to contribute](how-to-contribute/index.md).

## Areas

| Area | Paths | Recent contributors | Last activity | Commits | Distinct authors |
| --- | --- | --- | --- | --- | --- |
| Owners, pets and visits | `src/main/java/org/springframework/samples/petclinic/owner/` | Pedro Arthur Hartmann, Ayush Keshri, Rennan Ballaro Gomes de Sousa | 2026-09-29 | 78 | 34 |
| Vets | `src/main/java/org/springframework/samples/petclinic/vet/` | Pedro Arthur Hartmann, king-407, Dave Syer | 2026-09-29 | 28 | 14 |
| System | `src/main/java/org/springframework/samples/petclinic/system/` | Dave Syer, Moritz Halbritter, Patrick Baumgartner | 2025-11-26 | 22 | 11 |
| Model | `src/main/java/org/springframework/samples/petclinic/model/` | Thomas Schmidt, Patrick Baumgartner, Philippe Marschall | 2026-04-13 | 35 | 17 |
| Templates | `src/main/resources/templates/` | shivam tiwari, jang8584, Denis Fuenzalida | 2026-06-01 | 40 | 21 |
| Messages (i18n) | `src/main/resources/messages/` | Robinson J, Jaguar-H, shivam tiwari | 2026-07-18 | 15 | 12 |
| Database scripts | `src/main/resources/db/` | Michael Popov, Shivram, Stéphane Nicoll | 2026-07-22 | 40 | 21 |
| Application properties | `src/main/resources/application*.properties` | Dave Syer, Philippe Marschall, Patrick Baumgartner | 2026-04-20 | 33 | 12 |
| Styles | `src/main/scss/`, `src/main/resources/static/resources/css/` | Patrick Baumgartner, Dave Syer | 2025-10-04 | 11 | 2 |
| Tests | `src/test/` | Pedro Arthur Hartmann, Ayush Keshri, Rennan Ballaro Gomes de Sousa | 2026-09-29 | 199 | 49 |
| Maven build | `pom.xml`, Maven wrapper | Patrick Baumgartner, Stéphane Nicoll, Dave Syer | 2026-06-11 | 336 | 38 |
| Gradle build | `build.gradle`, Gradle wrapper | Patrick Baumgartner, Stéphane Nicoll, Dave Syer | 2026-06-11 | 55 | 11 |
| CI workflows | `.github/workflows/` | Dave Syer, Stéphane Nicoll, Moritz Halbritter | 2025-11-26 | 13 | 7 |
| Kubernetes | `k8s/` | Patrick Baumgartner, Andrey Litvitski | 2026-06-11 | 6 | 2 |
| Docker Compose | `docker-compose.yml` | Patrick Baumgartner, Dave Syer, portfoliodeekshith | 2026-06-11 | 22 | 6 |
| Dev containers | `.devcontainer/`, `.gitpod.yml` | Dave Syer, Julien Dubois, Yan Zhang | 2024-11-28 | 14 | 4 |
| Droid configuration, docs and agent guidance | `.factory/`, `docs/`, `AGENTS.md` | none on `origin/main` | none on `origin/main` | none | none |

The last row has no history on `origin/main`: `.factory/`, `docs/DEPENDENCIES.md`, `docs/RUNBOOK.md` and `AGENTS.md` exist only on the current branch `security/spring-boot-4.1.2-cve-remediation`. The same is true of `.github/workflows/osv-scanner.yml`, `.github/workflows/qa.yml`, `.github/workflows/droid-wiki-refresh.yml`, `.github/dependabot.yml`, `.github/PULL_REQUEST_TEMPLATE.md` and `.github/ISSUE_TEMPLATE/`. They get maintainers once the branch is merged. Agents may push feature branches and open pull requests, but people merge, release and deploy (`AGENTS.md`).

## Observations

- Activity is spread across many people. On `origin/main` the repository has 156 distinct human authors, and most areas have more than ten. [By the numbers](by-the-numbers.md) has the activity figures and [Lore](lore.md) the history.
- The most recent work on `origin/main` (September 2026) is in owners, vets and tests: field-length validation and the page-number overflow handling.
- Styles and Kubernetes have only two distinct authors each, and the dev container files have not changed since 2024-11-28.
- Build files change most often, because dependency and Spring Boot upgrades touch `pom.xml` and `build.gradle` together.

## Related pages

- [How to contribute](how-to-contribute/index.md): how to open a pull request and get it reviewed.
- [Dependencies](reference/dependencies.md): the libraries the build files manage.
- [Architecture](overview/architecture.md): what each package does.

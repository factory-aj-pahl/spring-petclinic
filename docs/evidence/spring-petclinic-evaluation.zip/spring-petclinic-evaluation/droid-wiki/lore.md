# Lore

PetClinic started in 2009 as a sample for Spring Framework 3 and has been rebuilt several times since: from a WAR with JSP pages and three persistence implementations to a Spring Boot jar with Thymeleaf and Spring Data JPA. This page tells that story era by era, with dates from `git log origin/main`. [By the numbers](by-the-numbers.md) has the counts and [Design decisions](background/design-decisions.md) explains why the code looks the way it does today.

## Where the history starts

The Git history begins with `349fdef Initial commit` on 2013-01-09, which adds only a 4-line `README.md`. The older work was imported on the same day: every commit before it has a commit date of 2013-01-09 but keeps its original author date, the earliest being 2009-05-05 (`f09d67c petclinic 3 initial commit - wip`). That is why 66 commits are dated 2009 to 2012 even though the repository did not exist in Git then. The import likely came from the Spring Framework's older version control, since the 2009 messages refer to Spring JIRA tickets (`SPR-6447`).

## Eras

### 2009: a sample for Spring 3

The first commits build a "petclinic 3" project in an Eclipse layout under `org.springframework.samples.petclinic/`, with JSP views and Tiles. By November it had moved to a standard Maven layout.

- 2009-05-05: `f09d67c` "petclinic 3 initial commit - wip", with Eclipse settings and a `HomeController`.
- 2009-05-06: `098cfb6` upgrade to Spring 3.0.0.M3; `2742ccb` moves pets under owners, the URL shape that `/owners/{ownerId}/pets/...` still uses.
- 2009-11-25: `521d01d` "commit the gross of the files + added maven pom" (117 files). The project was then called `petclinic-classic`, built for Java 1.5, with a TopLink Essentials dependency.
- 2009-11-26: the MySQL scripts and the six seed vets (James Carter to Sharon Jenkins) arrive. They are still there.

### 2013: on GitHub, rebuilt around repositories

After the import the code was reworked quickly. 224 commits are dated 2013, more than in any other year.

- 2013-01-09: `87ccf9f` "first step of migration to Spring 3.2", Java 1.6.
- 2013-01-14: `9f8acc0` migration to JPA annotations; the Hibernate mapping file `petclinic.hbm.xml` and the TopLink code are removed around this time.
- 2013-01-17 and 2013-01-18: `c9c8c4e` splits the `ClinicRepository` into separate repositories, with three implementations side by side: `repository/jdbc`, `repository/jpa` and, from `97aba3f`, `repository/springdatajpa`.
- 2013-02-05: `ae9085d` adds `CrashController` "to showcase behaviour when exception occurs".
- 2013-02-13: `23314c5` moves the entity base classes into the `model` package.
- 2013-02-24: `e44552e` adds Dandelion-Datatables for the HTML tables.
- 2013-12-13: `377bc63` moves to Spring 4 and Servlet 3.

### 2014 to 2016: front-end churn and Spring Boot

The project tried several ways to manage the front end before settling, and then moved to Spring Boot.

- 2015-05-11: Java 1.8 by default (`f958964`); 2015-06-29 back to Java 7 "for the time being" (`8b62561`).
- 2015-10-16: `09ed33a` reformats the code with EditorConfig.
- 2016-01-30: `c65cfb6` moves from WebJars to Bower (1,082 files, the largest commit in the history, mostly vendored libraries).
- 2016-02-06: Travis CI configuration added.
- 2016-04-04: `7dcf82a` migrates to Bootstrap 3 (830 files).
- 2016-06-17: `a6e81a5` "Spring Boot version of Petclinic", on Spring Boot 1.3.5. The same commit removes the JDBC, JPA and Spring Data JPA repository packages and the XML Spring configuration in `src/main/resources/spring/`.
- 2016-06-28: `eb6f934` goes back to WebJars, five months after leaving them.
- 2016-10-07: `d69b896` removes Dandelion to support Jetty 9.
- 2016-11-10: `e38a9fe` "Convert to jar with thymeleaf" replaces the JSP views with Thymeleaf templates, on Spring Boot 1.4.1 and Java 8. The same day `83ff9a5` reorganizes the code into the feature packages `owner`, `vet` and `system` that are still used.
- 2016-12-05: `0c7db64` makes MySQL "more first class" and adds `docker-compose.yml`.

### 2017 to 2021: Spring Boot 2 and modern tooling

A quieter period of upgrades, with build and CI tooling replaced piece by piece.

- 2017-11-03: the only tag, `1.5.x`, is set on `c36452a` with Spring Boot 1.5.4. It appears to mark the last Spring Boot 1.5 state before the move to 2.0.
- 2018-01-09: `14ef611` moves to Spring Boot 2.0 snapshots.
- 2020-01-03: `4e1f874` applies the spring-javaformat plugin, which the build still enforces.
- 2020-03-20: `c0847b7` adds H2 and makes it the default database in place of HSQLDB.
- 2021-05-10: `4df621b` "Make build work with Gradle" adds `build.gradle`.
- 2021-09-13: `8ad9c05` adds paging to the owner and vet lists.
- 2021-10-03: the first GitHub Actions workflow (`.github/workflows/maven-build.yml`); Travis is removed on 2021-10-29.
- 2021-11-19: `1095a15` converts the styles from LESS to SCSS and Bootstrap 5.
- 2021-12-07: `ce626da` adds PostgreSQL.

### 2022 to 2024: Spring Boot 3 and Java 17

- 2022-01-05: `c953442` removes `PetRepository` and saves pets and visits through `Owner` as the aggregate.
- 2022-03-30: `1315cf6` "Migrate to Spring Boot 3" raises the Java baseline to 17.
- 2022-06-08: `.devcontainer/` and `.gitpod.yml` are added.
- 2022-10-16: `f53e0d0` prepares native images and replaces Ehcache with Caffeine.
- 2023-08-27 to 2024-11-30: Korean, Portuguese, Russian, Persian and Turkish translations are added.
- 2024-11-07: `a3026bd` adds Kubernetes manifests in `k8s/`.

### 2025: Spring Boot 4

- 2025-09-01: `3aa79e3` moves to Spring Boot 4.0.0-M2.
- 2025-09-02: `a0aea8e` adds NullAway and JSpecify null-safety annotations, building with Java 24.
- 2025-10-14: `6feeae0` builds with Java 25; on 2025-11-26 `828940e` restores support for building with Java 17, together with Spring Boot 4.0.0.
- 2025-12-30: `2beb238` deletes the HSQLDB scripts, five years after H2 replaced HSQLDB.

### 2026: Spring Boot 4.1, hardening and the security branch

- 2026-05-27: `a2c2ef9` registers native-image hints for the nested `db/` scripts. It is the only `origin/main` commit with an AI co-author trailer.
- 2026-06-11: `9a5d50c` upgrades to Spring Boot 4.1.
- 2026-07-14 to 2026-07-22: unique pet names per owner (`e0db9b1`) and a PostgreSQL fix for the new constraint (`88e37c1`); Hindi and Japanese translations.
- 2026-09-18 to 2026-09-29: four hardening changes in five commits: visit description length (`f3c7483`), owner city and address length (`3c7ab98`), integer overflow in page numbers (`b33136f` and `0d064b0`, same message, one per controller) and a redirect for out-of-range pages (`500158f`, the current `origin/main`).
- 2026-11-13: the branch `security/spring-boot-4.1.2-cve-remediation` adds 11 commits up to `2aff817`, all co-authored by `factory-droid[bot]`: the Spring Boot 4.1.2 upgrade that fixes 20 advisories (`d74cc16`), a dependency version guard and failure-scenario tests (`23d0c67`), a redirect for page numbers above 429,496,730 (`3a5a0bc`), CI fixes (`c565970`), Dependabot and OSV-Scanner (`1f28c2c`), `docs/DEPENDENCIES.md` and `docs/RUNBOOK.md` (`0d8c589`), `AGENTS.md` and the Droid hook (`f9bbb32`), the QA skill and workflow (`f643efa`), the wiki refresh workflow (`7a27efc`), a range check that stops `/vets.html` from caching every page number (`0e8563f`, F15) and the runbook follow-ups F15 to F20 (`2aff817`). [Security](security.md) covers the advisories.

## Longest-standing features

| What | Present since | Commits that touched it |
| --- | --- | --- |
| `pom.xml` (Maven build) | 2009-11-25 | 333 |
| `src/main/java/org/springframework/samples/petclinic/owner/OwnerController.java` | 2009-11-25 | 52 |
| `src/main/java/org/springframework/samples/petclinic/owner/Owner.java` | 2009-11-25 | 39 |
| `src/main/java/org/springframework/samples/petclinic/vet/Vet.java` | 2009-11-25 | 23 |
| `src/main/java/org/springframework/samples/petclinic/model/Person.java` | 2009-11-25 | 19 |
| `src/main/resources/db/mysql/schema.sql` | 2009-11-25 | 9 |
| `src/main/resources/messages/messages.properties` (with `_de` and `_en`) | 2009-11-25 | 6 |
| `src/main/java/org/springframework/samples/petclinic/system/CrashController.java` | 2013-02-05 | 12 |

Method: `git log --follow --format=%h origin/main -- <file> | wc -l`, which follows renames, and the date of the oldest commit in that list. The domain itself (owners with pets, pets with visits, vets with specialties) was already in place on 2009-11-25.

## Deprecated features

| Feature | Introduced | Removed | Replaced by |
| --- | --- | --- | --- |
| TopLink Essentials and Hibernate XML mapping | 2009-11-25 | 2013-01-09 to 2013-01-14 | JPA annotations |
| JDBC and plain JPA repository implementations | 2013-01-17 | 2016-06-17 (`a6e81a5`) | Spring Data JPA only |
| XML Spring configuration (`src/main/resources/spring/`) | 2013-01-14 | 2016-06-17 | Spring Boot auto-configuration |
| `web.xml` and the WAR layout | 2009-11-25 | 2016-06-17 to 2016-11-10 | Executable jar |
| JSP views and tag files | 2009-05-05 | 2016-11-10 (`e38a9fe`) | Thymeleaf templates |
| Dandelion-Datatables | 2013-02-24 | 2016-10-07 (`d69b896`) | No direct replacement; server-side paging came on 2021-09-13 |
| Bower | 2016-01-25 | 2016-06-28 (`eb6f934`) | WebJars |
| LESS styles and wro4j | 2016-11-10 | 2021-11-19 (`1095a15`) | SCSS compiled by the Maven `css` profile |
| Travis CI | 2016-02-06 | 2021-10-29 (`bc35c40`) | GitHub Actions |
| HSQLDB as default database | 2009-11-26 | 2020-03-20 in the build, 2025-12-30 for the scripts | H2 |
| `PetRepository` | 2013-01-17 (`c9c8c4e`) | 2022-01-05 (`c953442`) | `OwnerRepository` with `Owner` as aggregate |
| Ehcache (version 3 from 2016-08-29) | 2013-02-14 (`0c09ec3`) | 2022-10-16 (`f53e0d0`) | Caffeine |
| `src/main/docker` | 2016-08-29 | 2016-11-10 | Buildpacks (`./mvnw spring-boot:build-image`) |

Method: `git log origin/main --diff-filter=A` and `--diff-filter=D` per path, plus `git log -S` on `pom.xml` for dependencies. [Cleanup opportunities](cleanup-opportunities.md) lists what could go next.

## Major rewrites

| Date | Commit | Change | Files |
| --- | --- | --- | --- |
| 2016-01-30 | `c65cfb6` | Front-end libraries moved to Bower and vendored | 1,082 |
| 2016-04-04 | `7dcf82a` | Migration to Bootstrap 3 | 830 |
| 2016-06-28 | `eb6f934` | Back to WebJars | 377 |
| 2009-11-25 | `521d01d` | Maven project with most of the original code | 117 |
| 2016-04-08 | `44b591f` | Spring Boot Dataflow UI graphic theme | 117 |
| 2013-01-09 | `87ccf9f` | Start of the Spring 3.2 migration | 95 |
| 2016-06-17 | `a6e81a5` | Spring Boot conversion | 66 |
| 2016-11-10 | `e38a9fe` | Jar with Thymeleaf | 65 |

Method: `git log origin/main --shortstat`, sorted by files changed. The three largest are front-end library moves rather than code changes.

## Growth trajectory

The number of tracked files stayed between 90 and 101 from 2013 to 2020 while the code changed shape underneath, then rose to 132 on `origin/main` and 157 on this branch. Java files dropped from 51 to 34 in 2016 when the extra persistence implementations went away, and were back to 50 by 2026. Distinct authors grew from 13 at the end of 2013 to 39 in 2016, 90 in 2022 and 156 by 2026; the busiest years for new people were 2016 and 2024. [By the numbers](by-the-numbers.md#growth) has the yearly table and [Maintainers](maintainers.md) shows who is active now.

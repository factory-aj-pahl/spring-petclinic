# Features

PetClinic has six user-visible features. Staff work through the owner pages to reach pets and visits, the vets page stands on its own, and two features apply to every page: the language switch and the error page. This page maps them and links to the page for each one.

## Feature map

| Feature | What a user can do | Page |
| --- | --- | --- |
| Owners | Search owners by the start of their last name, page through the results, add an owner, edit an owner, open an owner's details | [Owners](owners.md) |
| Pets | Add a pet to an owner and edit it: name, birth date and type | [Pets](pets.md) |
| Visits | Book a visit for a pet with a future date and a description, and see earlier visits on the owner page | [Visits](visits.md) |
| Vets | List the vets and their specialties, 5 per page, or fetch them as JSON or XML from `/vets` | [Vets](vets.md) |
| Internationalization | Switch the interface language with `?lang=` on any page | [Internationalization](internationalization.md) |
| Error handling | See a generic error page instead of internal details; try it with the "Error" menu item (`/oups`) | [Error handling](error-handling.md) |

Owners, pets and visits all live in one package, `src/main/java/org/springframework/samples/petclinic/owner/`, because `Owner` is the aggregate root that saves its pets and visits. The vets code is in `src/main/java/org/springframework/samples/petclinic/vet/`, and the language and error pages are configured in `src/main/java/org/springframework/samples/petclinic/system/`. [Architecture](../overview/architecture.md) shows how the packages fit together.

## User journey

The navigation bar in `src/main/resources/templates/fragments/layout.html` links to Home, Find owners, Veterinarians and Error on every page.

```mermaid
graph LR
    Home["Home /"] -->|navigation bar| Find["Find owners /owners/find"]
    Find -->|several matches| List["Owner list /owners?lastName="]
    Find -->|one match| Details["Owner details /owners/id"]
    List -->|click a name| Details
    Find -->|Add Owner| NewOwner["Add owner /owners/new"]
    NewOwner -->|saved| Details
    Details -->|Edit Owner| EditOwner["Edit owner"]
    Details -->|Add New Pet or Edit Pet| PetForm["Add or edit pet"]
    Details -->|Add Visit| VisitForm["Book visit"]
    EditOwner -->|saved| Details
    PetForm -->|saved| Details
    VisitForm -->|saved| Details
    Home -->|navigation bar| Vets["Vets /vets.html"]
```

Every form returns to the owner details page after a successful save, with a confirmation message at the top. Adding `?lang=de` (or another supported code) to any URL switches the language for the rest of the session; see [Internationalization](internationalization.md).

## Related pages

- [Patterns and conventions](../how-to-contribute/patterns-and-conventions.md): the controller pattern and validation rules shared by the owner, pet and visit forms.
- [HTTP API](../api.md): every route, including the Actuator endpoints that are not part of the user interface.
- [Data models](../reference/data-models.md): the tables behind these features.

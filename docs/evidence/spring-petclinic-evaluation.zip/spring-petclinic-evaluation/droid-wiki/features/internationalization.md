# Internationalization

Active contributors: Robinson J, Jaguar-H, shivam tiwari

Every visible text in the PetClinic pages comes from a message bundle, and a visitor switches the language with the `lang` URL parameter, for example `/?lang=de`. There are 11 bundle files covering 10 languages, and `I18nPropertiesSyncTest` checks that templates use message keys and that every translation has every key.

## Purpose

The application is a teaching sample, so it shows how Spring MVC and Thymeleaf handle languages: a locale kept in the HTTP session, an interceptor that changes it, and a `MessageSource` that Spring Boot configures from `src/main/resources/application.properties`. There is no language menu in the navigation bar; the URL parameter is the only way to switch.

## Directory layout

```text
src/main/java/org/springframework/samples/petclinic/system/WebConfiguration.java   locale resolver and interceptor
src/main/resources/application.properties                                          spring.messages.basename
src/main/resources/messages/
├── messages.properties        default bundle, English text
├── messages_en.properties     empty on purpose
├── messages_de.properties  messages_es.properties  messages_fa.properties
├── messages_hi.properties  messages_ja.properties  messages_ko.properties
└── messages_pt.properties  messages_ru.properties  messages_tr.properties
src/test/java/org/springframework/samples/petclinic/system/I18nPropertiesSyncTest.java
```

The default bundle has 52 keys. On `origin/main`, 12 distinct authors have changed `src/main/resources/messages/`.

## Languages

| Language | Locale code | File | Notes |
| --- | --- | --- | --- |
| English | `en` (and the default) | `src/main/resources/messages/messages.properties` | `src/main/resources/messages/messages_en.properties` contains only a comment, so English look-ups fall back to the default bundle. |
| German | `de` | `src/main/resources/messages/messages_de.properties` | |
| Spanish | `es` | `src/main/resources/messages/messages_es.properties` | |
| Persian | `fa` | `src/main/resources/messages/messages_fa.properties` | |
| Hindi | `hi` | `src/main/resources/messages/messages_hi.properties` | Written with `\uXXXX` escapes, so the file is plain ASCII. |
| Japanese | `ja` | `src/main/resources/messages/messages_ja.properties` | |
| Korean | `ko` | `src/main/resources/messages/messages_ko.properties` | |
| Portuguese | `pt` | `src/main/resources/messages/messages_pt.properties` | |
| Russian | `ru` | `src/main/resources/messages/messages_ru.properties` | |
| Turkish | `tr` | `src/main/resources/messages/messages_tr.properties` | |

## Key abstractions

| Type | File | What it does |
| --- | --- | --- |
| `SessionLocaleResolver` bean | `src/main/java/org/springframework/samples/petclinic/system/WebConfiguration.java` | Stores the chosen locale in the HTTP session. Its default locale is `Locale.ENGLISH`, so a first visit is in English whatever the browser's `Accept-Language` header says. |
| `LocaleChangeInterceptor` bean | `src/main/java/org/springframework/samples/petclinic/system/WebConfiguration.java` | Registered for every request through `addInterceptors`. When a request has a `lang` parameter, it parses the value as a locale and stores it in the resolver. |
| `MessageSource` | Spring Boot auto-configuration, `spring.messages.basename=messages/messages` in `src/main/resources/application.properties` | Loads `messages/messages*.properties` from the classpath. Spring Boot's default encoding for these files is UTF-8. |
| `I18nPropertiesSyncTest` | `src/test/java/org/springframework/samples/petclinic/system/I18nPropertiesSyncTest.java` | Two checks described below. |

## How it works

```mermaid
sequenceDiagram
    participant B as Browser
    participant I as LocaleChangeInterceptor
    participant S as SessionLocaleResolver
    participant T as Thymeleaf
    participant M as MessageSource
    B->>I: GET /?lang=de
    I->>S: setLocale(de)
    S-->>S: store in the HTTP session
    T->>S: current locale
    T->>M: resolve #{welcome} for de
    M-->>T: Willkommen
    T-->>B: page in German
    B->>T: GET /owners/find (no lang)
    T->>S: current locale, still de from the session
```

The language stays for the rest of the session, which the QA flow W9 in `.factory/skills/qa-web/SKILL.md` checks: after `/?lang=de` the next page is still German.

### Templates

Templates in `src/main/resources/templates/` print text with Thymeleaf message expressions, such as `<h2 th:text="#{vets}">Veterinarians</h2>` in `src/main/resources/templates/vets/vetList.html`. The text inside the tag is only a placeholder for opening the file without a server; Thymeleaf replaces it. Message keys can also be passed into fragments, as the navigation bar does with `#{home}`, `#{findOwners}`, `#{vets}` and `#{error}` in `src/main/resources/templates/fragments/layout.html`. The `<html>` element has no `lang` attribute, so the page does not tell the browser which language it is in.

### Validation and form messages

Form errors are shown by `th:errors` in `src/main/resources/templates/fragments/inputField.html` and `src/main/resources/templates/fragments/selectField.html`. Where the text comes from depends on how the error was raised:

| Source of the error | Example | Where the text comes from |
| --- | --- | --- |
| Bean Validation with a message key | `@Pattern(regexp = "\\d{10}", message = "{telephone.invalid}")` on `telephone` in `src/main/java/org/springframework/samples/petclinic/owner/Owner.java` | The `{...}` placeholder is resolved against the bundles, so the message is translated. Spring Boot's validator uses the application `MessageSource` for interpolation. |
| Bean Validation without a message key | `@NotBlank`, `@Size` on `Person`, `Owner` and `Visit` | Hibernate Validator's built-in messages (for example "must not be blank"). They do not come from these bundles. Which languages Hibernate Validator translates was not checked for this page. |
| `rejectValue` with a code that has a key | `required` (`src/main/java/org/springframework/samples/petclinic/owner/PetValidator.java`), `duplicate` and `typeMismatch.birthDate` (`src/main/java/org/springframework/samples/petclinic/owner/PetController.java`), `typeMismatch.visitDate` (`src/main/java/org/springframework/samples/petclinic/owner/VisitController.java`), `notFound` (`src/main/java/org/springframework/samples/petclinic/owner/OwnerController.java`) | The bundle entry for the code, so the message is translated. |
| `rejectValue` with a code that has no key | `size` in `PetValidator` ("Name must be no more than 30 characters"), `mismatch` in `OwnerController` | The English default message given in the Java call. |
| Type conversion failure while binding | A date the server cannot parse | Spring builds codes such as `typeMismatch.birthDate` and `typeMismatch.date` from the field name, so the keys `typeMismatch.birthDate` and `typeMismatch.date` apply even where no Java code names them. |

The key `typeMismatch.visitDate` ("Visit date must be in the future") is reused by `VisitController` for a date that parsed fine but is not after today, so its name does not describe the check.

Flash messages after a save ("New Owner Created", "New Pet has been Added" and the others listed in [Patterns and conventions](../how-to-contribute/patterns-and-conventions.md)) are English strings in the controllers and are not translated.

### Unsupported languages

`/?lang=xx` does not fail. The interceptor stores the locale `xx`, the `MessageSource` finds no `messages_xx.properties`, and the page is shown in English; the local QA run recorded this for flow W9 (`qa-results/report.md`). Spring Boot's default `spring.messages.fallback-to-system-locale=true` means the lookup tries the JVM's default locale before `src/main/resources/messages/messages.properties`. On a server whose default locale is, say, German, `?lang=xx` would therefore show German. That follows from Spring Boot's defaults and was not tested. A value that is not a valid locale string at all was also not tested.

## What `I18nPropertiesSyncTest` checks

The test has two methods, and both read the source tree from the working directory, so they run only from the repository root (which is how Maven and Gradle run them).

**`checkNonInternationalizedStrings`** walks `src/main`, collects `.java` and `.html` files, but applies its check only to the `.html` files. Java files are read and then ignored. For each trimmed line of a template:

1. Lines that start with `//` or `@`, or contain `log.` or `System.out`, are skipped.
2. The line is reported when it has literal text between a `>` and a `<` on the same line (pattern `>([^<>{}]+)<`), unless the line contains `#{`, has a `th:text` or `th:utext` attribute, or is a bracket-only element such as `<span>[</span>`.

So the test catches `<h2>Owners</h2>`, but not text on a line of its own, text next to a `th:text` attribute on the same line, or English strings in Java code.

**`checkI18nPropertyFilesAreInSync`** walks `src/main/resources`, loads every file whose name starts with `messages` and ends with `.properties` (read as UTF-8), and takes the keys of `src/main/resources/messages/messages.properties` as the reference. For every other file except `src/main/resources/messages/messages_en.properties`, it reports the reference keys that are missing. It does not report extra keys in a translation, empty values, values left in English, or broken characters.

## Adding a message key

1. Add the key and the English text to `src/main/resources/messages/messages.properties`.
2. Add the same key with a translation to each of the nine translated bundles (`_de`, `_es`, `_fa`, `_hi`, `_ja`, `_ko`, `_pt`, `_ru`, `_tr`). Leave `src/main/resources/messages/messages_en.properties` empty.
3. Use it in the template with `th:text="#{yourKey}"`, keeping a placeholder text inside the tag.
4. Run `./mvnw test -Dtest=I18nPropertiesSyncTest`. A missing key fails `checkI18nPropertyFilesAreInSync` with the file and key names.

## Adding a language

1. Copy `src/main/resources/messages/messages.properties` to `src/main/resources/messages/messages_<code>.properties`, where `<code>` is the ISO 639 language code.
2. Translate every value. Save the file as UTF-8, or use `\uXXXX` escapes as the Hindi file does.
3. Nothing else needs registering: the `MessageSource` finds the file by name, `I18nPropertiesSyncTest` picks it up automatically, and `src/main/java/org/springframework/samples/petclinic/PetClinicRuntimeHints.java` already includes `messages/*` for native images.
4. Run `./mvnw test -Dtest=I18nPropertiesSyncTest`, then open `http://localhost:8080/?lang=<code>` to check the pages.
5. Add the language to the table on this page.

## History

From `git log origin/main --diff-filter=A` on `src/main/resources/messages/`:

| Date | Commit | Added |
| --- | --- | --- |
| 2013-01-14 | `09c92b3` "general cleanup" | `src/main/resources/messages/messages.properties`, `src/main/resources/messages/messages_de.properties`, `src/main/resources/messages/messages_en.properties` |
| 2020-06-01 | `0390e85` | Spanish |
| 2023-08-27 | `18266fe` | Korean, "to support at least one non-European language" |
| 2024-10-19 | `bbb2379` | Portuguese |
| 2024-10-20 | `912de16` | Russian |
| 2024-11-30 | `22caee3` | Persian and Turkish |
| 2026-07-16 | `f182358` | Hindi |
| 2026-07-18 | `0f6e861` | Japanese |

`WebConfiguration` and `I18nPropertiesSyncTest` first appear in April 2025 (commits `0c88f91` and `c5af32d`), and the status-specific messages on the error page (`error.404`, `error.500`, `error.general`) were added on 2025-07-31. [Lore](../lore.md) places these in the project's longer history.

## Known issues

- `src/main/resources/messages/messages_de.properties` has the Unicode replacement character in `typeMismatch.date` and `typeMismatch.birthDate` ("ung\uFFFDltiges Datum" instead of "ungültiges Datum"). The cause is not recorded in the history. The sync test does not notice it.
- The keys `nonNumeric` and `duplicateFormSubmission` are in every bundle, but no template or Java file in `src/main` refers to them.

## Integration points

- Every page through the layout and the message keys; see [Web layer](../systems/web-layer.md).
- Validation messages for [Owners](owners.md), [Pets](pets.md) and [Visits](visits.md).
- The error page texts; see [Error handling](error-handling.md).

## Entry points for modification

Language behavior lives in `src/main/java/org/springframework/samples/petclinic/system/WebConfiguration.java`: change the default locale there, or swap `SessionLocaleResolver` for a cookie or `Accept-Language` resolver. To make the hard-coded text check also cover Java, extend `checkNonInternationalizedStrings`, which already collects the Java files.

## Key source files

| File | Purpose |
| --- | --- |
| `src/main/java/org/springframework/samples/petclinic/system/WebConfiguration.java` | Session locale resolver with English default; `lang` interceptor |
| `src/main/resources/application.properties` | `spring.messages.basename=messages/messages` |
| `src/main/resources/messages/messages.properties` | Default (English) texts, the reference key set |
| `src/main/resources/templates/fragments/layout.html` | Navigation bar and title keys |
| `src/test/java/org/springframework/samples/petclinic/system/I18nPropertiesSyncTest.java` | Hard-coded text check for templates and key sync check for bundles |

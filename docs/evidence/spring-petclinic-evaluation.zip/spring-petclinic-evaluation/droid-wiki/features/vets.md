# Vets

Active contributors: Pedro Arthur Hartmann, king-407, Dave Syer

The vets feature lists the clinic's veterinarians and their specialties. It has two routes: an HTML page at `/vets.html`, five vets per page, and a resource at `/vets` that returns the whole list as JSON or XML. Vets are read-only in the application, and both queries are cached.

## Purpose

Visitors look up which vets work at the clinic and what each one specializes in. API clients and the QA checks read the same data from `/vets`. No page creates, edits or deletes a vet; vets come only from the seed scripts or from direct changes to the database.

## Directory layout

```text
src/main/java/org/springframework/samples/petclinic/vet/
├── Specialty.java          entity, table specialties
├── Vet.java                entity, table vets, many-to-many to specialties
├── VetController.java      /vets.html and /vets
├── VetRepository.java      read-only, cached Spring Data repository
├── Vets.java               JSON/XML wrapper around the list
└── package-info.java
src/main/resources/templates/vets/vetList.html
src/test/java/org/springframework/samples/petclinic/vet/
├── VetControllerTests.java
└── VetTests.java
```

Six main files and two test classes. On `origin/main`, 14 distinct authors have changed `src/main/java/org/springframework/samples/petclinic/vet/` since 2016.

## Key abstractions

| Type | File | What it is |
| --- | --- | --- |
| `Vet` | `src/main/java/org/springframework/samples/petclinic/vet/Vet.java` | Entity that extends `Person` (first and last name). `specialties` is a `@ManyToMany(fetch = EAGER)` through the join table `vet_specialties`. `getSpecialties()` returns the specialties sorted by name. `getNrOfSpecialties()` returns the count. |
| `Specialty` | `src/main/java/org/springframework/samples/petclinic/vet/Specialty.java` | Entity that extends `NamedEntity`, table `specialties`. No fields of its own. |
| `Vets` | `src/main/java/org/springframework/samples/petclinic/vet/Vets.java` | `@XmlRootElement` wrapper with one `@XmlElement` getter, `getVetList()`. It exists so `/vets` returns one object instead of a bare list. |
| `VetRepository` | `src/main/java/org/springframework/samples/petclinic/vet/VetRepository.java` | Extends `Repository<Vet, Integer>`, so it declares only two read methods: `findAll()` and `findAll(Pageable)`. Both are `@Transactional(readOnly = true)` and `@Cacheable("vets")`. |
| `VetController` | `src/main/java/org/springframework/samples/petclinic/vet/VetController.java` | Package-private controller for both routes. |

## Routes

| Method and path | Handler | Response |
| --- | --- | --- |
| `GET /vets.html?page=N` | `VetController.showVetList` | Renders `vets/vetList` with five vets for page N (default 1). Page numbers below 1 or past the last page redirect to `/vets.html?page=1`. A page that is not an `int`, such as `abc` or `2147483648`, gives HTTP 400. |
| `GET /vets` | `VetController.showResourcesVetList` | `@ResponseBody` with a `Vets` object: JSON for `Accept: application/json`, XML for `Accept: application/xml`, HTTP 406 for a type the application cannot write, such as `text/csv`. |

The navigation bar links to `/vets.html` as "Veterinarians" (`src/main/resources/templates/fragments/layout.html`). [HTTP API](../api.md) lists every route in the application.

## How it works

### The HTML list

`showVetList` first reads the full vet list through the cached `findAll()` and computes the last page: the number of vets divided by five, rounded up, and at least 1. A page below 1 or above the last page redirects to `/vets.html?page=1` before any paged query runs, so a huge number such as `2147483647` ends on page 1 instead of failing or adding a cache entry. For an existing page the handler runs the cached `findAll(PageRequest.of(page - 1, 5))`. Commit `0e8563f` moved the range check in front of the paged query (F15 in `docs/RUNBOOK.md`); before that, every distinct page number added an entry to the `vets` cache, which has no size limit. The owners list clamps the page number instead, because its query is not cached; [Owners](owners.md) and [Patterns and conventions](../how-to-contribute/patterns-and-conventions.md#paging) describe it.

`src/main/resources/templates/vets/vetList.html` renders a table with the vet's full name and the specialties, each followed by a space, in the order `Vet.getSpecialties()` returns them (alphabetical). When `vet.nrOfSpecialties == 0`, the template shows the message key `none` instead, which is "none" in `src/main/resources/messages/messages.properties` and translated in the other bundles ("keine" in German). The page links are shown only when there is more than one page. With the seed data there are six vets, so the list has two pages.

### The JSON and XML resource

`/vets` reads `vetRepository.findAll()` and wraps it in `Vets`. Spring MVC picks the message converter from the request's `Accept` header:

```mermaid
sequenceDiagram
    participant C as Client
    participant D as DispatcherServlet
    participant V as VetController
    participant R as VetRepository
    participant K as Cache vets
    C->>D: GET /vets, Accept header
    D->>V: showResourcesVetList()
    V->>R: findAll()
    R->>K: look up the entry
    alt cached
        K-->>R: Collection of Vet
    else not cached
        R->>R: query vets and specialties
        R->>K: store the result
    end
    V-->>D: Vets
    alt application/json
        D-->>C: 200, Jackson JSON
    else application/xml
        D-->>C: 200, JAXB XML
    else no converter for the type
        D-->>C: 406 Not Acceptable
    end
```

- **JSON** comes from Jackson 3 (`tools.jackson.core:jackson-databind` 3.1.7, a dependency of `spring-boot-jackson` according to the SBOM). The body is `{"vetList":[...]}`. Each vet has `id`, `firstName`, `lastName`, `specialties`, and also `new` and `nrOfSpecialties`, because Jackson serializes every public getter, including `BaseEntity.isNew()`. The QA run in `qa-results/` recorded this output.
- **XML** comes from JAXB. `pom.xml` and `build.gradle` declare `jakarta.xml.bind:jakarta.xml.bind-api`, and the JAXB implementation `org.glassfish.jaxb:jaxb-runtime` 4.0.9 arrives as a dependency of `hibernate-core` (the SBOM shows this). With JAXB on the classpath, Spring MVC registers its JAXB converter for classes annotated with `@XmlRootElement`, which is why `Vets` has that annotation. The XML root is `<vets>`, with one `<vetList>` element per vet and one `<specialties>` element per specialty. There is no `jackson-dataformat-xml` in the jar.
- **Other types**, such as `text/csv`, get HTTP 406 with an empty body (`.factory/skills/qa-api/SKILL.md` flow A1, which passed in the local QA run).

Which format a request with no `Accept` header or with `Accept: */*` receives is decided by the converter order in Spring MVC. This page does not confirm it, because no test or recorded run covers that case.

### Caching and database outages

Both repository methods use the cache named `vets`. Spring Boot backs it with Caffeine, and no expiry is configured in `src/main/resources/application.properties`, so a result stays cached until the application restarts. Because the vets are read-only in the application, nothing in the code needs to evict the cache; a vet changed directly in the database does not show up until a restart.

The cache is also why `/vets` keeps answering when the database is down. `src/test/java/org/springframework/samples/petclinic/PostgresOutageIntegrationTests.java` requests `/vets` while PostgreSQL runs, stops the container, and then expects `/vets` to return 200 "served from the cache" while `/owners/1` returns the 500 error page. The test checks only `/vets`; each `/vets.html` page is a separate cache entry keyed by its `Pageable`, so only pages that were already requested before the outage would be served. [Caching](../systems/caching.md) covers the cache setup and the JCache customizer that never runs (F12).

## Seed data

`src/main/resources/db/h2/data.sql` loads six vets, three specialties and five vet-specialty links. The MySQL and PostgreSQL scripts in `src/main/resources/db/` load the same rows.

| Vet | Specialties |
| --- | --- |
| James Carter | none |
| Helen Leary | radiology |
| Linda Douglas | dentistry, surgery |
| Rafael Ortega | surgery |
| Henry Stevens | radiology |
| Sharon Jenkins | none |

[Data models](../reference/data-models.md) describes the `vets`, `specialties` and `vet_specialties` tables.

## Tests

| Test | What it checks |
| --- | --- |
| `src/test/java/org/springframework/samples/petclinic/vet/VetControllerTests.java` | `@WebMvcTest` slice with a mocked `VetRepository`, 5 tests: the HTML list renders `vets/vetList` with `listVets`; pages 0 and 2 redirect to page 1; pages 0, 2, `429496731` and `Integer.MAX_VALUE` redirect without calling `findAll(Pageable)`; page 1 queries `PageRequest.of(0, 5)`; `/vets` with `Accept: application/json` returns JSON with `vetList[0].id` equal to 1. |
| `src/test/java/org/springframework/samples/petclinic/vet/VetTests.java` | One test: a `Vet` survives Java serialization (needed for the GraalVM serialization hints in `PetClinicRuntimeHints`). |
| `src/test/java/org/springframework/samples/petclinic/UntrustedInputIntegrationTests.java` | `/vets.html` with page `-2147483648`, `429496731` and `2147483647` redirects to page 1; `2147483648` gives 400. `outOfRangeVetPagesAreNotCached` requests pages 3 to 202 and checks that none of them adds an entry to the `vets` cache. |
| `src/test/java/org/springframework/samples/petclinic/PostgresOutageIntegrationTests.java` | `/vets` returns 200 during a database outage. Needs Docker. |
| `src/test/java/org/springframework/samples/petclinic/service/ClinicServiceTests.java` | `shouldFindVets` loads the seeded vets through `VetRepository` and checks that Linda Douglas has two specialties, returned as dentistry then surgery. |

No automated test checks the XML output or the 406 response; the QA skill (`.factory/skills/qa-api/SKILL.md`) covers both. [Testing](../how-to-contribute/testing.md) explains the test layers.

## Integration points

- **Persistence:** `VetRepository` is a Spring Data JPA interface; see [Persistence](../systems/persistence.md).
- **Caching:** the `vets` cache, enabled by `@EnableCaching` in `src/main/java/org/springframework/samples/petclinic/system/CacheConfiguration.java`; see [Caching](../systems/caching.md).
- **Layout and messages:** the page uses the shared layout with the menu item `vets` and the message keys `vets`, `name`, `specialties`, `none`, `pages`, `first`, `previous`, `next` and `last`; see [Internationalization](internationalization.md).
- **Native images:** `src/main/java/org/springframework/samples/petclinic/PetClinicRuntimeHints.java` registers `Vet` for serialization.

## Entry points for modification

To add a field to the vet list, add it to `Vet` (and the `vets` table in every schema.sql under `src/main/resources/db/`), then to `src/main/resources/templates/vets/vetList.html` with a new message key in all bundles. JSON picks up any new public getter automatically, while XML follows JAXB's rules for the property. If you ever add a way to change vets, add cache eviction (`@CacheEvict("vets")`) at the same time, or the lists keep showing the old data.

## Key source files

| File | Purpose |
| --- | --- |
| `src/main/java/org/springframework/samples/petclinic/vet/VetController.java` | HTML list with the page range check, paging and redirects; JSON/XML resource |
| `src/main/java/org/springframework/samples/petclinic/vet/VetRepository.java` | Read-only repository with two cached `findAll` methods |
| `src/main/java/org/springframework/samples/petclinic/vet/Vet.java` | Vet entity, sorted specialties, `@XmlElement` getter |
| `src/main/java/org/springframework/samples/petclinic/vet/Vets.java` | `@XmlRootElement` wrapper returned by `/vets` |
| `src/main/java/org/springframework/samples/petclinic/vet/Specialty.java` | Specialty entity |
| `src/main/resources/templates/vets/vetList.html` | Vets table and page links |
| `src/main/resources/db/h2/data.sql` | Seed vets, specialties and links |

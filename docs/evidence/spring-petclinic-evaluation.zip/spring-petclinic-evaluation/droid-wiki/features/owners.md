# Owners

Active contributors: Pedro Arthur Hartmann, Ayush Keshri, Rennan Ballaro Gomes de Sousa

Owners are the entry point to everything a clinic user does. `OwnerController` handles the search form, the paged result list, the add and edit forms and the owner details page, which also lists the owner's pets and their visits.

## Purpose

Staff look up an owner by last name, open the owner's page, and from there add or edit pets and book visits. An owner has a first and last name, an address, a city and a 10-digit telephone number (`src/main/java/org/springframework/samples/petclinic/owner/Owner.java`, `src/main/java/org/springframework/samples/petclinic/model/Person.java`).

## Directory layout

```
src/main/java/org/springframework/samples/petclinic/owner/
  Owner.java               entity, aggregate root for pets and visits
  OwnerController.java     find, list, create, edit, show
  OwnerRepository.java     Spring Data JPA repository
src/main/resources/templates/owners/
  findOwners.html          search form
  ownersList.html          paged result table
  createOrUpdateOwnerForm.html
  ownerDetails.html        owner, pets, visits, flash messages
src/test/java/org/springframework/samples/petclinic/owner/
  OwnerControllerTests.java
  OwnerTests.java
```

The whole `owner` package has 12 files and about 1,030 lines of main code, with about 1,010 lines of tests in the matching test package, so the ratio is close to 1:1. On `origin/main`, 34 distinct people have changed the package.

## Key abstractions

| Type | File | Description |
| --- | --- | --- |
| `Owner` | `src/main/java/org/springframework/samples/petclinic/owner/Owner.java` | Entity for table `owners`. Holds the pets (`@OneToMany(cascade = ALL, fetch = EAGER)`, ordered by name) and helpers `addPet`, `getPet(...)` and `addVisit`. |
| `Person` | `src/main/java/org/springframework/samples/petclinic/model/Person.java` | Superclass with `firstName` and `lastName`, both `@NotBlank @Size(max = 30)`. |
| `OwnerRepository` | `src/main/java/org/springframework/samples/petclinic/owner/OwnerRepository.java` | `JpaRepository<Owner, Integer>` with the derived query `findByLastNameStartingWith(String, Pageable)`. |
| `OwnerController` | `src/main/java/org/springframework/samples/petclinic/owner/OwnerController.java` | Package-private controller for every `/owners` route except pets and visits. |

## Routes

| Method and path | Handler | Result |
| --- | --- | --- |
| `GET /owners/find` | `initFindForm` | `owners/findOwners` |
| `GET /owners?lastName=&page=` | `processFindForm` | `owners/ownersList`, a redirect to `/owners/{id}`, `owners/findOwners` with an error, or a redirect to page 1 |
| `GET /owners/new` | `initCreationForm` | `owners/createOrUpdateOwnerForm` |
| `POST /owners/new` | `processCreationForm` | Redirect to `/owners/{id}`, or the form with errors |
| `GET /owners/{ownerId}/edit` | `initUpdateOwnerForm` | `owners/createOrUpdateOwnerForm` filled with the stored owner |
| `POST /owners/{ownerId}/edit` | `processUpdateOwnerForm` | Redirect to `/owners/{ownerId}`, or the form with errors |
| `GET /owners/{ownerId}` | `showOwner` | `owners/ownerDetails` |

A non-numeric or too large `ownerId` or `page` gives HTTP 400, and an unknown `ownerId` gives HTTP 500 (both covered by `src/test/java/org/springframework/samples/petclinic/UntrustedInputIntegrationTests.java`; the 500 is follow-up F3 in `docs/RUNBOOK.md`). [Error handling](error-handling.md) explains the error page.

## How it works

The controller follows the shared form pattern: a `@ModelAttribute("owner")` loader, an `@InitBinder` that disallows `id` and `*.id`, `@Valid` binding, and post-redirect-get with a flash message. [Patterns and conventions](../how-to-contribute/patterns-and-conventions.md) explains the pattern and has the validation table for owner fields.

### Search

```mermaid
sequenceDiagram
    participant B as Browser
    participant C as OwnerController
    participant R as OwnerRepository
    B->>C: GET /owners?lastName=Davis&page=1
    C->>C: strip lastName, null becomes ""
    C->>C: clamp page to 1..Integer.MAX_VALUE / 5
    C->>R: findByLastNameStartingWith("Davis", page of 5)
    R-->>C: Page of owners
    alt page < 1 or page > max(totalPages, 1)
        C-->>B: 302 /owners?page=1&lastName=Davis
    else no owners
        C-->>B: findOwners with "has not been found"
    else exactly one owner
        C-->>B: 302 /owners/{id}
    else several owners
        C-->>B: ownersList, page 1 of N
    end
```

`processFindForm` in `src/main/java/org/springframework/samples/petclinic/owner/OwnerController.java`:

- **Prefix match.** The query is `OwnerRepository.findByLastNameStartingWith`, so "Da" finds "Davis". The input is trimmed with `String.strip()`, so " Franklin " and "Franklin" give the same result (added 2026-07-24 in "fix: normalize whitespace in owner search").
- **Empty search lists everyone.** A missing or blank `lastName` becomes `""`, which matches every owner. The navigation bar link goes to the form; submitting it empty lists all owners.
- **One match** redirects to the owner details page instead of showing a one-row list.
- **No match** re-renders `owners/findOwners` with the field error code `notFound`, shown as "has not been found" from `src/main/resources/messages/messages.properties`.
- **Case.** The query has no `IgnoreCase`, so case handling comes from the database column. The H2 schema declares `owners.last_name` as `VARCHAR_IGNORECASE(30)`, so on H2 "davis" finds "Davis". The PostgreSQL schema uses `TEXT`, where `LIKE` is case-sensitive, and the MySQL schema depends on the server's default collation. This is read from `src/main/resources/db/*/schema.sql` and not covered by a test.

### Paging

The list shows 5 owners per page. Before building the `PageRequest`, `findPaginatedForOwnersLastName` clamps the page to at least 1 and at most `Integer.MAX_VALUE / 5` (429,496,729), because Spring Data JPA rejects query offsets above `Integer.MAX_VALUE`. The handler then compares the page the user asked for with the real page count. Anything below 1 or above `max(totalPages, 1)` redirects to `/owners?page=1`, and keeps `lastName` in the redirect when it is not empty. A `page` value that is not an `int` (`abc`, `2147483648`) fails conversion and gives HTTP 400.

History on `origin/main` and this branch:

| Date | Commit | Change |
| --- | --- | --- |
| 2021-09-13 | `8ad9c05` | "Add pagination for owners and vets lists in HTML" |
| 2026-09-24 | `0d064b0` | Negative and zero pages clamped to 1 before the query |
| 2026-09-29 | `500158f` | Out-of-range pages redirect to page 1 |
| 2026-11-13 | `3a5a0bc` (this branch) | Cap at `Integer.MAX_VALUE / pageSize`; page numbers from 429,496,731 up returned HTTP 500 before |

The page links in `src/main/resources/templates/owners/ownersList.html` are built as `/owners?page=N` without `lastName`. Following "next" from a filtered list that has more than one page therefore shows page 2 of all owners, not of the search. Nothing in the tests checks the links.

### Create and edit

Both forms use `src/main/resources/templates/owners/createOrUpdateOwnerForm.html`, which shows "Add Owner" or "Update Owner" depending on whether the owner is new. Field rules (names 30 characters, address 255, city 80, telephone exactly 10 digits) are in the validation table on [Patterns and conventions](../how-to-contribute/patterns-and-conventions.md). On success, create saves through `OwnerRepository.save` and redirects to `/owners/{id}` with "New Owner Created"; edit redirects to `/owners/{ownerId}` with "Owner Values Updated".

On a validation error both handlers call `redirectAttributes.addFlashAttribute("error", ...)` and then return the form view. Spring MVC keeps flash attributes only when the handler redirects, so as far as the code shows these error texts are never displayed; the form shows the per-field messages instead.

**The owner id mismatch branch cannot be reached through HTTP.** `processUpdateOwnerForm` checks `Objects.equals(owner.getId(), ownerId)` and redirects back to the edit form with an "Owner ID mismatch" flash message when they differ. But the `owner` argument is the object that `findOwner` loaded with `findById(ownerId)`, and `@InitBinder` stops a form from changing its `id`. A real request therefore always has matching ids. `OwnerControllerTests.processUpdateOwnerFormWithIdMismatch` reaches the branch only by mocking `findById(1)` to return an owner whose id is 2 and passing it in as a flash attribute. The `rejectValue("id", ...)` call in that branch is also lost, because the handler redirects.

### Owner details

`showOwner` loads the owner again with `findById` and renders `src/main/resources/templates/owners/ownerDetails.html`: the owner's fields, "Edit Owner" and "Add New Pet" buttons, and a "Pets and Visits" table with one row per pet (name, birth date, type) and that pet's visits by date. Pets come ordered by name (`@OrderBy("name")` on `Owner.pets`) and visits by date (`@OrderBy("date ASC")` on `Pet.visits`). Each pet row links to "Edit Pet" and "Add Visit"; see [Pets](pets.md) and [Visits](visits.md).

The page shows the flash `message` in a green box (`id="success-message"`) and a flash `error` in a red box (`id="error-message"`). A script at the end of the template hides both after 3 seconds. Each box is rendered only when its attribute is set, and the script calls `document.getElementById(...).style` on both without checking for `null`:

- Only a success message (the usual case): the success box is hidden, then the script throws a `TypeError` on the missing error box. The user sees nothing wrong.
- Only an error message: the script throws on the missing success box first, so the error box is never hidden.
- Neither: the script throws after 3 seconds.

This is read from the template, not observed in a browser. In practice no current handler redirects to this page with an `error` attribute.

## Integration points

- [Pets](pets.md) and [Visits](visits.md) reuse `OwnerRepository` and save through the owner aggregate.
- [Persistence](../systems/persistence.md) covers the schema scripts and profiles; [Data models](../reference/data-models.md) lists the `owners` columns.
- [Internationalization](internationalization.md): labels come from message keys, but the flash messages ("New Owner Created", "Owner Values Updated") are English strings in the controller.

## Tests

| Test | What it covers |
| --- | --- |
| `src/test/java/org/springframework/samples/petclinic/owner/OwnerControllerTests.java` | `@WebMvcTest` slice: forms, field errors and size limits, search by name, trimming, whitespace-only search, not found, out-of-range and huge pages, edit, details, the id mismatch branch |
| `src/test/java/org/springframework/samples/petclinic/owner/OwnerTests.java` | `Owner.addPet` adds a saved pet once |
| `src/test/java/org/springframework/samples/petclinic/UntrustedInputIntegrationTests.java` | Full stack: page redirects up to `2147483647`, HTTP 400 for malformed numbers, HTTP 500 error page for unknown ids without internal details |
| `src/test/java/org/springframework/samples/petclinic/PetClinicIntegrationTests.java` | `/owners/1` and `/owners?lastName=` return 200 against H2 |
| `src/test/java/org/springframework/samples/petclinic/PetClinicConcurrencyTests.java` | Adds pets to owner 1 over HTTP; see [Pets](pets.md) |
| `src/test/java/org/springframework/samples/petclinic/service/ClinicServiceTests.java` | Repository queries against the seed data |

[Testing](../how-to-contribute/testing.md) describes the test layers.

## Entry points for modification

To change the search, edit `processFindForm` and `findPaginatedForOwnersLastName` in `src/main/java/org/springframework/samples/petclinic/owner/OwnerController.java`, and add a case to `OwnerControllerTests` first. To add an owner field, add the column to all three schema.sql files under `src/main/resources/db/`, the field with a matching `@Size` to `Owner`, an `inputField` line to `src/main/resources/templates/owners/createOrUpdateOwnerForm.html`, and the label key to every message bundle. Known traps are collected in [Pitfalls](../background/pitfalls.md).

## Key source files

| File | Purpose |
| --- | --- |
| `src/main/java/org/springframework/samples/petclinic/owner/OwnerController.java` | Search, paging, create, edit and details handlers |
| `src/main/java/org/springframework/samples/petclinic/owner/Owner.java` | Owner entity, validation, pet and visit helpers |
| `src/main/java/org/springframework/samples/petclinic/owner/OwnerRepository.java` | Prefix search and `findById` |
| `src/main/resources/templates/owners/findOwners.html` | Search form with the "has not been found" error |
| `src/main/resources/templates/owners/ownersList.html` | Result table and page links |
| `src/main/resources/templates/owners/createOrUpdateOwnerForm.html` | Add and edit form |
| `src/main/resources/templates/owners/ownerDetails.html` | Owner, pets, visits and flash messages |

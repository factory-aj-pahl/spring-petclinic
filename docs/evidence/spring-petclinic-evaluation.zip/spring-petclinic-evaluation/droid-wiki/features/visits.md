# Visits

Active contributors: Pedro Arthur Hartmann, Ayush Keshri, Rennan Ballaro Gomes de Sousa

A visit is a booked appointment for one pet, with a date and a description. `VisitController` shows the booking form and saves the visit through the owner, and the owner details page lists every pet's visits by date.

## Purpose

Users book a visit from the "Add Visit" link next to a pet on the owner page. Visits cannot be edited or cancelled in the application; the only operations are create and list.

## Directory layout

```
src/main/java/org/springframework/samples/petclinic/owner/
  Visit.java               entity, table visits
  VisitController.java     booking form and submit
  Owner.java               addVisit(petId, visit)
  Pet.java                 visits collection, ordered by date
src/main/resources/templates/pets/createOrUpdateVisitForm.html
src/main/resources/templates/fragments/inputField.html
src/main/resources/templates/owners/ownerDetails.html
src/test/java/org/springframework/samples/petclinic/owner/VisitControllerTests.java
```

## Key abstractions

| Type | File | Description |
| --- | --- | --- |
| `Visit` | `src/main/java/org/springframework/samples/petclinic/owner/Visit.java` | `BaseEntity` with `date` (column `visit_date`, `@DateTimeFormat(pattern = "yyyy-MM-dd")`) and `description` (`@NotBlank @Size(max = 255)`). The constructor sets the date to tomorrow. |
| `VisitController` | `src/main/java/org/springframework/samples/petclinic/owner/VisitController.java` | Loads the owner and pet, exposes `minVisitDate`, checks the date and saves. |
| `Owner.addVisit` | `src/main/java/org/springframework/samples/petclinic/owner/Owner.java` | Finds the pet by id (asserting it exists) and adds the visit to it. |
| `Pet.visits` | `src/main/java/org/springframework/samples/petclinic/owner/Pet.java` | `@OneToMany(cascade = ALL, fetch = EAGER)`, `@OrderBy("date ASC")`, held in a `LinkedHashSet`. |

## Routes

| Method and path | Handler | Result |
| --- | --- | --- |
| `GET /owners/{ownerId}/pets/{petId}/visits/new` | `initNewVisitForm` | `pets/createOrUpdateVisitForm` |
| `POST /owners/{ownerId}/pets/{petId}/visits/new` | `processNewVisitForm` | Redirect to `/owners/{ownerId}` with "Your visit has been booked", or the form with errors |

Both routes run `loadPetWithVisit` first. An unknown owner id, or a pet id that does not belong to the owner, throws `IllegalArgumentException` ("Pet with id ... not found for owner with id ...") and gives the HTTP 500 error page; `src/test/java/org/springframework/samples/petclinic/UntrustedInputIntegrationTests.java` checks `/owners/1/pets/999999/visits/new`. This is follow-up F3 in `docs/RUNBOOK.md`. A non-numeric id gives HTTP 400. See [Error handling](error-handling.md).

## How it works

`VisitController` uses the same loader, `@InitBinder` and post-redirect-get pattern as the other form controllers ([Patterns and conventions](../how-to-contribute/patterns-and-conventions.md)).

```mermaid
sequenceDiagram
    participant B as Browser
    participant C as VisitController
    participant O as Owner
    participant R as OwnerRepository
    B->>C: POST /owners/1/pets/7/visits/new
    C->>R: findById(1)
    R-->>C: Owner with pets and visits
    C->>O: getPet(7), then pet.addVisit(new Visit())
    C->>C: bind date and description, run Bean Validation
    C->>C: reject date if not after today
    alt errors
        C-->>B: 200, form with messages
    else valid
        C->>O: addVisit(7, visit)
        C->>R: save(owner)
        C-->>B: 302 /owners/1, "Your visit has been booked"
    end
```

### Loading the pet

`loadPetWithVisit` is a `@ModelAttribute("visit")` method, so it runs before both handlers. It loads the owner with `OwnerRepository.findById`, finds the pet with `Owner.getPet(Integer)`, puts `pet` and `owner` in the model, creates a `new Visit()` and adds it to the pet's visits in memory. The form then binds onto that visit. `@InitBinder` disallows `id` and `*.id`, so the form cannot choose the visit id.

### Date rules

The date has three layers:

| Layer | What it does | Where |
| --- | --- | --- |
| Default value | `new Visit()` sets `date` to `LocalDate.now().plusDays(1)`, so the form opens with tomorrow filled in. Before 2026-06-01 the default was today. | `src/main/java/org/springframework/samples/petclinic/owner/Visit.java` |
| Browser hint | `minVisitDate()` is a `@ModelAttribute` that returns tomorrow. `src/main/resources/templates/fragments/inputField.html` writes it as `th:min="${minVisitDate}"` on every `type="date"` input, so the visit form's date picker offers no date before tomorrow. On the pet form there is no `minVisitDate` in the model and Thymeleaf leaves the `min` attribute out. | `src/main/java/org/springframework/samples/petclinic/owner/VisitController.java` |
| Server check | `processNewVisitForm` rejects any date that is not after `LocalDate.now()`, so today and earlier fail, with code `typeMismatch.visitDate` ("Visit date must be in the future"). | `VisitController.processNewVisitForm` |

The browser hint and the server check were added together on 2026-06-01 (`753d35c`, "Validate future visit dates"), along with the `typeMismatch.visitDate` key in every translated bundle. "Today" is the server's date in its default time zone, because the code uses `LocalDate.now()`.

The server check runs only when `date` is not `null`, and `Visit.date` has no `@NotNull`. From reading the code, a request with an empty `date` binds `null`, passes validation and is saved without a date. The browser date input makes this unlikely, and no test covers it.

### Description rules

`description` is `@NotBlank` and `@Size(max = 255)`, matching `VARCHAR(255)` in the H2 and MySQL schemas (PostgreSQL uses `TEXT`). The length limit was added on 2026-09-18 (`f3c7483`). Before that, a longer description passed validation and reached the database, where the `VARCHAR(255)` column rejects it, which shows up as HTTP 500 rather than a form message.

### Saving

On success `processNewVisitForm` calls `owner.addVisit(petId, visit)` and `OwnerRepository.save(owner)`; the cascade on `Owner.pets` and `Pet.visits` writes the new row. There is no `VisitRepository`. See [Persistence](../systems/persistence.md).

### The form

`src/main/resources/templates/pets/createOrUpdateVisitForm.html` shows:

- a heading "New Visit";
- a table with the pet's name, birth date, type and owner;
- the form with `inputField` fragments for date (`type="date"`) and description, and a hidden `petId` input. `Visit` has no `petId` property, so that input is not bound; the handler takes `petId` from the path;
- a "Previous Visits" table of the pet's visits. Its row has `th:if="${!visit['new']}"` and `th:each="visit : ${pet.visits}"`. Thymeleaf runs `th:each` before `th:if`, so the condition tests each listed visit and hides the unsaved one that `loadPetWithVisit` added.

The labels `'Date'` and `'Description'` and the word "Visit" in the heading are English literals, not message keys, so they stay in English after a language switch ([Internationalization](internationalization.md)).

### Visit history

The owner details page, `src/main/resources/templates/owners/ownerDetails.html`, shows each pet's visits in a small table next to the pet: date (`yyyy-MM-dd`) and description. The order comes from `@OrderBy("date ASC")` on `Pet.visits`, so the oldest visit is first and future bookings are at the end. Past and future visits are listed together. The seed data in `src/main/resources/db/h2/data.sql` has 4 visits, for pets 7 and 8. [Owners](owners.md#owner-details) describes the rest of the page.

## Integration points

- Owner and pet loading through `OwnerRepository`, shared with [Owners](owners.md) and [Pets](pets.md).
- The `visits` table and its foreign key to `pets` are described in [Data models](../reference/data-models.md).

## Tests

| Test | What it covers |
| --- | --- |
| `src/test/java/org/springframework/samples/petclinic/owner/VisitControllerTests.java` | Form renders; booking for tomorrow redirects; missing description is an error; today is rejected with `typeMismatch.visitDate`; a 256-character description is rejected |
| `src/test/java/org/springframework/samples/petclinic/service/ClinicServiceTests.java` | `shouldAddNewVisitForPet`: `Owner.addVisit` and `save` give the new visit an id |
| `src/test/java/org/springframework/samples/petclinic/UntrustedInputIntegrationTests.java` | Unknown pet id on the visit form gives the error page without internal details |

No test checks the `min` attribute in the rendered HTML, a missing date, or the order of visits on the owner page. [Testing](../how-to-contribute/testing.md) explains how to add tests.

## Entry points for modification

Date and description rules live in `src/main/java/org/springframework/samples/petclinic/owner/Visit.java` and `VisitController.processNewVisitForm`; add a case to `VisitControllerTests` before changing them. To let users edit or cancel visits, add handlers to `VisitController` and a way to find a visit by id on `Pet`, since there is no visit repository. Known traps are in [Pitfalls](../background/pitfalls.md).

## Key source files

| File | Purpose |
| --- | --- |
| `src/main/java/org/springframework/samples/petclinic/owner/VisitController.java` | Loader, `minVisitDate`, date check and save |
| `src/main/java/org/springframework/samples/petclinic/owner/Visit.java` | Visit entity, default date, description rules |
| `src/main/java/org/springframework/samples/petclinic/owner/Owner.java` | `addVisit(petId, visit)` |
| `src/main/java/org/springframework/samples/petclinic/owner/Pet.java` | Visits collection and its order |
| `src/main/resources/templates/pets/createOrUpdateVisitForm.html` | Booking form and previous visits |
| `src/main/resources/templates/fragments/inputField.html` | Text and date inputs, `min` attribute |
| `src/main/resources/templates/owners/ownerDetails.html` | Visit history per pet |

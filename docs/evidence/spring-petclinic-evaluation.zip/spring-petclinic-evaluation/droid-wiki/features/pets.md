# Pets

Active contributors: Pedro Arthur Hartmann, Ayush Keshri, Rennan Ballaro Gomes de Sousa

A pet belongs to one owner and has a name, a birth date and a type. `PetController` adds and edits pets through the owner aggregate, `PetValidator` checks the form, and the database backs up the rule that an owner cannot have two pets with the same name.

## Purpose

From the owner details page a user can add a new pet or edit an existing one. There is no page that lists pets on their own and no way to delete a pet; pets appear only on the owner page ([Owners](owners.md)).

## Directory layout

```
src/main/java/org/springframework/samples/petclinic/owner/
  Pet.java                 entity, table pets
  PetType.java             entity, table types
  PetController.java       add and edit handlers
  PetValidator.java        Spring Validator for the pet form
  PetTypeFormatter.java    converts between PetType and its name
  PetTypeRepository.java   findPetTypes(), ordered by name
src/main/resources/templates/pets/createOrUpdatePetForm.html
src/main/resources/templates/fragments/inputField.html
src/main/resources/templates/fragments/selectField.html
src/main/resources/db/{h2,mysql,postgres}/schema.sql
```

## Key abstractions

| Type | File | Description |
| --- | --- | --- |
| `Pet` | `src/main/java/org/springframework/samples/petclinic/owner/Pet.java` | `NamedEntity` with `birthDate` (`@DateTimeFormat(pattern = "yyyy-MM-dd")`), a `@ManyToOne` `type` and the visits (`@OrderBy("date ASC")`). |
| `PetType` | `src/main/java/org/springframework/samples/petclinic/owner/PetType.java` | `NamedEntity` for table `types`. The seed data has cat, dog, lizard, snake, bird and hamster (`src/main/resources/db/h2/data.sql`). |
| `PetController` | `src/main/java/org/springframework/samples/petclinic/owner/PetController.java` | Mapped under `/owners/{ownerId}`; loads the owner, the pet and the pet types before each handler. |
| `PetValidator` | `src/main/java/org/springframework/samples/petclinic/owner/PetValidator.java` | Name, type and birth date rules. |
| `PetTypeFormatter` | `src/main/java/org/springframework/samples/petclinic/owner/PetTypeFormatter.java` | `@Component` `Formatter<PetType>` that Spring Boot registers for form binding. |
| `PetTypeRepository` | `src/main/java/org/springframework/samples/petclinic/owner/PetTypeRepository.java` | `@Query("SELECT ptype FROM PetType ptype ORDER BY ptype.name")` in `findPetTypes()`. |

## Routes

| Method and path | Handler | Result |
| --- | --- | --- |
| `GET /owners/{ownerId}/pets/new` | `initCreationForm` | `pets/createOrUpdatePetForm`, empty |
| `POST /owners/{ownerId}/pets/new` | `processCreationForm` | Redirect to `/owners/{ownerId}` with "New Pet has been Added", or the form with errors |
| `GET /owners/{ownerId}/pets/{petId}/edit` | `initUpdateForm` | `pets/createOrUpdatePetForm`, filled |
| `POST /owners/{ownerId}/pets/{petId}/edit` | `processUpdateForm` | Redirect to `/owners/{ownerId}` with "Pet details has been edited", or the form with errors |

An unknown `ownerId` throws `IllegalArgumentException` in `findOwner` and gives HTTP 500. An unknown `petId` is different: `findPet` returns `owner.getPet(petId)`, which is `null`, and the request fails later. `UntrustedInputIntegrationTests` confirms that `GET /owners/1/pets/999999/edit` returns the HTTP 500 error page; from the code, the failure comes from rendering the template with a `null` pet. A non-numeric `petId` gives HTTP 400. See [Error handling](error-handling.md).

## How it works

`PetController` follows the form pattern described in [Patterns and conventions](../how-to-contribute/patterns-and-conventions.md); [Architecture](../overview/architecture.md#request-lifecycle) has a sequence diagram of adding a pet. The parts specific to pets:

1. `populatePetTypes()` puts every pet type in the model as `types` for the drop-down list.
2. `findOwner(ownerId)` loads the owner. `findPet(ownerId, petId)` returns a new `Pet` when there is no `petId`; otherwise it loads the owner a second time and returns that owner's pet with the id.
3. `@InitBinder("pet")` sets `PetValidator` as the validator and disallows `id` and `*.id`. The hidden `id` input in the form is therefore ignored. Because `setValidator` replaces the default Bean Validation validator for `pet`, the `@NotBlank` on `NamedEntity.name` does not run here; `PetValidator` checks the name instead.
4. The handler adds the checks that need the owner or today's date, then saves with `OwnerRepository.saveAndFlush(owner)`. For a new pet it calls `owner.addPet(pet)` first. For an edit, `updatePetDetails` copies name, birth date and type onto the pet already in the owner's list.

### Validation rules

| Rule | Where | Message key and English text |
| --- | --- | --- |
| Name required (blank or whitespace fails) | `PetValidator` | `required`, "is required" |
| Name at most 30 characters (column size) | `PetValidator`, added 2026-08-11 in `676db04` | `size`, not in any bundle, so the English default "Name must be no more than 30 characters" shows in every language |
| Type required, for new pets only | `PetValidator` | `required` |
| Birth date required | `PetValidator` | `required` |
| Birth date in `yyyy-MM-dd` | `@DateTimeFormat` on `Pet.birthDate` | `typeMismatch.birthDate`, "invalid date" |
| Birth date not after today | `processCreationForm`, `processUpdateForm` (since 2023-07-07, `3be2895`) | `typeMismatch.birthDate`, also "invalid date" |
| Name unique per owner, ignoring case | Controller and database, see below | `duplicate`, "is already in use" |

A birth date of today is accepted. The future-date error reuses the "invalid date" text, so the user is not told that the date is in the future.

### Duplicate names in three places

The rule that one owner cannot have two pets with the same name was made case-insensitive and backed by the database on 2026-07-14 (`e0db9b1`, "Enforce unique pet names per owner").

| Layer | How it works | File |
| --- | --- | --- |
| Controller | On create, `owner.getPet(name, true)` looks for a saved pet with the same name using `equalsIgnoreCase`; `ignoreNew = true` skips the unsaved pet. On edit, `owner.getPet(name, false)` must return no pet or the pet being edited. Both reject `name` with code `duplicate`. | `src/main/java/org/springframework/samples/petclinic/owner/PetController.java`, `src/main/java/org/springframework/samples/petclinic/owner/Owner.java` |
| Exception mapping | If `saveAndFlush` throws `DataIntegrityViolationException` and its message, lower-cased, contains `unique_owner_pet_name`, the handler shows the same `duplicate` error. Any other integrity violation is rethrown and gives HTTP 500. This covers two requests that pass the controller check at the same time. | `PetController.isDuplicatePetNameViolation` |
| Database | A unique constraint on `(owner_id, name)`. | `src/main/resources/db/*/schema.sql` |

The database part differs between the three schemas:

| Database | Constraint | Case handling | Name in the error |
| --- | --- | --- | --- |
| H2 (default) | `ALTER TABLE pets ADD CONSTRAINT unique_owner_pet_name UNIQUE (owner_id, name)` | `pets.name` is `VARCHAR_IGNORECASE(30)`, so "Leo" and "leo" collide | `unique_owner_pet_name` |
| PostgreSQL | `CREATE UNIQUE INDEX IF NOT EXISTS unique_owner_pet_name ON pets (owner_id, LOWER(name))` | Case-insensitive through `LOWER(name)`; the column is `TEXT` with no length limit | `unique_owner_pet_name` |
| MySQL | `UNIQUE (owner_id, name)` inside `CREATE TABLE`, with no name | Depends on the column collation, which the script does not set | MySQL names an unnamed key after its first column, so the message will not contain `unique_owner_pet_name` |

On MySQL, a duplicate that gets past the controller check (two requests at once) would therefore be rethrown and give HTTP 500 instead of a form error. This follows from reading `src/main/resources/db/mysql/schema.sql` and `PetController`; no MySQL test covers it, because `src/test/java/org/springframework/samples/petclinic/MySqlIntegrationTests.java` does not add pets. On PostgreSQL, `CREATE TABLE IF NOT EXISTS` means an existing database created before July 2026 keeps its old table, but the separate `CREATE UNIQUE INDEX IF NOT EXISTS` still adds the index at the next start. If such a database already holds duplicate names, creating the index should fail at startup; this has not been tried.

### Pet types

- `PetTypeRepository.findPetTypes()` returns all types ordered by name. The controller calls it for every request to the pet routes, and `PetTypeFormatter.parse` calls it again for every bound form.
- `PetTypeFormatter.print` returns the type's name (or `<null>`). `parse` returns the type whose name equals the submitted text exactly, case included, and otherwise throws `ParseException`.
- `src/main/resources/templates/fragments/selectField.html` renders a `<select th:field="*{type}">` with one `<option>` per type. The option value and text are `${item}`, which is `NamedEntity.toString()`, the type's name, so the submitted value is the name that `parse` expects.
- An unknown type name (only possible with a hand-made request) becomes a `typeMismatch` error on `type`. No bundle has a `typeMismatch.type` or plain `typeMismatch` key, so from the code the form would show Spring's default conversion message. This is not covered by a test.

### Missing type when editing

`PetValidator` requires a type only when `pet.isNew()`. When editing:

- If the request has no `type` parameter, binding leaves the loaded pet's type in place and the edit keeps the old type.
- If `type` is sent empty, the formatter returns `null`, `updatePetDetails` sets the type to `null`, and the flush fails on `type_id INTEGER NOT NULL`. That `DataIntegrityViolationException` does not mention `unique_owner_pet_name`, so it is rethrown and the user gets HTTP 500.

Both cases come from reading the code; the drop-down list always sends a value, and no test covers either case.

### The form

`src/main/resources/templates/pets/createOrUpdatePetForm.html` shows the owner's name, then `inputField` fragments for name and birth date (an HTML `type="date"` input) and the `selectField` fragment for the type. The heading says "New Pet" for a new pet. The field labels `'Name'`, `'Birth Date'` and `'Type'` and the button texts `'Add Pet'` and `'Update Pet'` are English literals passed as fragment arguments, not message keys. `I18nPropertiesSyncTest` does not catch them because it only looks for text between HTML tags. See [Internationalization](internationalization.md).

## Integration points

- Pets are saved through the owner: `Owner.pets` is `@OneToMany(cascade = ALL, fetch = EAGER)` with `@JoinColumn(name = "owner_id")`. There is no `PetRepository`. See [Persistence](../systems/persistence.md).
- Visits hang off a pet; see [Visits](visits.md).
- Table and column details are in [Data models](../reference/data-models.md).

## Tests

| Test | What it covers |
| --- | --- |
| `src/test/java/org/springframework/samples/petclinic/owner/PetControllerTests.java` | Create and edit success, blank name, duplicate name on create and edit, same name on edit, missing type, future and malformed birth date, the `unique_owner_pet_name` mapping (with a mocked exception) |
| `src/test/java/org/springframework/samples/petclinic/owner/PetValidatorTests.java` | Each `PetValidator` rule, including a 31-character name |
| `src/test/java/org/springframework/samples/petclinic/owner/PetTypeFormatterTests.java` | `print`, `parse` and the `ParseException` for an unknown name |
| `src/test/java/org/springframework/samples/petclinic/service/ClinicServiceTests.java` | Insert and rename pets on H2; a case-insensitive duplicate for one owner throws `DataIntegrityViolationException`; the same name for two owners is allowed |
| `src/test/java/org/springframework/samples/petclinic/PetClinicConcurrencyTests.java` | Two simultaneous `POST /owners/1/pets/new` with the same name on H2: exactly one succeeds and one pet is stored |
| `src/test/java/org/springframework/samples/petclinic/UntrustedInputIntegrationTests.java` | Unknown and malformed pet ids |

## Entry points for modification

To add a pet field, add the column to all three schema.sql files under `src/main/resources/db/`, the field to `Pet`, a rule to `PetValidator` if needed, the copy in `PetController.updatePetDetails`, and an `inputField` line to the form. If you add another unique constraint, give it an explicit name in every schema and teach `isDuplicatePetNameViolation` about it. [Pitfalls](../background/pitfalls.md) collects the known traps.

## Key source files

| File | Purpose |
| --- | --- |
| `src/main/java/org/springframework/samples/petclinic/owner/PetController.java` | Add and edit handlers, duplicate and birth date checks, constraint mapping |
| `src/main/java/org/springframework/samples/petclinic/owner/PetValidator.java` | Name, type and birth date rules |
| `src/main/java/org/springframework/samples/petclinic/owner/Pet.java` | Pet entity |
| `src/main/java/org/springframework/samples/petclinic/owner/PetTypeFormatter.java` | Form conversion for pet types |
| `src/main/java/org/springframework/samples/petclinic/owner/PetTypeRepository.java` | Ordered list of pet types |
| `src/main/resources/templates/pets/createOrUpdatePetForm.html` | Add and edit form |
| `src/main/resources/templates/fragments/selectField.html` | Drop-down fragment used for the type |
| `src/main/resources/db/h2/schema.sql` | `VARCHAR_IGNORECASE` name and `unique_owner_pet_name` |

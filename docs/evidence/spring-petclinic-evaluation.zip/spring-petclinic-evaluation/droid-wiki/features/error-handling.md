# Error handling

Active contributors: Dave Syer, Moritz Halbritter, Patrick Baumgartner

PetClinic has no error handling code of its own. Exceptions go to Spring Boot's default error handling, which renders `src/main/resources/templates/error.html` for browsers and a small JSON object for other clients, and neither shows exception details. The tests added on this branch pin down which status code each kind of bad request or failure gets.

## Purpose

Users and API clients should get a controlled response for every failure: a status code that matches the problem where the code allows it, the normal page layout, and no stack traces, SQL or internal messages. The `/oups` page exists to show this behavior on purpose.

## Directory layout

```text
src/main/java/org/springframework/samples/petclinic/system/CrashController.java   GET /oups, throws on purpose
src/main/resources/templates/error.html                                         error page for browsers
src/main/resources/messages/messages*.properties                                somethingHappened, error.404, error.500, error.general
src/test/java/org/springframework/samples/petclinic/
├── system/CrashControllerTests.java
├── system/CrashControllerIntegrationTests.java
├── UntrustedInputIntegrationTests.java             added on this branch
├── DatabaseUnavailableAtStartupTests.java          added on this branch
└── PostgresOutageIntegrationTests.java             added on this branch
```

There is no `@ControllerAdvice`, `@ExceptionHandler` or `@ResponseStatus` anywhere in `src/main/java`, and `src/main/resources/application.properties` sets no `spring.web.error.*` or `server.error.*` property, so Spring Boot 4.1.2's defaults apply. On `origin/main`, 11 distinct authors have changed `src/main/java/org/springframework/samples/petclinic/system/`.

## Key abstractions

| Type | File | What it does |
| --- | --- | --- |
| `CrashController` | `src/main/java/org/springframework/samples/petclinic/system/CrashController.java` | `GET /oups` throws `RuntimeException("Expected: controller used to showcase what happens when an exception is thrown")`. The navigation bar links to it as "Error" (`src/main/resources/templates/fragments/layout.html`). |
| Error page | `src/main/resources/templates/error.html` | Thymeleaf view named `error`, inside the normal layout with the menu item `error` selected. Replaces Spring Boot's whitelabel page. |
| Spring Boot error controller | Spring Boot auto-configuration | Handles `/error` after an exception or an error status: HTML for clients that accept `text/html`, JSON for the rest. |
| `IllegalArgumentException` from loaders | `src/main/java/org/springframework/samples/petclinic/owner/OwnerController.java`, `src/main/java/org/springframework/samples/petclinic/owner/PetController.java`, `src/main/java/org/springframework/samples/petclinic/owner/VisitController.java` | The `@ModelAttribute` methods throw it when an owner id does not exist, or a pet id on the visit routes, with a message such as "Owner not found with id: ...". An unknown pet id on the pet edit route does not throw here: `PetController.findPet` returns `null` and the request fails later. |

## How it works

```mermaid
sequenceDiagram
    participant C as Browser or client
    participant D as DispatcherServlet
    participant H as Controller
    participant L as Log
    participant E as Spring Boot /error
    C->>D: GET /owners/999999
    D->>H: findOwner(999999)
    H-->>D: IllegalArgumentException
    D->>L: ERROR with the stack trace
    D->>E: forward with status 500
    alt Accept includes text/html
        E-->>C: 500, error.html in the layout
    else other Accept
        E-->>C: 500, JSON with timestamp, status, error, path
    end
```

Errors that Spring MVC maps to a status itself, such as a path variable that is not a number, take the same route without the controller and are logged differently (see [Where the details go](#where-the-details-go)).

### What the error page shows

`src/main/resources/templates/error.html` shows the pets picture, the heading `#{somethingHappened}` ("Something happened..."), and one line chosen by `th:switch="${status}"`:

| Status | Message key | English text |
| --- | --- | --- |
| 404 | `error.404` | The requested page was not found. |
| 500 | `error.500` | An internal server error occurred. |
| any other, including 400 and 503 | `error.general` | An unexpected error occurred. |

The texts are translated like every other key; see [Internationalization](internationalization.md).

The template also has `<p th:text="${message}">`, commented "Exception message (for developers)". With Spring Boot's default `spring.web.error.include-message=never`, the `message` attribute is not in the model, so this paragraph is empty in a normal run. `src/test/java/org/springframework/samples/petclinic/system/CrashControllerIntegrationTests.java` sets `spring.web.error.include-message=ALWAYS` and therefore does see the exception message on the page. Do not turn that property on in a deployment: messages such as "Owner not found with id" and conversion errors are exactly what `UntrustedInputIntegrationTests` checks stay hidden.

### The JSON error body

A client whose `Accept` header does not include `text/html` (curl's default `*/*`, or `application/json`) gets Spring Boot's JSON error body, for example `{"timestamp": ..., "status": 500, "error": "Internal Server Error", "path": "/owners/999999"}`. The defaults that shape it are `include-message=never`, `include-stacktrace=never`, `include-exception=false` and `include-path=always`, and RFC 9457 problem details are off (`spring.mvc.problemdetails.enabled=false`). `UntrustedInputIntegrationTests.jsonErrorResponseOmitsMessageAndStackTrace` checks that the body has `status` 500 and no `message`, `trace` or `exception` keys.

## Status codes

| Situation | Example | Status | Response | Source and test |
| --- | --- | --- | --- | --- |
| The crash demo | `/oups` | 500 | Error page with "An internal server error occurred." | `CrashController`; `CrashControllerTests`, `CrashControllerIntegrationTests` |
| Malformed number in a path or in `page` | `/owners/abc`, `/owners/2147483648`, `/owners/1/pets/abc/edit`, `/owners?page=abc`, `/vets.html?page=2147483648` | 400 | Error page with "An unexpected error occurred." | Spring MVC type conversion to `int`; `UntrustedInputIntegrationTests.malformedNumberIsRejectedAsBadRequest` |
| Page number out of range | `/owners?page=0`, `/vets.html?page=2147483647` | 302 to page 1 | Not an error | `OwnerController`, `VetController`; `UntrustedInputIntegrationTests.outOfRangePageNumberRedirectsToTheFirstPage` |
| Unknown path | `/does-not-exist` | 404 | Error page with "The requested page was not found." | Spring Boot defaults; QA flow W8 in `.factory/skills/qa-web/SKILL.md`. No automated test. |
| Unknown owner or pet id | `/owners/999999`, `/owners/999999/edit`, `/owners/1/pets/999999/edit`, `/owners/1/pets/999999/visits/new` | 500 | Error page without details. Should be 404 (known issue F3). | `IllegalArgumentException` in the loaders, or a `null` pet on the pet edit route; `UntrustedInputIntegrationTests.unknownIdRendersTheErrorPageWithoutInternalDetails` |
| `/vets` with an `Accept` type it cannot produce | `Accept: text/csv` | 406 | Empty body | Spring MVC content negotiation; QA flow A1 in `.factory/skills/qa-api/SKILL.md`. No automated test. |
| Database stops while the application runs | `/owners/1` during an outage | 500 | Error page without `jdbc:`, `SQLException`, `HikariPool` or stack lines. `/vets` still 200 from the cache. `/actuator/health` 503; `/livez` and `/readyz` 200. | `PostgresOutageIntegrationTests` (needs Docker) |
| Database unreachable at startup | `mysql` or `postgres` profile, nothing listening | No response | The application does not start: startup fails with a `ConnectException` root cause within 20 seconds and the process exits. | `DatabaseUnavailableAtStartupTests` |
| Invalid form input | Blank name, 9-digit telephone | 200 | The form again, with a message under each field | See [Patterns and conventions](../how-to-contribute/patterns-and-conventions.md) |

For F3, `docs/RUNBOOK.md` links the open upstream fix [spring-projects/spring-petclinic#2688](https://github.com/spring-projects/spring-petclinic/pull/2688), which throws `ResponseStatusException(NOT_FOUND)` instead. The comment above the unknown-id test in `src/test/java/org/springframework/samples/petclinic/UntrustedInputIntegrationTests.java` says the 500 is tracked in `docs/RUNBOOK.md` and that the test only makes sure users still get the error page without internal details. [Pitfalls](../background/pitfalls.md) lists F3 with the other open issues, and the operator view of these cases is the [failure behavior table in the runbook](../../docs/RUNBOOK.md#failure-behavior).

### Owner form error flashes

`OwnerController.processCreationForm` and `processUpdateOwnerForm` add a flash attribute `error` ("There was an error in creating the owner.", "There was an error in updating the owner.") when validation fails, but then return the form view instead of redirecting. Flash attributes travel only with a redirect, and the owner form template does not render `${error}`; only `src/main/resources/templates/owners/ownerDetails.html` does. As far as the code shows, these two messages are never displayed. The id-mismatch branch does redirect, but to the edit form, which also does not render `${error}`. This was read from the code and not tested.

## Where the details go

The details hidden from users are in the application log, which goes to standard output ([runbook, health checks](../../docs/RUNBOOK.md#health-checks)):

- **Unhandled exceptions** (500), such as `/oups` or an unknown id, are logged at `ERROR` by Tomcat (logger `o.a.c.c.C.[.[.[/].[dispatcherServlet]`): "Servlet.service() for servlet [dispatcherServlet] ... threw exception", followed by the full stack trace. The local QA run's `qa-results/1794576862/app.log` has this entry for `/oups`.
- **Errors Spring MVC resolves itself** (400, 406) are logged at `WARN` by `DefaultHandlerExceptionResolver` as one line without a stack trace, for example `Resolved [...MethodArgumentTypeMismatchException: Method parameter 'page': Failed to convert value ...]` or `Resolved [...HttpMediaTypeNotAcceptableException: No acceptable representation]`.

The application code has no loggers of its own. [How to monitor](../how-to-monitor.md) covers logs, health and metrics, and [Debugging](../how-to-contribute/debugging.md) covers troubleshooting.

## Failure-scenario tests on this branch

Commit `23d0c67` (2026-11-13) added these three test classes together with the version guard `PatchedDependencyVersionsTests`, and `3a5a0bc` extended `UntrustedInputIntegrationTests` with the large page numbers that used to return 500.

| Test | What it does | Runs without Docker |
| --- | --- | --- |
| `src/test/java/org/springframework/samples/petclinic/UntrustedInputIntegrationTests.java` | Full application on a random port with H2. Sends out-of-range pages (expects a 302 to page 1, keeping `lastName`), malformed numbers (expects 400), unknown ids (expects 500) and a JSON request (expects no `message`, `trace` or `exception`). Every HTML body must contain "Something happened..." and none of `Exception:`, `Caused by`, a stack line, `java.lang.`, `Failed to convert`, `not found with id` or `jdbc:`. 21 test invocations. | Yes |
| `src/test/java/org/springframework/samples/petclinic/DatabaseUnavailableAtStartupTests.java` | Starts the application with the `mysql` and then the `postgres` profile against a port where nothing listens. Expects startup to fail with a `ConnectException` root cause in under 20 seconds, well below HikariCP's 30-second connection timeout. Excludes `MysqlTestApplication`, which would otherwise swap in a Testcontainers database (F10). | Yes |
| `src/test/java/org/springframework/samples/petclinic/PostgresOutageIntegrationTests.java` | Runs against a `postgres:18.4` Testcontainer on a fixed host port, stops the container, checks the responses listed in the status table, starts it again and waits up to 60 seconds for `/actuator/health` to return 200 and `/owners/1` to work, without restarting the application. | No, skipped without Docker |

The older tests are `src/test/java/org/springframework/samples/petclinic/system/CrashControllerTests.java` (a plain unit test that the method throws) and `src/test/java/org/springframework/samples/petclinic/system/CrashControllerIntegrationTests.java` (a JSON request gets `timestamp`, `status`, `error`, `message` and `path`; an HTML request gets the error page and not the whitelabel page; both with `include-message=ALWAYS` and without a database). [Testing](../how-to-contribute/testing.md) covers the test layers.

## Integration points

- **Security:** hiding exception details is part of the input-handling story in [Security](../security.md). Actuator, which is fully exposed (F1), is a separate concern.
- **Health checks:** the database outage turns `/actuator/health` to 503, while readiness stays 200 (F2); see [How to monitor](../how-to-monitor.md).
- **Caching:** `/vets` survives an outage only because of the `vets` cache; see [Vets](vets.md) and [Caching](../systems/caching.md).

## Entry points for modification

To return 404 for unknown ids (F3), change the `orElseThrow` calls in the three owner controllers to throw `ResponseStatusException(HttpStatus.NOT_FOUND)`, then update `UntrustedInputIntegrationTests.unknownIdRendersTheErrorPageWithoutInternalDetails` and the F3 row in `docs/RUNBOOK.md`. To change what the error page says, edit `src/main/resources/templates/error.html` and add any new keys to every message bundle. To show a message for another status, add a `th:case` and a key such as `error.400`.

## Key source files

| File | Purpose |
| --- | --- |
| `src/main/java/org/springframework/samples/petclinic/system/CrashController.java` | `/oups`, throws a `RuntimeException` on purpose |
| `src/main/resources/templates/error.html` | Error page: heading, status-specific line, empty message paragraph by default |
| `src/main/resources/application.properties` | No error settings, so Spring Boot's defaults apply |
| `src/main/java/org/springframework/samples/petclinic/owner/OwnerController.java` | Owner loader that throws `IllegalArgumentException` for unknown ids |
| `src/test/java/org/springframework/samples/petclinic/UntrustedInputIntegrationTests.java` | Status codes and hidden details for bad input |
| `src/test/java/org/springframework/samples/petclinic/PostgresOutageIntegrationTests.java` | Behavior during and after a database outage |
| `src/test/java/org/springframework/samples/petclinic/DatabaseUnavailableAtStartupTests.java` | Fail-fast startup without a database |
| `docs/RUNBOOK.md` | Failure behavior table and follow-up F3 |

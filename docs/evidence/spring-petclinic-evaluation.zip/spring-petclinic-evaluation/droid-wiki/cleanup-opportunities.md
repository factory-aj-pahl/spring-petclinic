# Cleanup opportunities

Maintenance work that removes, refactors or updates code in this repository, with the evidence for each item and a rough size. Behavior that surprises people is covered in [Pitfalls](background/pitfalls.md); open follow-ups that need an owner decision are in `docs/RUNBOOK.md`. Checked on 2026-11-13 at commit 2aff817 with `rg`, `git grep`, `git log` and `wc`.

Sizes: small means under an hour and one file or two, medium means a few files plus tests, large means a design change or a migration.

## Dead ends

| Item | Evidence | Suggested change | Size |
| --- | --- | --- | --- |
| Message keys `nonNumeric` and `duplicateFormSubmission` | Defined in `src/main/resources/messages/messages.properties` lines 5-6 and in nine translations. `rg` finds no use in `src/main/java`, `src/main/resources/templates` or `src/test`. They date from the 2013 import (`09c92b3`). | Delete both keys from all bundles. `I18nPropertiesSyncTest` only checks that translations have the default keys, so removing them everywhere keeps it green. | Small |
| `JCacheManagerCustomizer` in `src/main/java/org/springframework/samples/petclinic/system/CacheConfiguration.java` | No JCache provider is on the classpath, so Spring Boot uses Caffeine directly and the customizer never runs (F12). The `javax.cache:cache-api` dependency in `pom.xml` and `build.gradle` exists only for this class (`rg javax.cache` finds no other use). | Replace the bean with `spring.cache.caffeine.spec` (statistics and a size limit, which also closes the remaining F15 note), keep `@EnableCaching`, then drop `cache-api` from both builds. See [Caching](systems/caching.md). | Small |
| Id-mismatch branch in `OwnerController.processUpdateOwnerForm` | `src/main/java/org/springframework/samples/petclinic/owner/OwnerController.java` lines 163-167. The owner comes from `findById(ownerId)` and `id` binding is disallowed, so the ids always match in a real request. Only `OwnerControllerTests.processUpdateOwnerFormWithIdMismatch` reaches it, by mocking `findById` to return an owner with another id (F20). | Remove the branch and the test, together with the `mismatch` error code, which has no message key (F19). | Small |
| `error` flash attributes | `src/main/java/org/springframework/samples/petclinic/owner/OwnerController.java` lines 80 and 159 add an `error` flash attribute and then render the form instead of redirecting, so it is dropped. `src/main/resources/templates/owners/createOrUpdateOwnerForm.html` has no `error` output. The only template that renders `error`, `src/main/resources/templates/owners/ownerDetails.html` lines 13-15, never receives one: no handler redirects to `/owners/{id}` with an `error` flash (F20). | Delete the three `addFlashAttribute("error", ...)` calls and the `error-message` block, and make the script in `src/main/resources/templates/owners/ownerDetails.html` skip missing elements. | Small |
| `${message}` paragraph in `src/main/resources/templates/error.html` | Line 18 is commented "for developers", but `spring.web.error.include-message` is not set in `src/main/resources`, so the default `never` applies and the paragraph is empty. Only `src/test/java/org/springframework/samples/petclinic/system/CrashControllerIntegrationTests.java` turns messages on. | Remove the paragraph, or render it only when `${message}` is not empty. Check `CrashControllerIntegrationTests` first. | Small |
| Legacy font formats under `src/main/resources/static/resources/fonts/` | All 13 image and font files are referenced: images by `src/main/resources/templates/fragments/layout.html`, `src/main/resources/templates/welcome.html`, `src/main/resources/templates/error.html` or the SCSS; fonts by `src/main/scss/typography.scss`. The `.eot` and `.svg` font files are only for very old browsers (inferred, not tested in a browser). | Optional: keep `.woff` (or add `.woff2`) and drop `.eot`, `.svg` and probably `.ttf`, then recompile the CSS with the `css` profile. | Small |

`src/main/java/org/springframework/samples/petclinic/system/CrashController.java` (`/oups`) is intentional, not dead: it demonstrates the error page and is linked from the navigation bar.

## TODO, FIXME and HACK comments

`git grep -nIE "TODO|FIXME|HACK|XXX"` over the tracked files (excluding `droid-wiki/`) returns no matches, so there is nothing to date with `git blame`. [Fun facts](fun-facts.md) has the history of the last TODO.

## Complexity hotspots

The code is small, so these are the files a change is most likely to touch, not files that need splitting.

| Group | Largest files (lines, `wc -l` at HEAD) |
| --- | --- |
| Java main | `src/main/java/org/springframework/samples/petclinic/owner/PetController.java` (207), `src/main/java/org/springframework/samples/petclinic/owner/OwnerController.java` (190), `src/main/java/org/springframework/samples/petclinic/owner/Owner.java` (188) |
| Java test | `src/test/java/org/springframework/samples/petclinic/owner/OwnerControllerTests.java` (330), `src/test/java/org/springframework/samples/petclinic/service/ClinicServiceTests.java` (315), `src/test/java/org/springframework/samples/petclinic/owner/PetControllerTests.java` (274) |
| Templates | `src/main/resources/templates/owners/ownerDetails.html` (95), `src/main/resources/templates/fragments/layout.html` (87), `src/main/resources/templates/owners/ownersList.html` (60) |
| SQL | `src/main/resources/db/h2/schema.sql` (65), `src/main/resources/db/mysql/schema.sql` (56), `src/main/resources/db/postgres/schema.sql` (53) |

Churn on `origin/main` from 2025-09-29 to 2026-09-29 (62 commits by commit date, `git log origin/main --since=2025-09-29 --until=2026-09-30 --name-only`, each file counted once per commit):

| File | Commits |
| --- | --- |
| `pom.xml` | 16 |
| `build.gradle` | 15 |
| `README.md` | 14 |
| `src/main/java/org/springframework/samples/petclinic/owner/OwnerController.java` | 6 |
| `src/test/java/org/springframework/samples/petclinic/owner/PetControllerTests.java` | 6 |
| `src/test/java/org/springframework/samples/petclinic/PetClinicIntegrationTests.java` | 6 |
| `src/test/java/org/springframework/samples/petclinic/MySqlIntegrationTests.java` | 6 |
| `gradle/wrapper/gradle-wrapper.properties` | 6 |
| `src/main/java/org/springframework/samples/petclinic/owner/PetController.java` | 5 |
| `src/main/java/org/springframework/samples/petclinic/owner/Owner.java` | 5 |

`src/main/java/org/springframework/samples/petclinic/owner/OwnerController.java` is both large and frequently changed, and it holds most of the F20 dead code above. Removing that code is the cheapest way to make it smaller. [By the numbers](by-the-numbers.md) has longer time ranges.

## Duplication and drift

| Item | Evidence | Suggested change | Size |
| --- | --- | --- | --- |
| Maven versus Gradle (F11) | `build.gradle` puts Actuator in `runtimeOnly` (Maven: compile). Maven has test starters that Gradle lacks: `spring-boot-starter-restclient`, `-thymeleaf-test`, `-validation-test`, `-actuator-test` and `-cache-test` (`pom.xml`). Gradle has no JaCoCo, no git-commit-id and no build-info setup. | Align the dependency lists and add `springBoot { buildInfo() }`, a git properties plugin and JaCoCo to `build.gradle`. See [Tooling](how-to-contribute/tooling.md). | Medium |
| Schema differences | `vet_specialties` has no primary key in any of `src/main/resources/db/{h2,mysql,postgres}/schema.sql`. PostgreSQL uses `TEXT` without length limits. MySQL's `UNIQUE (owner_id, name)` (line 47) has no name, while H2 and PostgreSQL call it `unique_owner_pet_name` (F17). | Add `PRIMARY KEY (vet_id, specialty_id)`; name the MySQL constraint; decide whether PostgreSQL should get `VARCHAR` sizes. Existing databases need a migration, and the scripts run at every start. See [Persistence](systems/persistence.md). | Medium |
| Development environments | `.devcontainer/devcontainer.json` installs Java `21-oracle`. `.devcontainer/Dockerfile` (comment: used by Gitpod, not the dev container) installs Java 17.0.7 on `java:0-17-bullseye`, and `.gitpod.yml` uses it. The build targets 17 (`pom.xml` `java.version`). | Set the dev container to 17 to match CI, and update or remove the Gitpod image if nobody uses it (not verified). | Small |
| Overlapping vet tests | In `src/test/java/org/springframework/samples/petclinic/vet/VetControllerTests.java`, `showVetListRedirectsOutOfBoundsPageToFirstPage` checks pages 0 and 2; `showVetListRedirectsOutOfRangePagesWithoutQueryingThem` checks 0, 2 and two large pages with the same assertions plus a `verify`. | Delete the first test. | Small |
| Missing license headers | `src/test/java/org/springframework/samples/petclinic/PetClinicConcurrencyTests.java`, `src/test/java/org/springframework/samples/petclinic/system/I18nPropertiesSyncTest.java` and `src/main/java/org/springframework/samples/petclinic/system/WebConfiguration.java` start with `package`; the other Java files have the Apache 2.0 header. | Add the header. | Small |
| Translation cleanup (F19) | Literal labels passed as fragment arguments in `src/main/resources/templates/pets/createOrUpdatePetForm.html` lines 20-26 and `src/main/resources/templates/pets/createOrUpdateVisitForm.html` lines 32-33. Error codes `size` (`src/main/java/org/springframework/samples/petclinic/owner/PetValidator.java` line 47) and `mismatch` have no keys. `src/main/resources/messages/messages_de.properties` lines 7-8 contain U+FFFD. | Pass `#{...}` keys, add a `size` key, fix the German text, and extend `I18nPropertiesSyncTest`. See [Internationalization](features/internationalization.md). | Medium |

## Dependency freshness

[Dependencies](reference/dependencies.md) and `docs/DEPENDENCIES.md` list every version. Items that Spring Boot does not manage:

| Item | Where | Note | Size |
| --- | --- | --- | --- |
| Font Awesome 4.7.0 | `pom.xml` property `webjars-font-awesome.version`, `build.gradle` | Unmaintained since 2016 (F14). A move to a newer major changes icon class names in the templates. | Medium |
| LibSass through libsass-maven-plugin 0.3.4 | `css` profile in `pom.xml` | LibSass is deprecated (F14). Replacing it means a Dart Sass based build step. | Medium |
| `dsyer/petclinic` with no tag | `k8s/petclinic.yml` line 33 | Unknown provenance (F4). Build the image in CI and deploy by tag or digest. | Large |
| GitHub Actions | `.github/workflows/*.yml` | `actions/checkout`, `setup-java`, `setup-node`, `upload-artifact`, `download-artifact` and `gradle/actions/setup-gradle` at `@v4`, `helm/kind-action@v1`, OSV-Scanner at `v2.7.1`. Only `peter-evans/create-pull-request` is pinned to a commit. Check for newer releases, and consider commit pinning. | Small |
| Other pinned versions | `pom.xml` properties: `webjars-locator.version` 1.1.3, `webjars-bootstrap.version` 5.3.8, `checkstyle.version` 12.3.1, `jacoco.version` 0.8.15, `maven-checkstyle.version` 3.6.0, `nohttp-checkstyle.version` 0.0.11, `spring-format.version` 0.0.47, `lifecycle-mapping` 1.0.0. `build.gradle` plugins: dependency-management 1.1.7, GraalVM native 1.1.2, CycloneDX 3.2.4. | Check for newer releases. Checkstyle must stay on 12 while the build supports Java 17 (comment in `pom.xml`). Keep both build files in step (`AGENTS.md`). | Small |

`.github/dependabot.yml` now opens weekly update pull requests for Maven, Gradle and GitHub Actions, so most version bumps arrive on their own. Font Awesome and LibSass will not, because they need code changes.

## Priorities

1. Remove the F20 dead code in `src/main/java/org/springframework/samples/petclinic/owner/OwnerController.java` and `src/main/resources/templates/owners/ownerDetails.html` (small, removes a script error too).
2. Replace the JCache customizer with a Caffeine spec that sets a size limit, and drop `cache-api` (small; F12 and the open F15 note).
3. Align `build.gradle` with `pom.xml` (medium; F11).
4. Fix the translation gaps and delete the unused message keys (medium; F19).
5. Name the MySQL pet-name constraint and add the `vet_specialties` primary key (medium; F17, needs a migration plan).

Items that need an owner decision, such as the front-end refresh (F14) and the Kubernetes image (F4), are tracked in the follow-ups table in `docs/RUNBOOK.md`.

2026-11-13T17:09:19Z
<!-- qa-report -->
## QA Report

| #   | Test Case | App | Persona | Result | Notes |
| --- | --------- | --- | ------- | ------ | ----- |
| 1 | Owner list with huge page numbers (`999999999`, `2147483647`, `429496731`) | web | visitor | :white_check_mark: PASS | Each lands on `/owners?page=1` with the list, no error page (these returned HTTP 500 before the cap) |
| 2 | Owner paging at the new cap (`429496729`, `429496730`, `429496731`, `2147483647`), with and without `lastName=Franklin` | web | visitor | :white_check_mark: PASS | All 302 to page 1; the `lastName` filter is kept. `page=2147483648` (not an int) gives 400, not 500 |
| 3 | Owner list paging and ordinary bounds (pager, `page=3/0/-1`, `lastName=Davis&page=9`, `page=abc`) | web | visitor | :white_check_mark: PASS | 5 owners per page; out-of-range pages go to page 1; Davis filter kept; `abc` shows the error page with HTTP 400 |
| 4 | Owner paging after a new owner is saved (11 owners) | web | visitor | :white_check_mark: PASS | Page 3 now lists `Qa Qa1794589205`; `page=4` and `page=2147483647` go to page 1 |
| 5 | Vets list and pager | web | visitor | :white_check_mark: PASS | Page 1: Carter to Stevens with specialties ("none" for Carter); page 2: Sharon Jenkins |
| 6 | Vets out-of-range pages (`3`, `0`, `-1`, `999999999`, `2147483647`, `abc`) | web | visitor | :white_check_mark: PASS | Each lands on `/vets.html?page=1`; `abc` gives the error page with HTTP 400 |
| 7 | Out-of-range vets pages do not fill the `vets` cache (1005 requests) | web | visitor | :white_check_mark: PASS | All 1005 got 302 to page 1; live `PageImpl` objects in the heap stayed at 2 (pages 1 and 2) before and after |
| 8 | Runtime SBOM shows the Spring Boot 4.1.2 stack and patched library minimums | api | visitor | :white_check_mark: PASS | `spring-boot 4.1.2`, `tomcat-embed-core 11.0.27`, `spring-webmvc 7.0.10`, `jackson-* 3.1.7`, `postgresql 42.7.14`, `log4j-api 2.25.5`; unknown SBOM id gives 404 |
| 9 | Vets as JSON and XML; unsupported `Accept` | api | visitor | :white_check_mark: PASS | JSON and XML both 200 with 6 vets; `text/csv` gives 406 |
| 10 | Health, liveness, readiness, info; shutdown blocked | api | visitor | :white_check_mark: PASS | All UP; info shows `spring-petclinic 4.0.0-SNAPSHOT`, commit `bd62ed3` (HEAD); `POST /actuator/shutdown` gives 404 |
| 11 | Home page and navigation bar | web | visitor | :white_check_mark: PASS | Styled dark nav bar with 4 links, pets picture loaded, the active item follows the page |
| 12 | Find owners (Davis, davis, Franklin, unknown, empty) | web | visitor | :white_check_mark: PASS | 2 Davis owners either case; Franklin opens `/owners/1`; unknown shows "has not been found"; empty lists page 1 of 2 |
| 13 | Add and edit an owner, with validation | web | visitor | :white_check_mark: PASS | "New Owner Created" (`/owners/11`), "Owner Values Updated" (city Monona); bad phone, blank fields and too-long fields show their messages and save nothing |
| 14 | Add and edit a pet, with validation | web | visitor | :white_check_mark: PASS | "New Pet has been Added", "Pet details has been edited"; duplicate name, future date, 31-char name and missing type (curl, HTTP 200) all rejected |
| 15 | Book a visit, with validation | web | visitor | :white_check_mark: PASS | "Your visit has been booked" for tomorrow; blank and 256-char descriptions rejected; today's date is blocked by the browser, and the server also rejects it (curl) |
| 16 | Error pages (`/oups`, unknown URL) | web | visitor | :white_check_mark: PASS | PetClinic error page in the normal layout: 500 "An internal server error occurred." and 404 "The requested page was not found." |
| 17 | Language switch (`de`, kept in session, `en`, `xx`) | web | visitor | :white_check_mark: PASS | "Willkommen", "Startseite", "Besitzer suchen"; German kept on Tierärzte and Besitzer suchen; back to English; `xx` shows English |

Result values: :white_check_mark: PASS, :x: FAIL, :no_entry: BLOCKED, :warning: FLAKY, :grey_question: INCONCLUSIVE

### Action Required

- The `droid-control@factory-plugins` plugin is enabled in `.factory/settings.json`, but the runner did not have it installed (`droid plugin list` showed no plugins). This run added the marketplace and installed the plugin at user scope so the web flows could run. A runner without that step fails the qa-web pre-flight check.
- The runner had `agent-browser 0.37.1`, but `.github/workflows/qa.yml` pins `0.43.0`. Results here came from 0.37.1.

## Suggested Skill Updates (2 issues found)

| #   | Severity        | File     | Issue               | Fix Prompt                                                                           |
| --- | --------------- | -------- | ------------------- | ------------------------------------------------------------------------------------ |
| 1 | 🟡 Degraded | `.factory/skills/qa/SKILL.md` | Pre-flight only checks that `droid-control` is active; a runner without it blocks every web flow, and the skill gives no install command | <details><summary>Copy</summary><br>`In .factory/skills/qa/SKILL.md, section "Step 4: Pre-flight Checks", item 7: add that when droid plugin list does not show droid-control@factory-plugins, run "droid plugin marketplace add Factory-AI/factory-plugins" and then "droid plugin install droid-control@factory-plugins --scope user", and check droid plugin list again before reporting qa-web as BLOCKED.`</details> |
| 2 | 🔵 Info | `.factory/skills/qa-web/SKILL.md` | The first page that creates a session (for example `/?lang=de`) rewrites every link to `...;jsessionid=...`, so exact-href selectors such as `a[href='/vets.html']` fail with "Element not found". The date-input `fill` problem also occurs with agent-browser 0.37.1, not only 0.43 | <details><summary>Copy</summary><br>`In .factory/skills/qa-web/SKILL.md, section "Known Failure Modes": extend item 4 to say that on the first response of a new session (for example /?lang=de) every link href also carries ";jsessionid=...", so select links with prefix matches such as a.nav-link[href^='/vets.html'] instead of exact href matches. Extend item 5 to say the same date-input fill problem was seen with agent-browser 0.37.1.`</details> |

<details>
<summary>Screenshots & Evidence</summary>

Run ID `1794589205`. The server was built from this checkout (commit `bd62ed3`) and started on port 8080 with the default H2 database. Screenshots, GIFs, raw JSON evidence, `snapshots.txt` and `app.log` are in the downloadable artifacts under `qa-results/1794589205/`.

**1, 2: Owner paging at the cap and huge page numbers** (curl, without following redirects)
```
$ for p in 2 3 429496729 429496730 429496731 999999999 2147483647; do curl -sS -o /dev/null -w "page=$p HTTP %{http_code} -> %{redirect_url}\n" "http://localhost:8080/owners?page=$p"; done
page=2 HTTP 200 ->
page=3 HTTP 302 -> http://localhost:8080/owners?page=1
page=429496729 HTTP 302 -> http://localhost:8080/owners?page=1
page=429496730 HTTP 302 -> http://localhost:8080/owners?page=1
page=429496731 HTTP 302 -> http://localhost:8080/owners?page=1
page=999999999 HTTP 302 -> http://localhost:8080/owners?page=1
page=2147483647 HTTP 302 -> http://localhost:8080/owners?page=1
lastName=Franklin page=429496730 HTTP 302 -> http://localhost:8080/owners?page=1&lastName=Franklin
lastName=Franklin page=429496731 HTTP 302 -> http://localhost:8080/owners?page=1&lastName=Franklin
lastName=Franklin page=2147483647 HTTP 302 -> http://localhost:8080/owners?page=1&lastName=Franklin
page=2147483648 HTTP 400
```
Browser, `/owners?page=2147483647` (accessibility tree, trimmed). It shows page 1 of the list, not an error page. Screenshot: `W3-owners-page-2147483647.png`.
```
URL: http://localhost:8080/owners?page=1
- heading "Owners" [level=2]
- row: cell "George Franklin" | "110 W. Liberty St." | "Madison" | "6085551023" | "Leo"
- row: cell "Betty Davis" ... (5 rows)
- generic (pager): link "2", link "3", next, last
```

**3: Owner paging and ordinary bounds** (browser address after each step)
```
/owners?page=1            -> 5 owners, pager "pages [ 1 2 ]", links to /owners?page=2
click pager "2"           -> /owners?page=2: Jean Coleman, Jeff Black, Maria Escobito, David Schroeder, Carlos Estaban
/owners?page=3, =0, =-1   -> /owners?page=1 (George Franklin ... Peter McTavish)
/owners?lastName=Davis&page=9 -> /owners?page=1&lastName=Davis: Betty Davis, Harold Davis
/owners?page=abc          -> h2 "Something happened...", "An unexpected error occurred." (curl: HTTP 400)
```

**4: Owner paging after adding owner 11** (accessibility tree, trimmed). Screenshot: `X3-owners-page3-after-add.png`.
```
URL: http://localhost:8080/owners?page=3
- heading "Owners"
- row: cell "Qa Qa1794589205" | "1 Main St" | "Monona" | "6085550000" | "Max1794589205"
- generic (pager): link "1", link "2", first, previous
open /owners?page=4  -> URL: http://localhost:8080/owners?page=1 (pager links "2", "3")
```

**5, 6: Vets list, pager and out-of-range pages.** Screenshots: `W7-vets-page1.png`, `W7-vets-page2.png`, `W7-diff.gif`, `W7-vets-page-999999999.png`.
```
/vets.html          -> James Carter none | Helen Leary radiology | Linda Douglas dentistry surgery | Rafael Ortega surgery | Henry Stevens radiology; pager "pages [ 1 2 ]"
click pager "2"     -> /vets.html?page=2: Sharon Jenkins none
/vets.html?page=3, =0, =-1, =999999999, =2147483647 -> /vets.html?page=1 (same 5 vets)
/vets.html?page=abc -> error page "An unexpected error occurred." (curl: HTTP 400)
```
```
URL: http://localhost:8080/vets.html?page=1      (opened /vets.html?page=999999999)
- heading "Veterinarians"
- row: "James Carter" "none" / "Helen Leary" "radiology" / "Linda Douglas" "dentistry surgery" / "Rafael Ortega" "surgery" / "Henry Stevens" "radiology"
```

**7: The `vets` cache is not filled by out-of-range pages.** The `vets` cache is Caffeine `UnboundedLocalManualCache` (`/actuator/caches`). `jcmd GC.class_histogram` counts live objects after a full GC.
```
# after GET /vets.html?page=1 and ?page=2 (both 200)
org.springframework.data.domain.PageImpl            2
org.springframework.cache.interceptor.SimpleKey     1
# GET /vets.html?page=3..1002 plus 429496731, 999999999, 2147483647, 0, -5
   1005 302      (redirect target: http://localhost:8080/vets.html?page=1)
# after
org.springframework.data.domain.PageImpl            2
org.springframework.cache.interceptor.SimpleKey     1
/actuator/health -> {"groups":["liveness","readiness"],"status":"UP"}
```

**8: Runtime SBOM**
```
$ curl -sS -o /tmp/sbom.json -w 'HTTP %{http_code} %{content_type}\n' http://localhost:8080/actuator/sbom/application
HTTP 200 application/vnd.cyclonedx+json
{"bomFormat":"CycloneDX","specVersion":"1.6","components":107}
$ jq -r '.components[] | select(.name | test("^(tomcat-embed-core|spring-webmvc|jackson-databind|jackson-core|postgresql|log4j-api|spring-boot|spring-core)$")) | "\(.group):\(.name) \(.version)"' /tmp/sbom.json
org.apache.logging.log4j:log4j-api 2.25.5           (min 2.25.5)
org.apache.tomcat.embed:tomcat-embed-core 11.0.27   (min 11.0.25)
org.postgresql:postgresql 42.7.14                   (min 42.7.12)
org.springframework.boot:spring-boot 4.1.2          (pom.xml parent 4.1.2)
org.springframework:spring-core 7.0.10
org.springframework:spring-webmvc 7.0.10            (min 7.0.9)
tools.jackson.core:jackson-core 3.1.7               (min 3.1.7)
tools.jackson.core:jackson-databind 3.1.7           (min 3.1.7)
$ curl http://localhost:8080/actuator/sbom          -> {"ids":["application"]} HTTP 200
$ curl http://localhost:8080/actuator/sbom/does-not-exist -> 404
```
The minimums match the `@CsvSource` in `PatchedDependencyVersionsTests.java`.

**9: Vets JSON and XML**
```
$ curl -sS -w '\nHTTP %{http_code} %{content_type}\n' -H 'Accept: application/json' http://localhost:8080/vets
...{"firstName":"Sharon","id":6,"lastName":"Jenkins","new":false,"nrOfSpecialties":0,"specialties":[]}]}
HTTP 200 application/json
vetList: 6; keys [firstName,id,lastName,new,nrOfSpecialties,specialties]; Carter specialties []; Leary [radiology]
$ curl -sS -H 'Accept: application/xml' http://localhost:8080/vets
<?xml version="1.0" encoding="UTF-8" standalone="yes"?><vets><vetList><id>1</id><firstName>James</firstName>...
HTTP 200 application/xml   (6 <vetList> elements)
$ curl -sS -o /dev/null -w '%{http_code}' -H 'Accept: text/csv' http://localhost:8080/vets
406
```

**10: Health and info**
```
/actuator/health            -> {"groups":["liveness","readiness"],"status":"UP"} HTTP 200
/actuator/health/liveness   -> {"status":"UP"} HTTP 200
/actuator/health/readiness  -> {"status":"UP"} HTTP 200
/actuator/info -> {"git":{"branch":"security/spring-boot-4.1.2-cve-remediation","commit":{"id":"bd62ed3",...}},"build":{"version":"4.0.0-SNAPSHOT","artifact":"spring-petclinic",...}}
git rev-parse HEAD -> bd62ed311d26dc733e6b62d8c12ee35078ab10da
POST /actuator/shutdown -> 404
```

**11: Home and navigation.** Screenshot: `W1-home.png`.
```
/ -> h2 "Welcome", active "HOME"; nav background rgb(52, 48, 45); links HOME, FIND OWNERS, VETERINARIANS, ERROR
images: pets.png (loaded, 239px wide), spring-logo.svg; stylesheets font-awesome.min.css, petclinic.css
click FIND OWNERS -> /owners/find, h2 "Find Owners", active "FIND OWNERS"
click VETERINARIANS -> /vets.html, h2 "Veterinarians", active "VETERINARIANS"
click HOME -> /, h2 "Welcome", active "HOME"
```

**12: Find owners.** Screenshot: `W2-not-found.png`.
```
"Davis"  -> /owners?lastName=Davis: Betty Davis, Harold Davis
"davis"  -> /owners?lastName=davis: Betty Davis, Harold Davis
"Franklin" -> /owners/1: George Franklin, pet Leo (cat)
"Zzqa1794589205" -> /owners?lastName=Zzqa1794589205, Find Owners form, help "has not been found"
""       -> /owners?lastName=: 5 owners, page 1 of 2
```

**13: Owner add and edit.** Screenshots: `W4-owner-created.png`, `W4-owner-updated.png`, `W4-diff.gif`, `W4-owner-empty.png`.
```
add Qa / Qa1794589205 / 1 Main St / Madison / 6085550000 -> /owners/11, #success-message "New Owner Created"
edit city Monona -> /owners/11, "Owner Values Updated", City Monona
telephone 12345  -> /owners/new, "Telephone: Telephone must be a 10-digit number"
all empty        -> First Name/Last Name/Address/City: must not be blank; Telephone: Telephone must be a 10-digit number, must not be blank
31/256/81 chars  -> First Name: size must be between 0 and 30; Address: size must be between 0 and 255; City: size must be between 0 and 80
search QaTel1794589205 and QaLong1794589205 -> "has not been found" (not saved)
```

**14: Pet add and edit.** Screenshots: `W5-pet-added.png`, `W5-pet-future-date.png`.
```
Rex1794589205, 2020-05-01, dog -> /owners/11, "New Pet has been Added", "Name Rex1794589205 Birth Date 2020-05-01 Type dog"
rename Max1794589205 -> "Pet details has been edited"
duplicate Max1794589205 -> "Name: is already in use"
birth date 2999-01-01   -> "Birth Date: invalid date"
31-char name            -> "Name: Name must be no more than 30 characters"
$ curl -sS -w '\nHTTP %{http_code}\n' -d "name=NoType1794589205&birthDate=2020-01-01" http://localhost:8080/owners/11/pets/new
HTTP 200, <span class="help-inline">is required</span>
```
The date was entered with key presses in MMDDYYYY order. `fill` left the field empty (Known Failure Mode 5).

**15: Visits.** Screenshots: `W6-visit-booked.png`, `W6-visit-today.png`.
```
form /owners/11/pets/14/visits/new: date default 2026-11-14, min 2026-11-14
"QA check-up 1794589205" -> /owners/11, "Your visit has been booked", visit "2026-11-14 QA check-up 1794589205"
blank description  -> "Description: must not be blank"
256 chars          -> "Description: size must be between 0 and 255"
today 2026-11-13   -> browser blocked the submit (field validity false, URL unchanged, no server re-render)
$ curl -sS -d "date=2026-11-13&description=TodayCurl1794589205" http://localhost:8080/owners/11/pets/14/visits/new
HTTP 200, <span class="help-inline">Visit date must be in the future</span>
owner page afterwards lists only the one booked visit
```

**16: Error pages.** Screenshot: `W8-oups.png`.
```
nav ERROR -> /oups: h2 "Something happened...", "An internal server error occurred.", nav bar present (curl: HTTP 500)
/does-not-exist -> "Something happened...", "The requested page was not found." (curl: HTTP 404)
```
`app.log` has no ERROR entries other than the two deliberate `/oups` exceptions.

**17: Language switch.** Screenshots: `W9-de.png`, `W9-de-vets.png`.
```
/?lang=de -> h2 "Willkommen", nav STARTSEITE, BESITZER SUCHEN, TIERÄRZTE, FEHLER
click TIERÄRZTE -> /vets.html, h2 "Tierärzte", "James Carter keine"
open /owners/find -> h2 "Besitzer suchen"
/?lang=en -> "Welcome"; /owners/find -> "Find Owners"
/?lang=xx -> "Welcome", no error
```

</details>

---

Screenshots and logs are in the `qa-results-43468095785-1` artifact of [this workflow run](https://github.com/factory-aj-pahl/spring-petclinic/actions/runs/43468095785). This check is informational and does not block merging.


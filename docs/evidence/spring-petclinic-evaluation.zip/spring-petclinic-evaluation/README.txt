Spring PetClinic: evaluation of agent-assisted remediation
==========================================================

Open presentation.html in a browser. It works offline.
Keys: Right and Left arrows or Space to move, N for speaker notes, F for full screen,
P to print or save as PDF (choose landscape and no margins).

Contents
  presentation.html     The presentation. Its links open the files below.
  evidence/             The evidence package from docs/evidence/ in pull request #1
    *.html              the Markdown files, rendered for a browser (start with README.html)
    *.md                the same files, as committed
    raw-evidence.sha256 the checksum of every file under raw/ and scripts/, as committed
    raw/                570 raw evidence files: logs, test reports, scans, probes,
                        QA reports and screenshots
    scripts/            21 scripts that produced or checked the raw files, and the
                        output of one
  repository-docs/      docs/DEPENDENCIES.md, docs/RUNBOOK.md and AGENTS.md from the
                        branch, as Markdown and HTML
  droid-wiki/           The 37 wiki pages that the Factory wiki skill generated, as
                        Markdown and HTML (start with index.html). They were kept local
                        and not uploaded, and they describe the branch at 2aff817.
  after-the-package/    The GitHub checks and the QA report comment for ee226cf, the head
                        of the pull request when they were collected, after the evidence
                        package was committed. raw-evidence.sha256 does not cover these files.
  assets/               The style sheet and the Mermaid library (MIT license) that the
                        HTML pages use

To check that the archive matches the pull request, run this in evidence/:
  sha256sum -c raw-evidence.sha256           (Linux)
  shasum -a 256 -c raw-evidence.sha256       (macOS)

Pull request: https://github.com/factory-aj-pahl/spring-petclinic/pull/1 (private repository)
Branch: security/spring-boot-4.1.2-cve-remediation
Built from commit 70c833f1cdb01a19d836b0f88ef8e26bec680df8.
The next commit on the branch adds this zip as docs/evidence/spring-petclinic-evaluation.zip
and changes nothing else.
Built: 2026-11-13T18:31:30Z

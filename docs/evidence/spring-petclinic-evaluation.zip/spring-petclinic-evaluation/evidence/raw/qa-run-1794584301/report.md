## QA Report

| #   | Test Case | App | Persona | Result | Notes |
| --- | --------- | --- | ------- | ------ | ----- |
| 1 | W3 Owner paging overflow: `page=999999999`, `2147483647`, `429496730`, `-2147483648` | web | visitor | :white_check_mark: PASS | Each one returns 302 to `/owners?page=1` with no error page. This is the `OwnerController` cap. |
| 2 | W3 Owner paging bounds: `page=3/0/-1` with 10 owners, and `page=3` (valid) / `page=4` with 11 owners | web | visitor | :white_check_mark: PASS | A valid last page renders with 1 row. A page beyond the last redirects to page 1. |
| 3 | W3 Filtered overflow `lastName=Davis&page=9` and `page=2147483647` | web | visitor | :white_check_mark: PASS | Both redirect to `/owners?page=1&lastName=Davis`, and the filter is kept. |
| 4 | W3 Negative: `page=abc` on owners and vets | web | visitor | :white_check_mark: PASS | PetClinic error page "An unexpected error occurred.", HTTP 400, not 500 |
| 5 | W7 Vets list, pager and page 2 (Sharon Jenkins) | web | visitor | :white_check_mark: PASS | Page 1 shows 5 vets with specialties ("none" for James Carter). This is the new `VetController` range check. |
| 6 | W7 Vets bounds: `page=3/0/-1/999999999/2147483647` | web | visitor | :white_check_mark: PASS | Each one lands on `/vets.html?page=1` with no error page. |
| 7 | Ad-hoc: 200 distinct out-of-range vets page numbers, then page 1 | web | visitor | :white_check_mark: PASS | All 200 return 302 before any paged query runs. Page 1 still returns 200. |
| 8 | A3 SBOM shows Spring Boot 4.1.2 and patched libraries | api | visitor | :white_check_mark: PASS | spring-boot 4.1.2, tomcat-embed-core 11.0.27, spring-webmvc 7.0.10, jackson 3.1.7, postgresql 42.7.14, log4j-api 2.25.5. All are at or above their minimums. |
| 9 | A3 SBOM index and missing SBOM 404 | api | visitor | :white_check_mark: PASS | `{"ids":["application"]}`, CycloneDX with 107 components, and `does-not-exist` returns 404 |
| 10 | A1 Vets JSON, XML and 406 for `text/csv` | api | visitor | :white_check_mark: PASS | 6 vets in both formats. James Carter has no specialties. Helen Leary has radiology. |
| 11 | A2 Health, liveness, readiness, info and the shutdown negative test | api | visitor | :white_check_mark: PASS | All UP. `git.commit.id` 407b5f3 matches HEAD. Version is 4.0.0-SNAPSHOT. `POST /actuator/shutdown` returns 404. |
| 12 | W1 Home page and navigation bar | web | visitor | :white_check_mark: PASS | The page is styled with a dark nav bar. Each link loads its heading and is marked active. |
| 13 | W2 Find owners (`Davis`, `davis`, `Franklin`, no match, empty search) | web | visitor | :white_check_mark: PASS | The search ignores case. Franklin goes straight to `/owners/1`. No match shows "has not been found". |
| 14 | W4 Add and edit an owner, plus validation (phone, blank fields, 81-character city) | web | visitor | :white_check_mark: PASS | Owner 11 was created, then its city was changed to Monona. Invalid input was not saved. |
| 15 | W5 Add and edit a pet, plus validation (duplicate, future date, no type via curl, 31-character name) | web | visitor | :white_check_mark: PASS | "is already in use", "invalid date", "is required" (HTTP 200) and "Name must be no more than 30 characters" |
| 16 | W6 Book a visit, plus validation (blank, 256 characters, today's date) | web | visitor | :white_check_mark: PASS | The visit was booked for tomorrow. Chrome refused today's date (`checkValidity()=false`), and nothing was saved. |
| 17 | W8 Error page (`/oups` 500, `/does-not-exist` 404) | web | visitor | :white_check_mark: PASS | The PetClinic layout shows "An internal server error occurred." and "The requested page was not found." |
| 18 | W9 Language switch (`de`, the choice persists, `en`, `xx`) | web | visitor | :white_check_mark: PASS | "Willkommen", Startseite and Besitzer suchen. German persists on Find Owners. `xx` falls back to English. |

Result values: :white_check_mark: PASS, :x: FAIL, :no_entry: BLOCKED, :warning: FLAKY, :grey_question: INCONCLUSIVE

<details>
<summary>Screenshots & Evidence</summary>

The server was built from commit `407b5f3` (branch `security/spring-boot-4.1.2-cve-remediation`) and run on `http://localhost:8080` with in-memory H2. Run ID `1794584301`. Screenshots are in the downloadable artifacts under `qa-results/1794584301/`: `W1-home.png`, `W3-invalid.png`, `W4-created.png`, `W4-edited.png`, `W4-diff.gif` (owner before and after the edit), `W5-pet-added.png`, `W6-visit.png`, `W7-reset.png`. The full browser logs are `W2.txt`, `read-flows*.txt`, `W9.txt`, `W1-W4.txt`, `W5-W6.txt`, `adhoc.txt` and `api-evidence.txt`.

**Owner and vets paging overflow (the changed code), HTTP status and redirect:**

```text
/owners?page=2147483647                    HTTP 302 -> http://localhost:8080/owners?page=1
/owners?page=429496730                     HTTP 302 -> http://localhost:8080/owners?page=1
/owners?lastName=Davis&page=2147483647     HTTP 302 -> http://localhost:8080/owners?page=1&lastName=Davis
/owners?page=-2147483648                   HTTP 302 -> http://localhost:8080/owners?page=1
/vets.html?page=2147483647                 HTTP 302 -> http://localhost:8080/vets.html?page=1
/vets.html?page=999999999                  HTTP 302 -> http://localhost:8080/vets.html?page=1
/vets.html?page=2                          HTTP 200
/owners?page=abc                           HTTP 400
/vets.html?page=abc                        HTTP 400
```

**Browser: owner list after overflow page numbers (the address lands on page 1):**

```text
URL=/owners?page=999999999   -> http://localhost:8080/owners?page=1   heading "Owners", pages [1 2]
URL=/owners?page=2147483647  -> http://localhost:8080/owners?page=1   heading "Owners", pages [1 2]
URL=/owners?lastName=Davis&page=2147483647 -> http://localhost:8080/owners?page=1&lastName=Davis  (Betty Davis, Harold Davis)
URL=/owners?page=abc         -> heading "Something happened..."  "An unexpected error occurred."
```

**Browser: paging with 11 owners, after W4 added one:**

```text
page=3           -> http://localhost:8080/owners?page=3  "Owners rows=1 pager=pages [ 1 2 3 ]"
page=4           -> http://localhost:8080/owners?page=1  "Owners rows=5 pager=pages [ 1 2 3 ]"
page=2147483647  -> http://localhost:8080/owners?page=1  "Owners rows=5 pager=pages [ 1 2 3 ]"
```

**Browser: vets page 1 and page 2:**

```text
- heading "Veterinarians"
  - cell "James Carter" / "none"
  - cell "Helen Leary" / "radiology"
  - cell "Linda Douglas" / "dentistry surgery"
  - cell "Rafael Ortega" / "surgery"
  - cell "Henry Stevens" / "radiology"
  - StaticText "pages [1"  link "2"
(page 2) - cell "Sharon Jenkins"
/vets.html?page=3, 0, -1, 999999999, 2147483647 -> http://localhost:8080/vets.html?page=1
```

**Ad-hoc test: many distinct out-of-range vets pages:**

```text
200 requests /vets.html?page=100..299 ->  200 x HTTP 302
/vets.html?page=1 HTTP 200
```

**SBOM library versions (A3):**

```text
org.apache.tomcat.embed:tomcat-embed-core 11.0.27 >= 11.0.25: PASS
org.springframework:spring-webmvc 7.0.10 >= 7.0.9: PASS
tools.jackson.core:jackson-databind 3.1.7 >= 3.1.7: PASS
tools.jackson.core:jackson-core 3.1.7 >= 3.1.7: PASS
org.postgresql:postgresql 42.7.14 >= 42.7.12: PASS
org.apache.logging.log4j:log4j-api 2.25.5 >= 2.25.5: PASS
spring-boot 4.1.2; components=107: PASS
$ curl -sS http://localhost:8080/actuator/sbom               -> {"ids":["application"]}  HTTP 200
$ curl -sS http://localhost:8080/actuator/sbom/application   -> "bomFormat" : "CycloneDX"  HTTP 200 application/vnd.cyclonedx+json
$ curl -sS http://localhost:8080/actuator/sbom/does-not-exist -> HTTP 404
```

**Vets JSON and XML (A1):**

```text
$ curl -sS -H 'Accept: application/json' http://localhost:8080/vets
{"vetList":[{"firstName":"James","id":1,"lastName":"Carter",...,"specialties":[]},{"firstName":"Helen","id":2,"lastName":"Leary",...,"specialties":[{"id":1,"name":"radiology"...}]}, ... 6 vets]}
HTTP 200 application/json
$ curl -sS -H 'Accept: application/xml' http://localhost:8080/vets
<?xml version="1.0" ...?><vets><vetList><id>1</id><firstName>James</firstName>... (6 <vetList>)</vets>
HTTP 200 application/xml
$ curl -sS -H 'Accept: text/csv' http://localhost:8080/vets   -> HTTP 406
```

**Actuator (A2):**

```text
/actuator/health            {"groups":["liveness","readiness"],"status":"UP"}  HTTP 200
/actuator/health/liveness   {"status":"UP"}  HTTP 200
/actuator/health/readiness  {"status":"UP"}  HTTP 200
/actuator/info              {"git":{"branch":"security/spring-boot-4.1.2-cve-remediation","commit":{"id":"407b5f3"}},"build":{"version":"4.0.0-SNAPSHOT","artifact":"spring-petclinic",...}}
$ curl -X POST /actuator/shutdown  -> {"status":404,"error":"Not Found"}  HTTP 404
```

**Owner forms (W4):**

```text
/owners/11  #success-message "New Owner Created"  Name "Qa Qa1794584301" / 1 Main St / Madison / 6085550000
/owners/11  #success-message "Owner Values Updated"  City Monona
telephone 12345   -> /owners/new  "Telephone must be a 10-digit number"
empty form        -> /owners/new  "must not be blank" x5
city 81 chars     -> /owners/new  "size must be between 0 and 80"
search Phone1794584301 / Long1794584301 -> "has not been found" (nothing saved)
```

**Pet and visit forms (W5, W6):**

```text
"New Pet has been Added"  Rex1794584301, 2020-05-01, dog
"Pet details has been edited"  Max1794584301
duplicate name -> "is already in use";  2999-01-01 -> "invalid date";  31 chars -> "Name must be no more than 30 characters"
$ curl -sS -d "name=NoType1794584301&birthDate=2020-01-01" http://localhost:8080/owners/11/pets/new -> "is required"  HTTP 200
"Your visit has been booked"  2026-11-14 QA check-up 1794584301 (date default = min = tomorrow)
blank -> "must not be blank";  256 chars -> "size must be between 0 and 255"
today 2026-11-13 -> checkValidity()=false, Chrome blocked submit (stayed on form); no "Today" visit saved
```

**Error pages and language (W8, W9):**

```text
/oups            HTTP 500  "Something happened..." "An internal server error occurred."
/does-not-exist  HTTP 404  "Something happened..." "The requested page was not found."
/?lang=de        heading "Willkommen", nav STARTSEITE / BESITZER SUCHEN / TIERÄRZTE / FEHLER
click Besitzer suchen -> /owners/find heading "Besitzer suchen" (German kept)
/?lang=en -> "Welcome";  /?lang=xx -> "Welcome" (English, no error)
```

**Server log:** the only ERROR entry is the intentional `CrashController` exception from `/oups`. The other entries are WARN lines for the expected 406 and the `page=abc` 400 conversions.

</details>

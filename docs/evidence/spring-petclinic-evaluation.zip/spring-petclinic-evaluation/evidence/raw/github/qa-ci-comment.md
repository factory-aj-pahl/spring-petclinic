<!-- qa-report -->
## QA Report

| #   | Test Case | App | Persona | Result | Notes |
| --- | --------- | --- | ------- | ------ | ----- |
| 1 | W3: owner list page numbers past the new cap (`429496729`, `429496730`, `999999999`, `2147483647`, `-2147483648`, `3`, `0`, `-1`) | web | visitor | :white_check_mark: PASS | Each one redirects (302) to `/owners?page=1` and shows the first 5 owners. No error page, and no 500 in `app.log` |
| 2 | W3: filtered owner search with an out-of-range page (`lastName=Davis&page=9` and `page=2147483647`) | web | visitor | :white_check_mark: PASS | Lands on `/owners?page=1&lastName=Davis`, so the filter is kept |
| 3 | W3: page numbers that are not valid integers (`page=abc`, `page=2147483648`) | web | visitor | :white_check_mark: PASS | Both show the PetClinic error page "An unexpected error occurred." with HTTP 400, not 500 |
| 4 | W3: owner pager, pages 1 and 2 | web | visitor | :white_check_mark: PASS | 5 owners on each page. Clicking "2" in the pager loads Jean Coleman to Carlos Estaban |
| 5 | W7: vets list and pager | web | visitor | :white_check_mark: PASS | Page 1 lists James Carter to Henry Stevens with their specialties ("none" where a vet has none). Page 2 lists Sharon Jenkins |
| 6 | W7: vets page numbers out of range (`3`, `0`, `999999999`, `2147483647`, `-2147483648`) and `abc` | web | visitor | :white_check_mark: PASS | Each out-of-range number redirects (302) to `/vets.html?page=1`. `abc` returns 400 and the error page. `page=2` still returns 200 |
| 7 | Ad-hoc: out-of-range vets pages do not grow the `vets` cache | web | visitor | :white_check_mark: PASS | After 500 requests for `page=2000` to `2499` (all 302), the heap still holds 2 cached `PageImpl` objects and 1 `SimpleKey`, the same as before |
| 8 | A3: SBOM shows the Spring Boot 4.1.2 upgrade | api | visitor | :white_check_mark: PASS | `spring-boot`, `spring-boot-webmvc`, `spring-boot-tomcat` and `spring-boot-actuator` are all at 4.1.2 |
| 9 | A3: patched library versions are at or above their minimums | api | visitor | :white_check_mark: PASS | tomcat-embed-core 11.0.27, spring-webmvc 7.0.10, jackson-databind and jackson-core 3.1.7, postgresql 42.7.14, log4j-api 2.25.5. The minimums match `PatchedDependencyVersionsTests` |
| 10 | A3: SBOM index, document and unknown id | api | visitor | :white_check_mark: PASS | `{"ids":["application"]}`. The document is CycloneDX with 107 components. An unknown id returns 404 |
| 11 | A1: vets as JSON and XML, and an unsupported type | api | visitor | :white_check_mark: PASS | JSON has 6 vets (Carter has none, Leary has radiology). XML has a `<vets>` root and 6 `<vetList>` elements. `text/csv` returns 406 |
| 12 | A2: health, liveness and readiness | api | visitor | :white_check_mark: PASS | All return HTTP 200 and `UP`, and the `liveness` and `readiness` groups are listed |
| 13 | A2: build info, and shutdown blocked | api | visitor | :white_check_mark: PASS | `git.commit.id` is `204566f`, which matches HEAD. Artifact is `spring-petclinic` and version is `4.0.0-SNAPSHOT`. `POST /actuator/shutdown` returns 404 |
| 14 | W2: find owners | web | visitor | :white_check_mark: PASS | `Davis` and `davis` both list Betty and Harold Davis. `Franklin` goes to `/owners/1`. An unknown name shows "has not been found". An empty search lists all owners on 2 pages |
| 15 | W4: add and edit an owner, with validation | web | visitor | :white_check_mark: PASS | The new owner gets id 11 and shows "New Owner Created". The city edit shows "Owner Values Updated". The phone, blank-field and size messages all appear, and none of the invalid owners was saved |
| 16 | W5: add and edit a pet, with validation | web | visitor | :white_check_mark: PASS | The add and edit messages appear. The duplicate, future-date, 31-character-name and missing-type checks all fail with the expected messages ("is required" was checked with curl, HTTP 200) |
| 17 | W6: book a visit, with validation | web | visitor | :white_check_mark: PASS | "Your visit has been booked" appears for 2026-11-14. Blank and 256-character descriptions are rejected. Chrome refused to submit today's date ("Value must be 11/14/2026 or later.") |
| 18 | W1: home page and navigation | web | visitor | :white_check_mark: PASS | The page is styled, with a dark navigation bar and the pets picture. Home, Find Owners and Veterinarians each load and are marked active in the bar |
| 19 | W8: error pages | web | visitor | :white_check_mark: PASS | `/oups` shows "An internal server error occurred." (500, which is expected). `/does-not-exist` shows "The requested page was not found." (404). Both use the normal layout |
| 20 | W9: language switch | web | visitor | :white_check_mark: PASS | `?lang=de` shows "Willkommen", "Startseite" and "Besitzer suchen", and German stays on for the next pages. `?lang=en` switches back. `?lang=xx` shows English with HTTP 200 |

Result values: :white_check_mark: PASS, :x: FAIL, :no_entry: BLOCKED, :warning: FLAKY, :grey_question: INCONCLUSIVE

### Action Required

- The `droid-control@factory-plugins` plugin is not installed on the runner (`droid plugin list` reports no plugins). The web flows were driven with the bundled `agent-browser` 0.37.1 directly. Video evidence is off (`video_evidence: false`), so nothing was lost. To use the droid-control route the QA skill expects, install the plugin in the QA workflow.

<details>
<summary>Screenshots & Evidence</summary>

Run ID `1794587602`. The server was built from HEAD `204566f` and started on `http://localhost:8080` with the default H2 database. Screenshots are in the downloadable artifacts under `qa-results/1794587602/`: `W1-home.png`, `W2-davis.png`, `W3-page2.png`, `W3-page-maxint.png`, `W4-owner-created.png`, `W4-before-edit.png`, `W4-after-edit.png`, `W4-diff.gif` (owner page before and after the city edit), `W5-pet-added.png`, `W5-pet-edited.png`, `W5-diff.gif` (pet before and after the rename), `W6-visit-booked.png`, `W7-vets-page1.png`, `W7-vets-page2.png`, `W8-oups.png`, `W9-de.png`. The server log is `app.log`.

**W3: owner page numbers. This shows the new `Integer.MAX_VALUE / pageSize` cap redirects instead of failing.** The browser's final address and rows:

```
== open /owners?page=429496729
"/owners?page=1 | rows: George Franklin, Betty Davis, Eduardo Rodriquez, Harold Davis, Peter McTavish | pager: pages [ 1 2 ]"
== open /owners?page=429496730
"/owners?page=1 | rows: George Franklin, Betty Davis, Eduardo Rodriquez, Harold Davis, Peter McTavish | pager: pages [ 1 2 ]"
== open /owners?page=2147483647
"/owners?page=1 | rows: George Franklin, Betty Davis, Eduardo Rodriquez, Harold Davis, Peter McTavish | pager: pages [ 1 2 ]"
== open /owners?page=-2147483648
"/owners?page=1 | rows: George Franklin, Betty Davis, Eduardo Rodriquez, Harold Davis, Peter McTavish | pager: pages [ 1 2 ]"
== open /owners?lastName=Davis&page=2147483647
"/owners?page=1&lastName=Davis | rows: Betty Davis, Harold Davis | pager: none"
== open /owners?page=abc
"/owners?page=abc | h2: Something happened... | p: An unexpected error occurred."
```

**W3: HTTP status for each request** (`curl -sS -o /dev/null -w '%{http_code} %{redirect_url}' -H 'Accept: text/html' <url>`):

```
/owners?page=3 -> 302 http://localhost:8080/owners?page=1
/owners?page=0 -> 302 http://localhost:8080/owners?page=1
/owners?page=-1 -> 302 http://localhost:8080/owners?page=1
/owners?page=999999999 -> 302 http://localhost:8080/owners?page=1
/owners?page=2147483647 -> 302 http://localhost:8080/owners?page=1
/owners?lastName=Davis&page=9 -> 302 http://localhost:8080/owners?page=1&lastName=Davis
/owners?page=abc -> 400
/owners?page=429496729 -> 302 http://localhost:8080/owners?page=1
/owners?page=429496730 -> 302 http://localhost:8080/owners?page=1
/owners?page=-2147483648 -> 302 http://localhost:8080/owners?page=1
/owners?lastName=Davis&page=2147483647 -> 302 http://localhost:8080/owners?page=1&lastName=Davis
/owners?page=2147483648 -> 400
```

**W7: vets list and page numbers. This shows the range check now runs before the paged query.**

```
== open /vets.html
"/vets.html | rows: James Carter [none], Helen Leary [radiology], Linda Douglas [dentistry surgery], Rafael Ortega [surgery], Henry Stevens [radiology] | pager: pages [ 1 2 ]"
== clicked pager 2
"/vets.html?page=2 | rows: Sharon Jenkins [none] | pager: pages [ 1 2 ]"

/vets.html?page=3 -> 302 http://localhost:8080/vets.html?page=1
/vets.html?page=0 -> 302 http://localhost:8080/vets.html?page=1
/vets.html?page=999999999 -> 302 http://localhost:8080/vets.html?page=1
/vets.html?page=2147483647 -> 302 http://localhost:8080/vets.html?page=1
/vets.html?page=-2147483648 -> 302 http://localhost:8080/vets.html?page=1
/vets.html?page=2 -> 200
/vets.html?page=abc -> 400
```

**Ad-hoc: the `vets` cache does not grow when out-of-range pages are requested.** The cache is an unbounded Caffeine cache (`/actuator/caches`). The heap was counted with `jcmd <pid> GC.class_histogram`, which forces a full GC first:

```
heap before: org.springframework.data.domain.PageRequest=4 org.springframework.data.domain.PageImpl=2 org.springframework.cache.interceptor.SimpleKey=1
500 out-of-range requests /vets.html?page=2000..2499 -> 500 302
heap after:  org.springframework.data.domain.PageRequest=4 org.springframework.data.domain.PageImpl=2 org.springframework.cache.interceptor.SimpleKey=1
page=1 200
page=2 200
heap after valid pages: org.springframework.data.domain.PageRequest=4 org.springframework.data.domain.PageImpl=2 org.springframework.cache.interceptor.SimpleKey=1
```

**Server log.** The only `ERROR` lines are the two intended `/oups` exceptions. The rejected `page=abc` and `page=2147483648` requests appear as `WARN MethodArgumentTypeMismatchException` (400). No paging request caused a 500.

**A3: runtime SBOM. This shows the server ships Spring Boot 4.1.2 and the patched libraries.**

```
$ curl http://localhost:8080/actuator/sbom
{"ids":["application"]}
HTTP 200 application/vnd.spring-boot.actuator.v3+json

$ curl -D - http://localhost:8080/actuator/sbom/application
HTTP/1.1 200
Content-Type: application/vnd.cyclonedx+json
bomFormat: CycloneDX  components: 107

$ ... | jq -r '.components[] | select(.name | test("^(tomcat-embed-core|spring-webmvc|jackson-databind|jackson-core|postgresql|log4j-api)$")) | "\(.group):\(.name) \(.version)"'
org.apache.logging.log4j:log4j-api 2.25.5            (min 2.25.5)
org.apache.tomcat.embed:tomcat-embed-core 11.0.27    (min 11.0.25)
org.springframework:spring-webmvc 7.0.10             (min 7.0.9)
org.postgresql:postgresql 42.7.14                    (min 42.7.12)
tools.jackson.core:jackson-databind 3.1.7            (min 3.1.7)
tools.jackson.core:jackson-core 3.1.7                (min 3.1.7)

Spring Boot modules:
org.springframework.boot:spring-boot 4.1.2
org.springframework.boot:spring-boot-webmvc 4.1.2
org.springframework.boot:spring-boot-tomcat 4.1.2
org.springframework.boot:spring-boot-actuator 4.1.2

$ curl -o /dev/null -w '%{http_code}' http://localhost:8080/actuator/sbom/does-not-exist
404
```

**A1: vets JSON and XML**

```
$ curl -sS -H 'Accept: application/json' http://localhost:8080/vets
HTTP/1.1 200   Content-Type: application/json
vets: 6
1 James Carter []
2 Helen Leary ["radiology"]
3 Linda Douglas ["dentistry","surgery"]
4 Rafael Ortega ["surgery"]
5 Henry Stevens ["radiology"]
6 Sharon Jenkins []
keys: ["firstName","id","lastName","new","nrOfSpecialties","specialties"]

$ curl -sS -H 'Accept: application/xml' http://localhost:8080/vets
<?xml version="1.0" encoding="UTF-8" standalone="yes"?><vets ...
vetList elements: 6
HTTP 200 application/xml

$ curl -sS -o /dev/null -w '%{http_code}' -H 'Accept: text/csv' http://localhost:8080/vets
406
```

**A2: health and info**

```
$ curl http://localhost:8080/actuator/health
{"groups":["liveness","readiness"],"status":"UP"}
HTTP 200
$ curl http://localhost:8080/actuator/health/liveness
{"status":"UP"}
HTTP 200
$ curl http://localhost:8080/actuator/health/readiness
{"status":"UP"}
HTTP 200
$ curl http://localhost:8080/actuator/info
{"git":{"branch":"security/spring-boot-4.1.2-cve-remediation","commit":{"id":"204566f",...}},"build":{"version":"4.0.0-SNAPSHOT","artifact":"spring-petclinic",...}}
HTTP 200        (git rev-parse HEAD = 204566f6245e630b69f7067c30ea3f04a200ef98)
$ curl -o /dev/null -w '%{http_code}' -X POST http://localhost:8080/actuator/shutdown
404
```

**W2: find owners**

```
== search 'Davis'    -> "/owners?lastName=Davis | rows: Betty Davis, Harold Davis"
== search 'davis'    -> "/owners?lastName=davis | rows: Betty Davis, Harold Davis"
== search 'Franklin' -> "/owners/1 | h2: Owner Information"  (George Franklin, 110 W. Liberty St., Madison)
== search 'Zzqa1794587602' -> "h2: Find Owners | help: has not been found"
== search ''         -> "rows: George Franklin, Betty Davis, Eduardo Rodriquez, Harold Davis, Peter McTavish | pager: pages [ 1 2 ]"
```

**W4: owner form** (owner `Qa Qa1794587602`, id 11)

```
saw: New Owner Created
== after add: http://localhost:8080/owners/11
"New Owner Created | Name Qa Qa1794587602 ; Address 1 Main St ; City Madison ; Telephone 6085550000"
saw: Owner Values Updated
"Owner Values Updated | Name Qa Qa1794587602 ; Address 1 Main St ; City Monona ; Telephone 6085550000"
== negative: phone 12345   -> "errors: Telephone=Telephone must be a 10-digit number"
== negative: all empty     -> "errors: First Name=must not be blank; Last Name=must not be blank; Address=must not be blank; City=must not be blank; Telephone=must not be blank ..."
== negative: city 81, first name 31 -> "errors: First Name=size must be between 0 and 30; City=size must be between 0 and 80"
== negative: address 256   -> "errors: Address=size must be between 0 and 255"
Searching for the rejected last names (QaTel, QaLen, QaAdr) returns "has not been found" for each one
```

**W5: pet form** (pet id 14 on owner 11)

```
saw: New Pet has been Added      -> "Name Rex1794587602 Birth Date 2020-05-01 Type dog"
saw: Pet details has been edited -> "Name Max1794587602 Birth Date 2020-05-01 Type dog"
== negative: duplicate name -> "errors: Name=is already in use"
== negative: future birth date 2999-01-01 -> "errors: Birth Date=invalid date"
== negative: name 31 chars -> "errors: Name=Name must be no more than 30 characters"
$ curl -sS -w "\nHTTP %{http_code}\n" -d "name=NoType1794587602&birthDate=2020-01-01" http://localhost:8080/owners/11/pets/new
HTTP 200   (body contains "is required")
```

**W6: visit form**

```
visit form: date type=date value=2026-11-14 min=2026-11-14
saw: Your visit has been booked -> "Visit Date Description ; 2026-11-14 QA check-up 1794587602"
== negative: blank description -> "errors: Description=must not be blank"
== negative: 256 chars         -> "errors: Description=size must be between 0 and 255"  (h2: New Visit, no error page)
== negative: today's date 2026-11-13 -> the browser refused to submit: "Value must be 11/14/2026 or later." (the address stayed on /visits/new)
```

**W1, W8, W9: navigation, error page and language**

```
== click /owners/find -> "Find Owners | active nav: FIND OWNERS"
== click /vets.html   -> "Veterinarians | active nav: VETERINARIANS"
== click /            -> "Welcome | active nav: HOME"     (nav background rgb(52, 48, 45))
== click Error nav    -> "/oups | nav: HOME, FIND OWNERS, VETERINARIANS, ERROR | h2: Something happened... | p: An internal server error occurred."  (HTTP 500, expected)
== open /does-not-exist -> "h2: Something happened... | p: The requested page was not found."  (HTTP 404)
== open /?lang=de     -> "nav: STARTSEITE, BESITZER SUCHEN, TIERÄRZTE, FEHLER | h2: Willkommen"
== click Find Owners  -> "/owners/find | h2: Besitzer suchen"
== click Vets         -> "/vets.html | h2: Tierärzte"
== open /?lang=en     -> "h2: Welcome"
== open /?lang=xx     -> "h2: Welcome"  (HTTP 200)
```

</details>

---

Screenshots and logs are in the `qa-results-43463692800-1` artifact of [this workflow run](https://github.com/factory-aj-pahl/spring-petclinic/actions/runs/43463692800). This check is informational and does not block merging.


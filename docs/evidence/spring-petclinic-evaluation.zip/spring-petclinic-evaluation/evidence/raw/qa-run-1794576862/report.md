## QA Report

| #   | Test Case | App | Persona | Result | Notes |
| --- | --------- | --- | ------- | ------ | ----- |
| 1 | Owner list: huge page numbers (`999999999`, `2147483647`, `429496729`, `429496730`) redirect to page 1 | web | visitor | :white_check_mark: PASS | Each lands on `/owners?page=1` (HTTP 302), no error page. Before the fix these returned HTTP 500. |
| 2 | Vets list: huge page numbers (`999999999`, `2147483647`, `429496729`, `429496730`) redirect to page 1 | web | visitor | :white_check_mark: PASS | Each lands on `/vets.html?page=1` (HTTP 302). |
| 3 | Paging boundaries: `0`, `-1`, `-2147483648`, the page after the last one, filtered `lastName=Davis&page=9` | web | visitor | :white_check_mark: PASS | All land on page 1, and the Davis filter is kept (`/owners?page=1&lastName=Davis`). With 11 owners, page 3 shows the new owner and page 4 redirects. |
| 4 | Negative: non-integer page (`abc`, `2147483648`) | web | visitor | :white_check_mark: PASS | PetClinic error page "An unexpected error occurred." with HTTP 400 (type mismatch), not 500. |
| 5 | W2 Find owners: `Davis`, `davis`, `Franklin`, unknown name, empty search | web | visitor | :white_check_mark: PASS | 2 Davis owners for both cases; Franklin goes to `/owners/1`; "has not been found"; empty search shows page 1 of 2. |
| 6 | W3 Owner pager | web | visitor | :white_check_mark: PASS | 5 owners on page 1 and on page 2; the pager links work. |
| 7 | W7 Vets list and pager | web | visitor | :white_check_mark: PASS | 5 vets with specialties ("none" for Carter); page 2 shows Sharon Jenkins. |
| 8 | A1 Vets JSON / XML / 406 on Spring Boot 4.1.2 | api | visitor | :white_check_mark: PASS | JSON 200 with 6 vets (Carter has none, Leary has radiology); XML 200 with `<vets>` and 6 `<vetList>`; `text/csv` returns 406. |
| 9 | A2 Health, liveness, readiness, info; shutdown blocked | api | visitor | :white_check_mark: PASS | All UP; `git.commit.id` f9bbb32 matches HEAD; `build.version` 4.0.0-SNAPSHOT; `POST /actuator/shutdown` returns 404. |
| 10 | A3 SBOM shows the upgraded and patched versions | api | visitor | :white_check_mark: PASS | spring-boot 4.1.2, tomcat-embed-core 11.0.27, spring-webmvc 7.0.10, jackson-databind/core 3.1.7, postgresql 42.7.14, log4j-api 2.25.5; all at or above the minimums. 107 components; an unknown SBOM id returns 404. |
| 11 | W1 Home page, styling and navigation | web | visitor | :white_check_mark: PASS | Styled dark nav bar; images load; Home, Find Owners and Veterinarians headings render. |
| 12 | W4 Add/edit owner and validation | web | visitor | :white_check_mark: PASS | "New Owner Created" (id 11), "Owner Values Updated" (city Monona); errors for a bad phone, blank fields, and city 81 / first name 31 / address 256 characters. |
| 13 | W5 Add/edit pet and validation | web | visitor | :white_check_mark: PASS | "New Pet has been Added", "Pet details has been edited"; "is already in use", "invalid date", "Name must be no more than 30 characters"; a curl post without a type returns HTTP 200 with "is required". |
| 14 | W6 Book a visit and validation | web | visitor | :white_check_mark: PASS | "Your visit has been booked" with the default date (tomorrow). Errors for a blank description and one of 256 characters. Chrome blocked submitting today's date ("Value must be 11/14/2026 or later."). |
| 15 | W8 Error pages | web | visitor | :white_check_mark: PASS | `/oups` shows "An internal server error occurred." (500, expected); `/does-not-exist` shows "The requested page was not found." (404). |
| 16 | W9 Language switch | web | visitor | :white_check_mark: PASS | `lang=de` shows Willkommen / Startseite / Besitzer suchen, and German persists on the next page; `lang=en` and `lang=xx` show English. |

Result values: :white_check_mark: PASS, :x: FAIL, :no_entry: BLOCKED, :warning: FLAKY, :grey_question: INCONCLUSIVE

<details>
<summary>Screenshots & Evidence</summary>

Server: `java -jar target/spring-petclinic-4.0.0-SNAPSHOT.jar --server.port=8080` built from f9bbb32 with uncommitted changes, default H2 profile. The banner shows "Built with Spring Boot :: 4.1.2" and the log shows Apache Tomcat/11.0.27. The only `ERROR` lines in `app.log` come from the two intentional `/oups` requests.

**Tests 1-4: paging caps and bounds (HTTP status of the browser requests)**
```
$ curl -sS -o /dev/null -w '%{http_code} %{redirect_url}' -H 'Accept: text/html' 'http://localhost:8080/owners?page=2147483647'
302 http://localhost:8080/owners?page=1
$ ... '/owners?page=429496730'
302 http://localhost:8080/owners?page=1
$ ... '/vets.html?page=2147483647'
302 http://localhost:8080/vets.html?page=1
$ ... '/owners?lastName=Davis&page=9'
302 http://localhost:8080/owners?page=1&lastName=Davis
$ ... '/owners?page=2147483648'
400
$ ... '/vets.html?page=2147483648'
400
$ ... '/owners?page=abc'
400
```

**Test 1: browser at `/owners?page=999999999` (accessibility tree, trimmed): page 1 of the list**
```
W3 999999999 http://localhost:8080/owners?page=1
- heading "Owners" [level=2]
  - row
    - cell "George Franklin"
    ...
- generic
  - StaticText "pages [1"
  - link "2"
```

**Test 2: browser at `/vets.html?page=2147483647` (trimmed)**
```
W7 targeted 2147483647 http://localhost:8080/vets.html?page=1
- heading "Veterinarians" [level=2]
  - row
    - cell "James Carter"
    - cell "none"
```

**Test 4: browser at `/owners?page=2147483648`: error page instead of a 500**
```
Targeted owner 2147483648 http://localhost:8080/owners?page=2147483648
- heading "Something happened..." [level=2]
- paragraph
  - StaticText "An unexpected error occurred."
```

**Test 3: after creating owner 11 (3 pages)**
```
$ curl -sS -w 'HTTP %{http_code} %{redirect_url}' 'http://localhost:8080/owners?page=3'
HTTP 200      (body contains Qa1794576862)
$ curl ... '/owners?page=4'
HTTP 302 http://localhost:8080/owners?page=1
$ curl ... '/owners?page=2147483647'
HTTP 302 http://localhost:8080/owners?page=1
```

**Test 5: owner search for `Franklin` goes straight to the owner's page**
```
W2 'Franklin' http://localhost:8080/owners/1
- heading "Owner Information" [level=2]
    - cell "George Franklin"
```

**Test 7: vets page 2**
```
W7 page 2 http://localhost:8080/vets.html?page=2
    - cell "Sharon Jenkins"
    - cell "none"
```

**Tests 8-10: API (see `api.txt` for the full commands)**
```
$ curl -sS -H 'Accept: application/json' http://localhost:8080/vets
HTTP 200 application/json   vetList: 6 (Carter specialties [], Leary [radiology])
$ curl -sS -H 'Accept: application/xml' http://localhost:8080/vets
HTTP 200 application/xml    root <vets>, 6 <vetList>
$ curl -sS -o /dev/null -w '%{http_code}' -H 'Accept: text/csv' http://localhost:8080/vets
406
$ curl -sS http://localhost:8080/actuator/health
{"groups":["liveness","readiness"],"status":"UP"}   (liveness and readiness: {"status":"UP"})
$ curl -sS http://localhost:8080/actuator/info
"git":{"branch":"security/spring-boot-4.1.2-cve-remediation","commit":{"id":"f9bbb32",...}},"build":{"version":"4.0.0-SNAPSHOT","artifact":"spring-petclinic",...}
$ curl -sS -o /dev/null -w '%{http_code}' -X POST http://localhost:8080/actuator/shutdown
404
$ curl -sS http://localhost:8080/actuator/sbom
{"ids":["application"]}
$ curl -sS http://localhost:8080/actuator/sbom/application
HTTP 200 application/vnd.cyclonedx+json  bomFormat CycloneDX, 107 components
org.springframework.boot:spring-boot 4.1.2
org.apache.tomcat.embed:tomcat-embed-core 11.0.27   (min 11.0.25)
org.springframework:spring-webmvc 7.0.10            (min 7.0.9)
tools.jackson.core:jackson-databind 3.1.7           (min 3.1.7)
tools.jackson.core:jackson-core 3.1.7               (min 3.1.7)
org.postgresql:postgresql 42.7.14                   (min 42.7.12)
org.apache.logging.log4j:log4j-api 2.25.5           (min 2.25.5)
$ curl -sS -o /dev/null -w '%{http_code}' http://localhost:8080/actuator/sbom/does-not-exist
404
```

**Tests 12-14: form flows (page state after each submit)**
```
W4 created {"url": ".../owners/11", "success": "New Owner Created"}  City Madison
W4 updated {"success": "Owner Values Updated"}  City Monona
W4 bad phone   ["Telephone: Telephone must be a 10-digit number"]
W4 empty       ["First Name: must not be blank", "Last Name: must not be blank", "Address: must not be blank", "City: must not be blank", "Telephone: ..."]
W4 long city   ["City: size must be between 0 and 80"]
W4 long first  ["First Name: size must be between 0 and 30", "Address: size must be between 0 and 255"]
W5 added       {"success": "New Pet has been Added"}  Rex1794576862 2020-05-01 dog
W5 edited      {"success": "Pet details has been edited"}  Max1794576862
W5 duplicate   ["Name: is already in use"]
W5 future      ["Birth Date: invalid date"]
W5 long name   ["Name: Name must be no more than 30 characters"]
$ curl -sS -w '\nHTTP %{http_code}\n' -d 'name=NoType1794576862&birthDate=2020-01-01' http://localhost:8080/owners/11/pets/new
<span class="help-inline">is required</span>
HTTP 200
W6 date default {'value': '2026-11-14', 'min': '2026-11-14'}
W6 booked      {"success": "Your visit has been booked"}  2026-11-14  QA check-up 1794576862
W6 blank       ["Description: must not be blank"]
W6 long        ["Description: size must be between 0 and 255"]
W6 today field {'value': '2026-11-13', 'valid': False, 'msg': 'Value must be 11/14/2026 or later.'}  -> browser refused to submit; no visit saved
```

**Test 16: language switch**
```
W9 German http://localhost:8080/?lang=de   heading "Willkommen"; nav STARTSEITE, BESITZER SUCHEN
W9 persists http://localhost:8080/owners/find   heading "Besitzer suchen"
W9 unsupported http://localhost:8080/?lang=xx   heading "Welcome"
```

Screenshot files, in the downloadable artifacts under `qa-results/1794576862/`: `W1-home.png`, `W3-before.png`, `W3-after.png`, `W3-diff.gif` (page 1, and page 1 again after the `page=2147483647` redirect), `W4-created.png`, `W4-updated.png`, `W5-added.png`, `W5-edited.png`, `W5-diff.gif`, `W6-booked.png`, `W8-error.png`. Full browser logs: `web-readonly.txt`, `web-lang.txt`, `web-forms.txt`; API log: `api.txt`; SBOM: `sbom.json`; server log: `app.log`.

</details>

## Suggested Skill Updates (2 issues found)

| #   | Severity        | File     | Issue               | Fix Prompt                                                                           |
| --- | --------------- | -------- | ------------------- | ------------------------------------------------------------------------------------ |
| 1   | 🟡 Degraded | `.factory/skills/qa-web/SKILL.md` | With agent-browser, an `open` or `click` sent before the previous navigation finished failed with `net::ERR_ABORTED` or "Element not found" | <details><summary>Copy</summary><br>`In .factory/skills/qa-web/SKILL.md, append to "Known Failure Modes": "Navigation race in agent-browser. Running open, click or snapshot right after a click that loads a page can fail with net::ERR_ABORTED or 'Element not found', or capture the old page. After every navigation or form submit, run 'agent-browser wait --load networkidle' before the next command."`</details> |
| 2   | 🔵 Info | `.factory/skills/qa-web/SKILL.md` | `agent-browser fill` leaves `<input type="date">` empty (agent-browser 0.43, en-US Chrome) | <details><summary>Copy</summary><br>`In .factory/skills/qa-web/SKILL.md, extend item 5 "Date inputs" in "Known Failure Modes": with agent-browser, 'fill' and 'type' leave date fields empty. Run 'agent-browser focus #birthDate', then press each digit in MMDDYYYY order with 'agent-browser press <digit>' (en-US locale), and read the value back with eval before submitting.`</details> |

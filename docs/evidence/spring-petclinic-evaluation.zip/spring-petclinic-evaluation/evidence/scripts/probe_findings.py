import http.client, json, re, subprocess, sys, time, urllib.parse

mode, port, pid, out = sys.argv[1], int(sys.argv[2]), sys.argv[3], sys.argv[4]
JCMD = "/home/factory-user/.local/tools/jdk-17/bin/jcmd"

def conn():
    return http.client.HTTPConnection("localhost", port, timeout=30)

def req(c, method, path, form=None):
    h = {"Accept": "text/html"}
    body = None
    if form is not None:
        body = urllib.parse.urlencode(form)
        h["Content-Type"] = "application/x-www-form-urlencoded"
    c.request(method, path, body=body, headers=h)
    r = c.getresponse()
    data = r.read().decode("utf-8", "replace")
    return r.status, {k.lower(): v for k, v in r.getheaders()}, data

def histogram():
    txt = subprocess.run([JCMD, pid, "GC.class_histogram"], capture_output=True, text=True).stdout
    counts = {}
    for line in txt.splitlines():
        m = re.match(r"\s*\d+:\s+(\d+)\s+(\d+)\s+(\S+)", line)
        if m and m.group(3) in ("org.springframework.data.domain.PageImpl", "org.springframework.data.domain.PageRequest"):
            counts[m.group(3).rsplit(".", 1)[1]] = {"instances": int(m.group(1)), "bytes": int(m.group(2))}
    heap = subprocess.run([JCMD, pid, "GC.heap_info"], capture_output=True, text=True).stdout
    m = re.search(r"used (\d+)K", heap)
    return counts, (int(m.group(1)) if m else None)

def owners_in(body):
    return re.findall(r'<a href="/owners/(\d+)(?:;jsessionid=[^"]*)?"[^>]*>([^<]*)</a>', body)

res = {"mode": mode, "port": port}
if mode == "h2":
    c = conn()
    # F15: distinct page numbers on /vets.html
    h0, heap0 = histogram()
    statuses = {}
    t0 = time.time()
    for k in range(2, 5002):
        s, _, _ = req(c, "GET", f"/vets.html?page={k}")
        statuses[s] = statuses.get(s, 0) + 1
    t1 = time.time()
    h1, heap1 = histogram()
    statuses_repeat = {}
    for k in range(2, 5002):
        s, _, _ = req(c, "GET", f"/vets.html?page={k}")
        statuses_repeat[s] = statuses_repeat.get(s, 0) + 1
    h2, heap2 = histogram()
    res["F15"] = {
        "requests_distinct_pages": 5000, "statuses": statuses, "seconds": round(t1 - t0, 2),
        "before": h0, "heap_used_kb_before": heap0,
        "after_5000_distinct": h1, "heap_used_kb_after_distinct": heap1,
        "after_same_5000_again": h2, "heap_used_kb_after_repeat": heap2, "statuses_repeat": statuses_repeat,
    }
    # F18 on H2: lower-case search
    s, _, body = req(c, "GET", "/owners?lastName=davis")
    res["F18_h2"] = {"query": "lastName=davis", "status": s, "owners": owners_in(body), "not_found_message": "has not been found" in body}
    # F20: invalid owner form, error flash text
    s, _, body = req(c, "POST", "/owners/new", {"firstName": "", "lastName": "", "address": "", "city": "", "telephone": ""})
    res["F20_flash"] = {"status": s, "flash_text_present": "There was an error in creating the owner." in body,
                         "field_error_markers": len(re.findall(r'invalid-feedback|help-inline|has-error', body))}
    # F16: filtered search with two pages
    created = []
    for i in range(1, 7):
        s, h, _ = req(c, "POST", "/owners/new", {"firstName": f"Probe{i}", "lastName": "Probetest", "address": "1 Main St", "city": "Town", "telephone": "6085550000"})
        created.append((s, h.get("location")))
    s, _, body = req(c, "GET", "/owners?lastName=Probetest")
    links = sorted(set(re.findall(r'href="([^"]*page=[^"]*)"', body)))
    page1 = owners_in(body)
    page2_link = next((l for l in links if re.search(r"page=2(\D|$)", l)), None)
    p2 = None
    if page2_link:
        s2, _, body2 = req(c, "GET", page2_link.replace("&amp;", "&"))
        p2 = {"link": page2_link, "status": s2, "owners": owners_in(body2),
              "non_probe_owners": [o for o in owners_in(body2) if "Probetest" not in o[1]]}
    res["F16"] = {"created": created, "search_status": s, "page1_owners": page1, "page_links": links,
                  "links_with_lastName": [l for l in links if "lastName" in l], "page2": p2}
elif mode == "pg":
    c = conn()
    for q in ("davis", "Davis"):
        s, _, body = req(c, "GET", f"/owners?lastName={q}")
        res[f"F18_pg_{q}"] = {"status": s, "owners": owners_in(body), "not_found_message": "has not been found" in body}
print(json.dumps(res, indent=1))
with open(f"{out}/{mode}-probe.json", "w") as f:
    json.dump(res, f, indent=1)

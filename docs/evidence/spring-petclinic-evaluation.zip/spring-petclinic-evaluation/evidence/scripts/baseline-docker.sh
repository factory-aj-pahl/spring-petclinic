#!/bin/sh
# Full Maven build of the unchanged upstream commit 500158f (Spring Boot 4.1.0) with Docker
# running, so the baseline test count and coverage compare like for like with the branch.
# Uses a local clone, so the git-commit-id plugin reports 500158f.
set -u
REPO=/home/factory-user/spring-petclinic
export JAVA_HOME=$HOME/.local/tools/jdk-17
export PATH=$JAVA_HOME/bin:$PATH
CL=/tmp/petclinic-baseline-docker
OUT=/home/factory-user/petclinic-evaluation/evidence/raw/baseline-docker
mkdir -p "$OUT"
rm -rf "$CL"
git clone -q --no-hardlinks "$REPO" "$CL" > "$OUT/clone.txt" 2>&1
cd "$CL"
git checkout -q --detach 500158f >> "$OUT/clone.txt" 2>&1
{
  echo "commit: $(git rev-parse HEAD)"
  grep -A1 '<artifactId>spring-boot-starter-parent</artifactId>' pom.xml | tail -1 | tr -d ' '
  java -version 2>&1 | head -1
  docker version --format 'docker server {{.Server.Version}}'
  echo "maven start: $(date -u +%FT%TZ)"
} > "$OUT/env.txt" 2>&1
./mvnw -B clean verify > "$OUT/mvn-verify.log" 2>&1
echo "maven exit: $?" >> "$OUT/env.txt"
echo "maven end: $(date -u +%FT%TZ)" >> "$OUT/env.txt"
cp -a target/surefire-reports "$OUT/surefire-reports" 2>/dev/null
cp target/site/jacoco/jacoco.csv "$OUT/jacoco.csv" 2>/dev/null
cd /
rm -rf "$CL"
echo "clone removed: $( [ -e "$CL" ] && echo no || echo yes )" >> "$OUT/env.txt"
echo "done: $(date -u +%FT%TZ)" >> "$OUT/env.txt"

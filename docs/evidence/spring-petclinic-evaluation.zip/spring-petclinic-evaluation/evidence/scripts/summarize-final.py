import csv, glob, os, re, sys, xml.etree.ElementTree as ET
out = sys.argv[1]
print(open(os.path.join(out, 'env.txt')).read())
def junit(dirpath):
    t = f = e = s = 0
    for x in glob.glob(os.path.join(dirpath, 'TEST-*.xml')):
        r = ET.parse(x).getroot()
        t += int(r.get('tests', 0)); f += int(r.get('failures', 0)); e += int(r.get('errors', 0)); s += int(r.get('skipped', 0))
    return t, f, e, s, len(glob.glob(os.path.join(dirpath, 'TEST-*.xml')))
print('surefire (tests, failures, errors, skipped, files):', junit(os.path.join(out, 'surefire-reports')))
print('gradle    (tests, failures, errors, skipped, files):', junit(os.path.join(out, 'gradle-test-results')))
mvn = open(os.path.join(out, 'mvn-verify.log'), errors='replace').read()
summ = re.findall(r'Tests run: \d+, Failures: \d+, Errors: \d+, Skipped: \d+(?!,)', mvn)
print('maven last summary:', summ[-1] if summ else None, '| BUILD SUCCESS' if 'BUILD SUCCESS' in mvn else '| no BUILD SUCCESS')
m = re.search(r'Total time:\s+(.*)', mvn); print('maven total time:', m.group(1) if m else None)
gr = open(os.path.join(out, 'gradle-build.log'), errors='replace').read()
m = re.search(r'BUILD (SUCCESSFUL|FAILED)[^\n]*', gr); print('gradle:', m.group(0) if m else None)
for f in ('osv-pom.txt', 'osv-sbom.txt'):
    lines = open(os.path.join(out, f), errors='replace').read().strip().splitlines()
    print(f, '->', lines[-3:])
hook = open(os.path.join(out, 'hook-unittest.log')).read().strip().splitlines()
print('hook ->', hook[-3:])
L = [0, 0]; B = [0, 0]
with open(os.path.join(out, 'jacoco.csv')) as fh:
    for row in csv.DictReader(fh):
        L[0] += int(row['LINE_MISSED']); L[1] += int(row['LINE_COVERED'])
        B[0] += int(row['BRANCH_MISSED']); B[1] += int(row['BRANCH_COVERED'])
print(f'jacoco line {L[1]}/{L[0]+L[1]} = {100*L[1]/(L[0]+L[1]):.1f}%, branch {B[1]}/{B[0]+B[1]} = {100*B[1]/(B[0]+B[1]):.1f}%')
print('sbom present:', os.path.exists(os.path.join(out, 'sbom.cdx.json')))

import json, os, subprocess, sys, tempfile, shutil, textwrap
from ruamel.yaml import YAML

REPO = '/home/factory-user/spring-petclinic'
wf = YAML(typ='safe').load(open(f'{REPO}/.github/workflows/qa.yml'))
steps = {s.get('name') or s.get('uses'): s for s in wf['jobs']['qa']['steps']}
post = steps['Post the QA report on the pull request']['run']
keycheck = steps['Check for the Factory API key']['run']

FAKE_GH = textwrap.dedent('''\
    #!/bin/bash
    if [ "$1" = api ] && [ "$2" = --paginate ]; then cat "$FAKE_COMMENTS"; exit 0; fi
    if [ "$1" = api ] && [ "$2" = --method ]; then
      echo "$3 $4" >> "$FAKE_LOG"
      for a in "$@"; do case "$a" in body=@*) cp "${a#body=@}" "$FAKE_OUT";; esac; done
      exit 0
    fi
    echo "unexpected gh call: $*" >&2; exit 1
''')

failures = []
def check(name, cond, detail=''):
    print(('PASS ' if cond else 'FAIL ') + name + (f' -- {detail}' if detail and not cond else ''))
    if not cond: failures.append(name)

def run_post(report=None, output=None, pages=None):
    d = tempfile.mkdtemp(prefix='qa-post-')
    ws, tmp, binp = (os.path.join(d, x) for x in ('ws', 'tmp', 'bin'))
    for p in (ws, tmp, binp): os.makedirs(p)
    if report is not None:
        os.makedirs(os.path.join(ws, 'qa-results'))
        open(os.path.join(ws, 'qa-results', 'report.md'), 'wb').write(report.encode())
    if output is not None:
        open(os.path.join(ws, 'qa-output.txt'), 'w').write(output)
    open(os.path.join(binp, 'gh'), 'w').write(FAKE_GH); os.chmod(os.path.join(binp, 'gh'), 0o755)
    comments = os.path.join(d, 'comments.json')
    open(comments, 'w').write(''.join(json.dumps(p) for p in (pages or [[]])))
    script = os.path.join(d, 'step.sh'); open(script, 'w').write(post)
    env = dict(os.environ, PATH=f'{binp}:' + os.environ['PATH'], RUNNER_TEMP=tmp, GITHUB_REPOSITORY='o/r',
               PR_NUMBER='7', ARTIFACT='qa-results-1-1', RUN_URL='https://github.com/o/r/actions/runs/1',
               FAKE_COMMENTS=comments, FAKE_LOG=os.path.join(d, 'log'), FAKE_OUT=os.path.join(d, 'out.md'))
    # GitHub runs `run:` steps with `bash -e {0}` when no shell is set.
    p = subprocess.run(['bash', '-e', script], cwd=ws, env=env, capture_output=True, text=True)
    out = open(env['FAKE_OUT'], 'rb').read() if os.path.exists(env['FAKE_OUT']) else b''
    log = open(env['FAKE_LOG']).read() if os.path.exists(env['FAKE_LOG']) else ''
    shutil.rmtree(d)
    return p, out, log

def fences_balanced(t): return sum(1 for l in t.splitlines() if l.lstrip(' ').startswith('```')) % 2 == 0
def details_balanced(t): return t.count('<details') == t.count('</details>')

# A: small report with heading, no existing comment -> POST
p, out, log = run_post(report='## QA Report\n\n| # | Test |\n| 1 | ok |\n')
t = out.decode()
check('A exit 0', p.returncode == 0, p.stderr)
check('A POST used', log.strip() == 'POST repos/o/r/issues/7/comments', log)
check('A marker first line', t.splitlines()[0] == '<!-- qa-report -->')
check('A heading kept once', t.count('## QA Report') == 1)
check('A footer', 'qa-results-1-1' in t and 'informational' in t)

# B: report without heading (blank lines first) -> heading added
p, out, log = run_post(report='\n\n# Results\nall good\n')
t = out.decode()
check('B heading added', t.splitlines()[1] == '## QA Report', t[:80])

# B2: heading after blank lines is recognised (no duplicate)
p, out, log = run_post(report='\n\n## QA Report\nok\n')
check('B2 no duplicate heading', out.decode().count('## QA Report') == 1)

# C: large report cut inside an open code block and an open <details>
big = '## QA Report\n\n| 1 | x |\n\n<details>\n<summary>Evidence</summary>\n\n```text\n' + ('line of evidence \u2705 caf\u00e9\n' * 4000) + '```\n\n</details>\n'
p, out, log = run_post(report=big)
check('C exit 0', p.returncode == 0, p.stderr)
try:
    t = out.decode('utf-8'); ok = True
except UnicodeDecodeError as e:
    ok = False; t = out.decode('utf-8', 'replace')
check('C valid UTF-8', ok)
check('C under 65536 chars', len(t) < 65536, str(len(t)))
check('C fences balanced', fences_balanced(t))
check('C details balanced', details_balanced(t))
check('C cut note', 'cut short' in t)
check('C footer last', t.rstrip().endswith('does not block merging.'))

# C2: emoji straddling the byte cut point (60000) still yields valid UTF-8
pre = '## QA Report\n\n' + 'a' * (59998 - len('## QA Report\n\n'))
p, out, log = run_post(report=pre + '\u2705\u2705\u2705 tail\nmore\n' + 'b' * 9000 + '\n')
try:
    out.decode('utf-8'); ok = True
except UnicodeDecodeError: ok = False
check('C2 valid UTF-8 at cut', ok)

# D: existing comments over two pages; another user's marker comment is ignored -> PATCH bot's id
pages = [[{'id': 1, 'user': {'login': 'someone'}, 'body': '<!-- qa-report --> quoted'},
          {'id': 2, 'user': {'login': 'someone'}, 'body': None}],
         [{'id': 3, 'user': {'login': 'github-actions[bot]'}, 'body': 'other bot comment'},
          {'id': 4, 'user': {'login': 'github-actions[bot]'}, 'body': '<!-- qa-report -->\n## QA Report'}]]
p, out, log = run_post(report='## QA Report\nok\n', pages=pages)
check('D exit 0', p.returncode == 0, p.stderr)
check('D PATCH bot comment 4', log.strip() == 'PATCH repos/o/r/issues/comments/4', log)

# E: no report, output present -> fallback with balanced fence and details
p, out, log = run_post(output='boom\nerror: auth failed\n')
t = out.decode()
check('E fallback text', 'did not write a report' in t and 'error: auth failed' in t)
check('E fences/details balanced', fences_balanced(t) and details_balanced(t))

# F: no report and no output
p, out, log = run_post()
check('F exit 0', p.returncode == 0, p.stderr)
check('F no output note', 'No output was captured.' in out.decode())

# Key check step
for key, expect in (('', 'false'), ('secret-value', 'true')):
    d = tempfile.mkdtemp(prefix='qa-key-'); gho = os.path.join(d, 'out')
    script = os.path.join(d, 'k.sh'); open(script, 'w').write(keycheck)
    p = subprocess.run(['bash', '-e', script], cwd=d, env=dict(os.environ, FACTORY_API_KEY=key, GITHUB_OUTPUT=gho), capture_output=True, text=True)
    got = open(gho).read().strip()
    rep = os.path.join(d, 'qa-results', 'report.md')
    check(f'key={bool(key)} output set={expect}', p.returncode == 0 and got == f'set={expect}', got + p.stderr)
    if expect == 'false':
        r = open(rep).read()
        check('missing key report', r.startswith('## QA Report') and '`FACTORY_API_KEY`' in r and 'Dependabot' in r, r)
    else:
        check('key present: no report written', not os.path.exists(rep))
    shutil.rmtree(d)

print('FAILURES:', failures)
sys.exit(1 if failures else 0)

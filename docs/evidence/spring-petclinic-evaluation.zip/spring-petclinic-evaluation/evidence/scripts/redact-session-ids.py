"""Replaces the HTTP session ids in probe output with <redacted>, as in raw/findings-probe/."""
import re, sys

RX = re.compile(r'(?i)(;jsessionid=)[0-9a-f]{16,}')
for path in sys.argv[1:]:
    with open(path, encoding='utf-8') as fh:
        text = fh.read()
    new, n = RX.subn(r'\1<redacted>', text)
    with open(path, 'w', encoding='utf-8') as fh:
        fh.write(new)
    print(f'{path}: {n} session ids redacted')

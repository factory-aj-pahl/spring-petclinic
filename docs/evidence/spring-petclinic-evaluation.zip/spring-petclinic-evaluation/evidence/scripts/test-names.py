import glob, xml.etree.ElementTree as ET
D = '/home/factory-user/petclinic-evaluation/evidence/raw/final-4/surefire-reports'
for cls in ['UntrustedInputIntegrationTests', 'PatchedDependencyVersionsTests', 'DatabaseUnavailableAtStartupTests', 'PostgresOutageIntegrationTests', 'VetControllerTests', 'OwnerControllerTests']:
    f = glob.glob(f'{D}/TEST-*.{cls}.xml')[0]
    r = ET.parse(f).getroot()
    cases = r.findall('testcase')
    by = {}
    for c in cases:
        by.setdefault(c.get('name').split('(')[0].split('[')[0].strip(), []).append(c.get('name'))
    print(f'== {cls}: {len(cases)} cases, time {r.get("time")}s')
    for k, v in by.items():
        print(f'   {len(v)} x {k}: {v[:12]}')

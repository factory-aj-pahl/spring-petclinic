#!/bin/sh
# Runs the dependency version guard on the base commit (Spring Boot 4.1.0) in a temporary
# worktree, to show that it fails when the vulnerable versions come back.
set -u
REPO=/home/factory-user/spring-petclinic
export JAVA_HOME=$HOME/.local/tools/jdk-17
export PATH=$JAVA_HOME/bin:$PATH
WT=/tmp/petclinic-guard-check
OUT=/home/factory-user/petclinic-evaluation/evidence/raw/guard-check-4.1.0
mkdir -p "$OUT"
cd "$REPO"
git worktree add --detach "$WT" 500158f > "$OUT/worktree.txt" 2>&1
cp src/test/java/org/springframework/samples/petclinic/PatchedDependencyVersionsTests.java "$WT/src/test/java/org/springframework/samples/petclinic/"
cd "$WT"
{
  echo "worktree commit: $(git rev-parse HEAD)"
  echo "guard test copied from: $(git -C "$REPO" rev-parse HEAD)"
  grep -A1 '<artifactId>spring-boot-starter-parent</artifactId>' pom.xml | tail -1 | tr -d ' '
  echo "start: $(date -u +%FT%TZ)"
} > "$OUT/env.txt"
./mvnw -B test -Dtest=PatchedDependencyVersionsTests -Dsurefire.failIfNoSpecifiedTests=false > "$OUT/mvn-test.log" 2>&1
echo "maven exit: $?" >> "$OUT/env.txt"
echo "end: $(date -u +%FT%TZ)" >> "$OUT/env.txt"
cd "$REPO"
git worktree remove --force "$WT" >> "$OUT/worktree.txt" 2>&1
git worktree prune
echo "done" >> "$OUT/env.txt"

"""Writes the untrusted-input probe of 03:33 and its output, as recorded in the session
transcript, to raw/overflow-discovery/probe-transcript.txt. Tokens are redacted."""
import json, re
P = '/home/factory-user/.factory/sessions/-home-factory-user-spring-petclinic/5f856a0b-6321-404e-bcb7-7b7183376551.jsonl'
OUT = '/home/factory-user/petclinic-evaluation/evidence/raw/overflow-discovery/probe-transcript.txt'
TOK = re.compile(r'(gh[pousr]_[A-Za-z0-9]{10,}|github_pat_[A-Za-z0-9_]{10,}|fk-[A-Za-z0-9_-]{10,}|x-access-token:[^@\s]+)')
WINDOW = ('2026-11-13T03:33:00', '2026-11-13T03:34:10')
uses, out = {}, []
with open(P, encoding='utf-8', errors='replace') as fh:
    for line in fh:
        try:
            o = json.loads(line)
        except Exception:
            continue
        t = o.get('timestamp', '')
        if not (WINDOW[0] <= t[:19] <= WINDOW[1]):
            continue
        m = o.get('message') or {}
        for x in m.get('content') or []:
            if not isinstance(x, dict):
                continue
            if x.get('type') == 'tool_use' and x['id'] not in uses:
                uses[x['id']] = True
                inp = x.get('input') or {}
                body = inp.get('script') or inp.get('command') or json.dumps(inp)
                out.append(f'=== {t} agent tool call ({x.get("name")})\n{body}\n')
            elif x.get('type') == 'tool_result' and x.get('tool_use_id') in uses:
                cc = x.get('content')
                s = cc if isinstance(cc, str) else '\n'.join(i.get('text', '') for i in cc if isinstance(i, dict)) if isinstance(cc, list) else json.dumps(cc)
                uses[x.get('tool_use_id')] = False
                out.append(f'=== {t} tool result\n{s}\n')
text = TOK.sub('[REDACTED]', '\n'.join(out))
open(OUT, 'w', encoding='utf-8').write(text)
print(f'wrote {OUT}: {len(out)} entries, {len(text)} characters')

#!/bin/sh
# Final verification run for the evidence package. Runs sequentially: Maven and Gradle
# both start the same Docker containers.
set -u
cd /home/factory-user/spring-petclinic
export JAVA_HOME=$HOME/.local/tools/jdk-17
export PATH=$JAVA_HOME/bin:$HOME/.local/tools/bin:$PATH
OUT=/home/factory-user/petclinic-evaluation/evidence/raw/final-2
mkdir -p "$OUT"
ENV="$OUT/env.txt"
{
  echo "commit: $(git rev-parse HEAD)"
  echo "branch: $(git rev-parse --abbrev-ref HEAD)"
  echo "uncommitted tracked changes: $(git status --porcelain --untracked-files=no | wc -l)"
  java -version 2>&1 | head -1
  docker version --format 'docker server {{.Server.Version}}'
  echo "osv-scanner: $(osv-scanner --version 2>&1 | head -1)"
  echo "maven start: $(date -u +%FT%TZ)"
} > "$ENV" 2>&1
./mvnw -B clean verify > "$OUT/mvn-verify.log" 2>&1
echo "maven exit: $?" >> "$ENV"
echo "maven end: $(date -u +%FT%TZ)" >> "$ENV"
rm -rf "$OUT/surefire-reports"; cp -a target/surefire-reports "$OUT/surefire-reports" 2>/dev/null
cp target/site/jacoco/jacoco.csv "$OUT/jacoco.csv" 2>/dev/null
cp target/classes/META-INF/sbom/application.cdx.json "$OUT/sbom.cdx.json" 2>/dev/null
osv-scanner scan source -L pom.xml > "$OUT/osv-pom.txt" 2>&1
echo "osv pom exit: $?" >> "$ENV"
osv-scanner scan source -L target/classes/META-INF/sbom/application.cdx.json > "$OUT/osv-sbom.txt" 2>&1
echo "osv sbom exit: $?" >> "$ENV"
python3 -B -m unittest discover -s .factory/hooks -v > "$OUT/hook-unittest.log" 2>&1
echo "hook tests exit: $?" >> "$ENV"
echo "gradle start: $(date -u +%FT%TZ)" >> "$ENV"
./gradlew --no-daemon clean build > "$OUT/gradle-build.log" 2>&1
echo "gradle exit: $?" >> "$ENV"
echo "gradle end: $(date -u +%FT%TZ)" >> "$ENV"
rm -rf "$OUT/gradle-test-results"; cp -a build/test-results/test "$OUT/gradle-test-results" 2>/dev/null
echo "done: $(date -u +%FT%TZ)" >> "$ENV"

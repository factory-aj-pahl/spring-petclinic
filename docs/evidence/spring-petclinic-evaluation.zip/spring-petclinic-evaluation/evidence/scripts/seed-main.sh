#!/bin/sh
# One-time push of the unchanged upstream commit 500158f to main of
# factory-aj-pahl/spring-petclinic, approved as decision 7 in
# /home/factory-user/petclinic-evaluation/evidence/approval-record.md.
# It refuses to run when origin is not that repository or main already exists.
set -u
REPO=/home/factory-user/spring-petclinic
OUT=/home/factory-user/petclinic-evaluation/evidence/raw/seed-main
EXPECTED_COMMIT=500158f732419217507c7656904b8e6aa1bcc0d6
EXPECTED_ORIGIN=https://github.com/factory-aj-pahl/spring-petclinic.git
mkdir -p "$OUT"
LOG="$OUT/push.log"
cd "$REPO" || exit 1
{
  echo "start: $(date -u +%FT%TZ)"
  echo "script: $0"
  echo "commit to push: $(git rev-parse "$EXPECTED_COMMIT^{commit}")"
  echo "origin (remote.origin.url): $(git config --get remote.origin.url)"
  echo "acting GitHub account: $(gh api user --jq .login)"
  echo "remote branches before:"
  git ls-remote --heads origin
} > "$LOG" 2>&1
fail() { echo "precondition failed: $1" >> "$LOG"; echo "end: $(date -u +%FT%TZ)" >> "$LOG"; exit 1; }
[ "$(git rev-parse "$EXPECTED_COMMIT^{commit}")" = "$EXPECTED_COMMIT" ] || fail "commit $EXPECTED_COMMIT not found"
[ "$(git config --get remote.origin.url)" = "$EXPECTED_ORIGIN" ] || fail "origin is not $EXPECTED_ORIGIN"
[ -z "$(git ls-remote --heads origin)" ] || fail "origin already has branches"
if git push origin "$EXPECTED_COMMIT:refs/heads/main" >> "$LOG" 2>&1; then rc=0; else rc=$?; fi
{
  echo "push exit: $rc"
  echo "remote branches after:"
  git ls-remote --heads origin
  echo "end: $(date -u +%FT%TZ)"
} >> "$LOG" 2>&1
# git can rewrite the URL with a credential (url.*.insteadOf); keep any user:token@ part out of the log.
sed -i -E 's#(https?://)[^/@[:space:]]+@#\1#g' "$LOG"
exit "$rc"

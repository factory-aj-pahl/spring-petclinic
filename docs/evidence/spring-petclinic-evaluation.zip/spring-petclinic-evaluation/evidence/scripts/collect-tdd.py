import re
E = '/home/factory-user/petclinic-evaluation/evidence/raw'
for f in ['tdd-before-overflow-fix.log', 'tdd-red-overflow.log', 'tdd-green-overflow.log', 'tdd-red-f15.log', 'tdd-green-f15.log']:
    t = open(f'{E}/{f}', errors='replace').read()
    print('=====', f, len(t.splitlines()), 'lines')
    for m in re.finditer(r'Tests run: (\d+), Failures: (\d+), Errors: (\d+), Skipped: (\d+), Time elapsed: [^\n]*? - in ([\w.]+)', t):
        print('  ', m.group(5).split('.')[-1], m.group(1), 'fail', m.group(2), 'err', m.group(3))
    for line in t.splitlines():
        if re.search(r'Building spring-petclinic|-Dtest|Running org|commit ', line) and 'Running org' not in line:
            print('  >', line.strip()[:200])
    i = t.find('Results:')
    if i >= 0:
        print(t[i:i+2500])

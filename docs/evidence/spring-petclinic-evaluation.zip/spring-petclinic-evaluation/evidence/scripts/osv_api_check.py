#!/usr/bin/env python3
"""Query the OSV.dev API for every Maven coordinate in a `mvn dependency:list` output file.

Usage: osv_api_check.py <dependency-list.txt> <out.json>
Exit code 0 always; prints a one-line summary. Independent of osv-scanner so the two can be cross-checked.
"""
import json
import re
import sys
import urllib.request

API = "https://api.osv.dev/v1"
LINE = re.compile(r"^\s+([^:\s]+):([^:\s]+):[^:\s]+:(?:[^:\s]+:)?([^:\s]+):([a-z]+)(?:\s|$)")


def post(url, payload):
    req = urllib.request.Request(url, data=json.dumps(payload).encode(), headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=60) as r:
        return json.load(r)


def get(url):
    with urllib.request.urlopen(url, timeout=60) as r:
        return json.load(r)


def main():
    src, out = sys.argv[1], sys.argv[2]
    coords = {}
    for line in open(src, encoding="utf-8"):
        m = LINE.match(line)
        if m:
            g, a, v, scope = m.groups()
            coords.setdefault((f"{g}:{a}", v), scope)
    pkgs = sorted(coords)
    queries = [{"package": {"ecosystem": "Maven", "name": n}, "version": v} for n, v in pkgs]
    results = []
    for i in range(0, len(queries), 500):
        results += post(f"{API}/querybatch", {"queries": queries[i:i + 500]})["results"]
    findings, raw = [], {}
    for (name, version), res in zip(pkgs, results):
        for vuln in res.get("vulns", []):
            vid = vuln["id"]
            if vid not in raw:
                raw[vid] = get(f"{API}/vulns/{vid}")
            d = raw[vid]
            fixed = sorted({ev["fixed"] for aff in d.get("affected", []) if aff.get("package", {}).get("name") == name
                            for rng in aff.get("ranges", []) for ev in rng.get("events", []) if "fixed" in ev})
            findings.append({
                "package": name, "version": version, "scope": coords[(name, version)], "id": vid,
                "aliases": d.get("aliases", []), "summary": d.get("summary", ""),
                "severity": (d.get("database_specific") or {}).get("severity"),
                "cvss": [s.get("score") for s in d.get("severity", [])], "fixed": fixed,
                "published": d.get("published"), "modified": d.get("modified"),
            })
    json.dump({"scanned_packages": len(pkgs), "findings": findings, "raw": raw}, open(out, "w"), indent=2)
    pk = sorted({f["package"] for f in findings})
    print(f"scanned={len(pkgs)} findings={len(findings)} packages={len(pk)} {pk}")


if __name__ == "__main__":
    main()

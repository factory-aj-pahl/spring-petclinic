import glob, os, re, xml.etree.ElementTree as ET
E = '/home/factory-user/petclinic-evaluation/evidence/raw'
def per_class(d):
    out = {}
    for x in glob.glob(os.path.join(d, 'TEST-*.xml')):
        r = ET.parse(x).getroot()
        out[r.get('name').split('.')[-1]] = (int(r.get('tests')), int(r.get('failures')) + int(r.get('errors')), int(r.get('skipped')), float(r.get('time', 0)))
    return out
base = per_class(f'{E}/baseline-docker/surefire-reports')
fin = per_class(f'{E}/final-4/surefire-reports')
print(f'baseline-docker total {sum(v[0] for v in base.values())} in {len(base)} classes, fail {sum(v[1] for v in base.values())}, skip {sum(v[2] for v in base.values())}')
print(f'final-4 total {sum(v[0] for v in fin.values())} in {len(fin)} classes, fail {sum(v[1] for v in fin.values())}, skip {sum(v[2] for v in fin.values())}')
for k in sorted(set(base) | set(fin)):
    b = base.get(k, (0, 0, 0, 0)); f = fin.get(k, (0, 0, 0, 0))
    print(f'{k}: {b[0]} -> {f[0]} (fail {f[1]}, skip {f[2]}){"  NEW" if k not in base else ""}')
# Gradle per class (nested classes separate)
g = per_class(f'{E}/final-4/gradle-test-results')
print('gradle total', sum(v[0] for v in g.values()), 'fail', sum(v[1] for v in g.values()), 'skip', sum(v[2] for v in g.values()), 'files', len(g))
mvn = open(f'{E}/baseline-docker/mvn-verify.log', errors='replace').read()
m = re.search(r'Total time:\s+(.*)', mvn); print('baseline maven total time:', m.group(1) if m else None)
mvn4 = open(f'{E}/final-4/mvn-verify.log', errors='replace').read()
m = re.search(r'Total time:\s+(.*)', mvn4); print('final-4 maven total time:', m.group(1) if m else None)
# TDD logs
for f in ['tdd-before-overflow-fix.log', 'tdd-red-overflow.log', 'tdd-green-overflow.log', 'tdd-red-f15.log', 'tdd-green-f15.log']:
    t = open(f'{E}/{f}', errors='replace').read()
    summ = re.findall(r'Tests run: (\d+), Failures: (\d+), Errors: (\d+), Skipped: (\d+)(?!,)', t)
    fails = sorted(set(re.findall(r'\[ERROR\]\s+(?:Failures:\s+)?\s*([A-Za-z]+Tests?\.[A-Za-z0-9_]+)', t)))
    head = re.findall(r'(?m)^(?:commit|# ).*$', t)[:3]
    built = 'BUILD SUCCESS' in t
    print(f'{f}: summary {summ[-1] if summ else None} build_success={built} failing={fails[:12]} head={head}')
gc = open(f'{E}/guard-check-4.1.0/mvn-test.log', errors='replace').read()
print('guard check summary', re.findall(r'Tests run: (\d+), Failures: (\d+), Errors: (\d+), Skipped: (\d+)(?!,)', gc)[-1:])
for line in gc.splitlines():
    if re.search(r'expected|below|minimum|must be at least|\[ERROR\]   ', line):
        print('  ', line.strip()[:220])

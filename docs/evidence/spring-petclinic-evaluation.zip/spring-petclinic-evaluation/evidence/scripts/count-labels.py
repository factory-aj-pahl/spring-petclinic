"""Counts the Confirmed, Inferred and Unknown labels in docs/DEPENDENCIES.md, and its open questions."""
import re, sys

path = sys.argv[1] if len(sys.argv) > 1 else '/home/factory-user/spring-petclinic/docs/DEPENDENCIES.md'
lines = open(path, encoding='utf-8').read().splitlines()

def cells(row):
    return [c.strip() for c in re.split(r'(?<!\\)\|', row.strip().strip('|'))]

tables, section, current = [], '', None
for line in lines:
    if line.startswith('## '):
        section = line[3:].strip()
    if line.startswith('|'):
        if current is None:
            current = (section, [])
            tables.append(current)
        current[1].append(line)
    else:
        current = None

total = {}
for section, rows in tables:
    header = cells(rows[0])
    if 'Status' not in header:
        continue
    i = header.index('Status')
    counts = {}
    for row in rows[2:]:
        label = cells(row)[i]
        counts[label] = counts.get(label, 0) + 1
    print(f'{section}: {counts}')
    for k, v in counts.items():
        total[k] = total.get(k, 0) + v
print(f'Total: {total}, {sum(total.values())} entries')
print(f"Open questions: {sum(len(rows) - 2 for section, rows in tables if section == 'Open questions')}")

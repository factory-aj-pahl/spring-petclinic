"""Scans the evidence archive for credentials and personal data before it is shared.

Prints, for each pattern, the number of matches and the files that contain them, with the
matched values masked. Exits with 1 when a credential pattern matches.
"""
import os, re, sys

ROOT = sys.argv[1] if len(sys.argv) > 1 else '/home/factory-user/petclinic-evaluation/evidence'
# The scan's own output lists the matches it found, so scanning it again would count them twice.
OWN_OUTPUT = os.path.join('raw', 'credential-scan.txt')
CREDENTIALS = {
    'GitHub token': r'\b(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,})',
    'Factory API key': r'\bfk-[A-Za-z0-9_-]{16,}',
    'URL with credentials': r'[a-z][a-z0-9+.-]*://[^/\s:@"\'<>]+:[^@\s/"\'<>]+@',
    'x-access-token': r'x-access-token:[A-Za-z0-9_-]{20,}',
    'Authorization header': r'(?i)authorization["\']?\s*[:=]\s*["\']?(?:bearer|token|basic)\s+[A-Za-z0-9._~+/=-]{12,}',
    'Private key': r'-----BEGIN [A-Z ]*PRIVATE KEY-----',
    'AWS access key': r'\bAKIA[0-9A-Z]{16}\b',
    'Slack token': r'\bxox[abprs]-[A-Za-z0-9-]{10,}',
    'JWT': r'\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}',
    'HTTP session id': r'(?i)jsessionid=[0-9a-f]{16,}',
}
REVIEW = {
    'Password or secret assignment': r'(?i)\b(?:password|passwd|pwd|secret)["\']?\s*[:=]\s*["\']?([^\s"\',;})\]]{3,})',
    'Email address': r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}\b',
}

def mask(s):
    return s if len(s) <= 6 else s[:4] + '*' * 6

def scan(patterns):
    found = {}
    for dirpath, _, files in os.walk(ROOT):
        for name in files:
            path = os.path.join(dirpath, name)
            if name.lower().endswith(('.png', '.gif', '.jpg', '.jar')) or os.path.relpath(path, ROOT) == OWN_OUTPUT:
                continue
            try:
                text = open(path, encoding='utf-8', errors='replace').read()
            except OSError:
                continue
            for label, rx in patterns.items():
                for m in re.finditer(rx, text):
                    found.setdefault(label, {}).setdefault(os.path.relpath(path, ROOT), []).append(m.group(0))
    return found

bad = scan(CREDENTIALS)
print('Credential patterns:')
for label in CREDENTIALS:
    hits = bad.get(label, {})
    print(f'  {label}: {sum(len(v) for v in hits.values())}')
    for f, vals in sorted(hits.items()):
        print(f'    {f}: {len(vals)} ({", ".join(sorted({mask(v) for v in vals})[:5])})')
review = scan(REVIEW)
print('For manual review:')
for label in REVIEW:
    hits = review.get(label, {})
    print(f'  {label}: {sum(len(v) for v in hits.values())}')
    values = {}
    for f, vals in hits.items():
        for v in vals:
            values.setdefault(v, set()).add(f)
    for v, fs in sorted(values.items()):
        print(f'    {v!r}: {len(fs)} files, e.g. {sorted(fs)[0]}')
sys.exit(1 if bad else 0)

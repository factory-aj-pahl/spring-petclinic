#!/usr/bin/env bash
set -u
JDK=$HOME/.local/tools/jdk-17
export JAVA_HOME=$JDK PATH=$JDK/bin:$PATH
REPO=/home/factory-user/spring-petclinic
OUT=/home/factory-user/petclinic-evaluation/evidence/raw/findings-probe-final
JAR=/tmp/petclinic-final.jar
PY=/home/factory-user/petclinic-evaluation/work/probe_findings.py
mkdir -p "$OUT"
date -u +%FT%TZ > "$OUT/started.txt"
git -C "$REPO" rev-parse HEAD > "$OUT/head.txt"
sha256sum "$JAR" > "$OUT/jar.sha256"
unzip -p "$JAR" BOOT-INF/classes/git.properties 2>/dev/null | grep -E '^git.commit.id.abbrev=' > "$OUT/jar-git.txt" || true
java -version > "$OUT/java-version.txt" 2>&1
wait_up() { for i in $(seq 1 90); do curl -sf -o /dev/null "http://localhost:$1/actuator/health" && return 0; sleep 1; done; return 1; }

java -Xmx256m -jar "$JAR" --server.port=18080 > "$OUT/app-h2.log" 2>&1 &
APP=$!
if wait_up 18080; then
  python3 "$PY" h2 18080 "$APP" "$OUT" > "$OUT/h2-probe.txt" 2>&1; echo "h2 probe exit=$?" >> "$OUT/h2-probe.txt"
else echo "H2 app did not start" > "$OUT/h2-probe.txt"; fi
kill "$APP"; wait "$APP" 2>/dev/null

PGPASS=$(python3 -c 'import secrets; print(secrets.token_hex(16))')
docker run -d --rm --name probe-pg -e POSTGRES_USER=petclinic -e POSTGRES_PASSWORD="$PGPASS" -e POSTGRES_DB=petclinic -p 127.0.0.1:15432:5432 postgres:18.4 > "$OUT/pg-container.txt" 2>&1
for i in $(seq 1 90); do docker exec probe-pg pg_isready -h 127.0.0.1 -U petclinic -d petclinic >/dev/null 2>&1 && break; sleep 1; done
POSTGRES_URL=jdbc:postgresql://localhost:15432/petclinic POSTGRES_USER=petclinic POSTGRES_PASS="$PGPASS" \
  java -Xmx256m -jar "$JAR" --server.port=18081 --spring.profiles.active=postgres > "$OUT/app-pg.log" 2>&1 &
APP2=$!
if wait_up 18081; then
  python3 "$PY" pg 18081 "$APP2" "$OUT" > "$OUT/pg-probe.txt" 2>&1; echo "pg probe exit=$?" >> "$OUT/pg-probe.txt"
else echo "PG app did not start" > "$OUT/pg-probe.txt"; fi
kill "$APP2"; wait "$APP2" 2>/dev/null
docker stop probe-pg > /dev/null 2>&1
if grep -rlF -- "$PGPASS" "$OUT" > /dev/null 2>&1; then echo "generated password found in output files" > "$OUT/SECRET-CHECK-FAILED"; else echo "generated database password not present in any output file" > "$OUT/secret-check.txt"; fi
unset PGPASS
date -u +%FT%TZ > "$OUT/finished.txt"
echo done

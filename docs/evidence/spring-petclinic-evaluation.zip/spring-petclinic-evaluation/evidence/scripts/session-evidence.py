"""Builds the session evidence files from the Droid session transcript.

Outputs plain text with secrets redacted: user-authored messages, AskUser prompts and
answers, hook blocks on Execute calls, and the time spent waiting for answers.
"""
import json, re, sys
from datetime import datetime
P = '/home/factory-user/.factory/sessions/-home-factory-user-spring-petclinic/5f856a0b-6321-404e-bcb7-7b7183376551.jsonl'
TOK = re.compile(r'(gh[pousr]_[A-Za-z0-9]{10,}|github_pat_[A-Za-z0-9_]{10,}|fk-[A-Za-z0-9_-]{10,}|x-access-token:[^@\s]+)')
SYSTEM = re.compile(r'^(\[org-hook-test\]|Hook settings changed|Background task completed|Script Output from|\[Script completed|Script call_|<system-reminder>)')
def ts(s): return datetime.fromisoformat(s.replace('Z', '+00:00'))
def red(s): return TOK.sub('[REDACTED]', s)
uses, asks, answers, blocks, user_msgs = {}, {}, {}, [], []
first = last = None
with open(P, encoding='utf-8', errors='replace') as fh:
    for line in fh:
        try: o = json.loads(line)
        except Exception: continue
        t = o.get('timestamp')
        m = o.get('message') or {}
        role = m.get('role'); c = m.get('content')
        if not t or not role: continue
        first = first or t; last = t
        if isinstance(c, str): c = [{'type': 'text', 'text': c}]
        if not isinstance(c, list): continue
        for x in c:
            if not isinstance(x, dict): continue
            ty = x.get('type')
            if role == 'assistant' and ty == 'tool_use':
                uses[x['id']] = (t, x.get('name'), x.get('input') or {})
                if x.get('name') == 'AskUser':
                    asks[x['id']] = t
            elif role == 'user' and ty == 'tool_result':
                tid = x.get('tool_use_id')
                cc = x.get('content')
                s = cc if isinstance(cc, str) else ' '.join(i.get('text', '') for i in cc if isinstance(i, dict)) if isinstance(cc, list) else json.dumps(cc)
                if tid in asks: answers[tid] = (t, s)
                u = uses.get(tid)
                if u and u[1] == 'Execute' and re.match(r'\s*(Script policy rejected this inner tool call: )?(Error: )?Blocked by \.factory/hooks/guard_release_actions\.py', s):
                    blocks.append((t, u[2].get('command', ''), s[:400]))
            elif role == 'user' and ty == 'text':
                txt = x.get('text', '')
                if not SYSTEM.match(txt.strip()):
                    user_msgs.append((t, txt))
out = []
out.append(f'Session transcript: {P.rsplit("/", 1)[1]}')
out.append(f'First event {first}, last event {last}')
out.append('')
out.append('## Messages written by the user')
for t, s in user_msgs:
    out.append(f'{t}: {red(s).strip()}')
out.append('')
out.append('## AskUser prompts (asked, answered, wait)')
total_wait = 0; nq = 0
for i, (k, t) in enumerate(sorted(asks.items(), key=lambda kv: kv[1]), 1):
    q = uses[k][2].get('questionnaire', '')
    qs = re.findall(r'\[question\]\s*(.+)', q)
    nq += len(qs)
    a = answers.get(k)
    w = (ts(a[0]) - ts(t)).total_seconds() / 60 if a else 0
    total_wait += w
    out.append(f'### Prompt {i}: asked {t}, answered {a[0] if a else "-"}, wait {w:.1f} min, {len(qs)} question(s)')
    for qq in qs: out.append(f'- Q: {red(qq)}')
    if a:
        for qa in re.findall(r'\[answer\]\s*([^\n]+)', a[1]): out.append(f'  - A: {red(qa)}')
out.append('')
out.append(f'Total: {len(asks)} prompts, {nq} questions, {total_wait:.1f} minutes waiting for answers')
span = (ts(last) - ts(first)).total_seconds() / 60
out.append(f'Session span: {span:.1f} minutes, of which {total_wait:.1f} waiting for answers and {span - total_wait:.1f} not waiting')
out.append('')
out.append('## Execute calls blocked by .factory/hooks/guard_release_actions.py')
for t, cmd, s in blocks:
    out.append(f'{t}: command {red(cmd)[:300]!r}')
    out.append(f'    result: {red(s).strip()[:300]!r}')
print('\n'.join(out))
